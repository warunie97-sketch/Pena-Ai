import React, { useState, useEffect, useCallback } from 'react';
import { ToolId } from './types';
import { TOOLS, SHORTCUT_KEY_MAP } from './constants';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import GenericTextView from './features/GenericTextView';
import TextEditorView from './features/TextEditorView';
import ImageGeneratorView from './features/ImageGeneratorView';
import VideoGeneratorView from './features/VideoGeneratorView';
import ImageEditorView from './features/ImageEditorView';
import SearchView from './features/SearchView';
import EbookReaderView from './features/EbookReaderView';
import ContentManagerView from './features/ContentManagerView';
import AdsManagerView from './features/AdsManagerView';
import BookPublishingView from './features/BookPublishingView';
import CodeDocumentationView from './features/CodeDocumentationView';
import ProjectManagerView from './features/ProjectManagerView';
import AudioGeneratorView from './features/AudioGeneratorView';
import LiveChatView from './features/LiveChatView';
import VideoAnalysisView from './features/VideoAnalysisView';
import BlogView from './features/BlogView';
import { GeminiProvider, useGemini } from './contexts/GeminiContext';
import ApiKeyModal from './components/ApiKeyModal';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import AuthView from './features/AuthView';
import LoadingSpinner from './components/LoadingSpinner';
import EmailMarketingView from './features/EmailMarketingView';
import { UTMProvider } from './contexts/UTMContext';
import UTMSettingsView from './features/UTMSettingsView';
import CalendarView from './components/CalendarView';
import { ThemeProvider } from './contexts/ThemeContext';
import { LanguageProvider } from './contexts/LanguageContext';
import WelcomeView from './features/WelcomeView';
import ChatbotView from './features/ChatbotView';
import AudioTranscriptionView from './features/AudioTranscriptionView';
import CustomerSupportView from './features/CustomerSupportView';
import LocalDiscoveryView from './features/LocalDiscoveryView';
import AnimationGeneratorView from './features/AnimationGeneratorView';
import SupplyChainView from './features/SupplyChainView';
import WarehousingView from './features/WarehousingView';
import { AnalyticsProvider, useAnalytics } from './contexts/AnalyticsContext';
import DashboardView from './features/DashboardView';
import FeedView from './features/FeedView';

const AppContent: React.FC = () => {
  const [activeTool, setActiveTool] = useState<ToolId | null>(null);
  const [sharedContent, setSharedContent] = useState<string>('');
  const { isKeySet } = useGemini();
  const { trackToolUsage } = useAnalytics();

  const handleSetActiveTool = useCallback((toolId: ToolId | null) => {
    if (toolId) {
      trackToolUsage(toolId);
    }
    setActiveTool(toolId);
  }, [trackToolUsage]);

  const handleShareToSocials = (content: string) => {
    setSharedContent(content);
    handleSetActiveTool(ToolId.ContentManagement);
  };
  
  const clearSharedContent = () => {
    setSharedContent('');
  };

  // Add keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
        // Ignore shortcuts if a modal is open or if the user is typing in an input/textarea.
        if (document.querySelector('[role="dialog"]') || 
            (event.target instanceof HTMLInputElement) || 
            (event.target instanceof HTMLTextAreaElement)) {
            return;
        }

        if (event.altKey && SHORTCUT_KEY_MAP[event.key]) {
            event.preventDefault();
            const toolId = SHORTCUT_KEY_MAP[event.key];
            handleSetActiveTool(toolId);
        }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => {
        window.removeEventListener('keydown', handleKeyDown);
    };
  }, [handleSetActiveTool]);


  const renderActiveTool = () => {
    // Disable tools if API key is not set, show welcome screen
    if (!isKeySet) {
      return <WelcomeView />;
    }

    if (activeTool === null) {
        return <WelcomeView />;
    }

    const tool = TOOLS.find(t => t.id === activeTool);
    if (!tool) {
        return <WelcomeView />;
    }

    switch (tool.id) {
      case ToolId.Dashboard:
        return <DashboardView />;
      case ToolId.ContentWriting:
      case ToolId.Copywriting:
      case ToolId.CreativeWriting:
      case ToolId.SeoArticle:
      case ToolId.IdeaGenerator:
      case ToolId.ImageAnalysis:
        return <GenericTextView key={tool.id} tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.SupplyChainManagement:
        return <SupplyChainView tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.WarehousingManagement:
        return <WarehousingView tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.CustomerSupport:
        return <CustomerSupportView tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.EmailMarketing:
        return <EmailMarketingView tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.ContentManagement:
        return <ContentManagerView tool={tool} sharedContent={sharedContent} clearSharedContent={clearSharedContent} />;
      case ToolId.AdsManagement:
        return <AdsManagerView tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.BookPublishing:
        return <BookPublishingView tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.TextEditing:
        return <TextEditorView tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.AcademicResearch:
        return <SearchView tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.LocalDiscovery:
        return <LocalDiscoveryView tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.EbookReader:
        return <EbookReaderView tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.CodeDocumentation:
        return <CodeDocumentationView tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.UtmSettings:
        return <UTMSettingsView tool={tool} />;
      case ToolId.PhotoGenerator:
        return <ImageGeneratorView tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.AnimationGenerator:
        return <AnimationGeneratorView tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.VideoGenerator:
        return <VideoGeneratorView tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.VideoAnalysis:
        return <VideoAnalysisView tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.PaintingTools:
        return <ImageEditorView tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.AudioGenerator:
        return <AudioGeneratorView tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.AudioTranscription:
        return <AudioTranscriptionView tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.LiveChat:
        return <LiveChatView tool={tool} onShareToSocials={handleShareToSocials} />;
      case ToolId.ProjectManagement:
        return <ProjectManagerView tool={tool} />;
      case ToolId.MyBlog:
        return <BlogView tool={tool} />;
      case ToolId.CommunityFeed:
        return <FeedView tool={tool} />;
      case ToolId.Chatbot:
        return <ChatbotView tool={tool} />;
      default:
        return <WelcomeView />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-100 dark:bg-slate-900 font-sans">
      <Sidebar activeTool={activeTool} setActiveTool={handleSetActiveTool} />
      <div className="flex flex-col flex-1 h-screen">
          <Header activeTool={activeTool} />
          <main className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8 bg-slate-200/50 dark:bg-slate-800/50">
          <div key={activeTool} className="animate-fadeIn">
              {renderActiveTool()}
          </div>
          </main>
      </div>
    </div>
  );
}

const AppGate: React.FC = () => {
    const { isKeySet, openModal } = useGemini();
    
    // Automatically open the modal on initial load if the key is not set.
    useEffect(() => {
        if (!isKeySet) {
            openModal();
        }
    }, [isKeySet, openModal]);
    
    return (
        <>
            <ApiKeyModal />
            <AppContent />
        </>
    )
}

const Root: React.FC = () => {
    const { currentUser, isLoading } = useAuth();
    
    if (isLoading) {
        return (
            <div className="flex h-screen w-full items-center justify-center bg-slate-100 dark:bg-slate-900">
                <LoadingSpinner className="h-12 w-12" />
            </div>
        );
    }

    if (currentUser) {
        return (
             <GeminiProvider>
              <AnalyticsProvider>
                <UTMProvider>
                    <AppGate />
                </UTMProvider>
              </AnalyticsProvider>
            </GeminiProvider>
        );
    } else {
        return <AuthView />;
    }
}

const App: React.FC = () => {
    return (
        <AuthProvider>
            <ThemeProvider>
              <LanguageProvider>
                  <Root />
              </LanguageProvider>
            </ThemeProvider>
        </AuthProvider>
    );
}

export default App;