import React, { useState, useCallback, useRef, useEffect } from 'react';
import type { Tool } from '../types';
import { generateWithSearch, SearchResult } from '../services/geminiService';
import { parseFileForText } from '../utils/fileParsers';
import LoadingSpinner from '../components/LoadingSpinner';
import SearchResultDisplay from '../components/SearchResultDisplay';
import HistoryPanel from '../components/HistoryPanel';
import { useHistory } from '../hooks/useHistory';
import { useGemini } from '../contexts/GeminiContext';
import { useLanguage } from '../contexts/LanguageContext';

interface SearchViewProps {
  tool: Tool;
  onShareToSocials: (content: string) => void;
}

type SearchSource = 'general' | 'scholar' | 'journals';

const SearchView: React.FC<SearchViewProps> = ({ tool, onShareToSocials }) => {
  const { aiInstance } = useGemini();
  const { uiLang, t } = useLanguage();
  const [prompt, setPrompt] = useState('');
  const [imageAttachment, setImageAttachment] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [documentAttachment, setDocumentAttachment] = useState<File | null>(null);
  const [extractedText, setExtractedText] = useState<string | null>(null);
  const [isParsing, setIsParsing] = useState(false);
  const [searchSource, setSearchSource] = useState<SearchSource>('general');

  const [result, setResult] = useState<SearchResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { history, addHistoryItem, clearHistory } = useHistory(`history_${tool.id}`);

  useEffect(() => {
    return () => {
      if (imagePreview) {
        URL.revokeObjectURL(imagePreview);
      }
    };
  }, [imagePreview]);

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    handleRemoveAttachment();
    setError('');

    if (file.type.startsWith('image/')) {
      setImageAttachment(file);
      setImagePreview(URL.createObjectURL(file));
    } else {
      setDocumentAttachment(file);
      setIsParsing(true);
      try {
        const text = await parseFileForText(file);
        setExtractedText(text);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Gagal memparsing fail.');
        handleRemoveAttachment();
      } finally {
        setIsParsing(false);
      }
    }
  };

  const handleRemoveAttachment = () => {
    if (imagePreview) {
      URL.revokeObjectURL(imagePreview);
    }
    setImageAttachment(null);
    setImagePreview(null);
    setDocumentAttachment(null);
    setExtractedText(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };


  const handleGenerate = useCallback(async () => {
    if (!aiInstance) {
      setError('Sila tetapkan Kunci API Gemini anda dalam pengepala.');
      return;
    }
    if (!prompt.trim()) {
      setError('Sila masukkan pertanyaan carian.');
      return;
    }
    setIsLoading(true);
    setError('');
    setResult(null);
    addHistoryItem(prompt);

    let finalPrompt = prompt;
    switch (searchSource) {
        case 'scholar':
            finalPrompt = `Using Google Scholar, find academic papers, theses, and articles about: "${prompt}". Provide a comprehensive summary and cite your sources.`;
            break;
        case 'journals':
            finalPrompt = `Search academic journals (like Scopus, PubMed, ArXiv) for peer-reviewed papers on: "${prompt}". Summarize the key findings and methodologies.`;
            break;
        default:
            finalPrompt = prompt; // Use the original prompt for general search
            break;
    }

    try {
      const instruction = tool.systemInstruction ? tool.systemInstruction[uiLang] : undefined;
      const searchResult = await generateWithSearch(aiInstance, finalPrompt, instruction, imageAttachment, extractedText);
      setResult(searchResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [prompt, tool.systemInstruction, addHistoryItem, imageAttachment, extractedText, aiInstance, uiLang, searchSource]);
  
  const handleHistorySelect = (selectedPrompt: string) => {
    setPrompt(selectedPrompt);
  };

  const searchSources: { id: SearchSource; label: string }[] = [
      { id: 'general', label: t('tools.academic_research.sourceGeneral') },
      { id: 'scholar', label: t('tools.academic_research.sourceScholar') },
      { id: 'journals', label: t('tools.academic_research.sourceJournals') },
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
        <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
            {t('tools.academic_research.sourceLabel')}
          </label>
          <div className="flex flex-col sm:flex-row gap-2 rounded-lg bg-slate-100 dark:bg-slate-700/50 p-1">
            {searchSources.map(source => (
                <button
                  key={source.id}
                  onClick={() => setSearchSource(source.id as SearchSource)}
                  className={`flex-1 py-2 px-3 text-sm font-semibold rounded-md transition-colors text-center ${searchSource === source.id ? 'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'}`}
                >
                  {source.label}
                </button>
            ))}
          </div>
        </div>
        <div>
          <label htmlFor="prompt" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
            Pertanyaan Penyelidikan Anda
          </label>
          <textarea
            id="prompt"
            rows={3}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-3 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
            placeholder={`cth., Apakah kesan rantaian bekalan logistik terhadap pelepasan karbon?`}
          />
          <p className="text-xs text-slate-500 dark:text-slate-500 mt-2">Sila pastikan gesaan anda mematuhi garis panduan kandungan yang selamat untuk mengelakkan hasil yang tidak diingini.</p>
        </div>
        
        <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">
                Lampirkan Fail untuk Konteks (Pilihan)
            </label>
            <div className="flex items-center gap-4">
                <input type="file" accept="image/*,.pdf,.docx,.txt" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
                <button onClick={() => fileInputRef.current?.click()} className="flex items-center justify-center bg-slate-200 hover:bg-slate-300 text-slate-700 dark:bg-slate-600 dark:hover:bg-slate-500 dark:text-white font-medium py-2 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">
                     <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
                    Pilih Fail
                </button>
                 {(imageAttachment || documentAttachment) && (
                    <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-700 pl-3 rounded-full">
                         <span className="text-slate-600 dark:text-slate-300 text-sm truncate max-w-xs">{imageAttachment?.name || documentAttachment?.name}</span>
                        <button onClick={handleRemoveAttachment} className="text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white p-1.5 rounded-full transition-transform hover:scale-110" aria-label="Remove attachment">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                        </button>
                    </div>
                )}
            </div>
             {isParsing && (
                 <div className="flex items-center text-sm text-slate-500 dark:text-slate-400 mt-2">
                    <LoadingSpinner className="w-4 h-4 mr-2" />
                    <span>Memparsing dokumen...</span>
                </div>
            )}
             {imagePreview && (
                <div className="mt-2 bg-slate-200/50 dark:bg-slate-900/50 p-2 rounded-lg inline-block">
                    <img src={imagePreview} alt="Preview" className="max-h-32 w-auto rounded-md" />
                </div>
            )}
        </div>

        <HistoryPanel history={history} onSelect={handleHistorySelect} onClear={clearHistory} />

        <button
          onClick={handleGenerate}
          disabled={isLoading || isParsing || !aiInstance}
          className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
        >
          {isLoading ? <LoadingSpinner /> : 'Penyelidikan'}
        </button>

        {error && <p className="text-red-500 dark:text-red-400 text-center">{error}</p>}
      </div>

       <div className="mt-8">
            <SearchResultDisplay
                isLoading={isLoading}
                result={result}
                error={error}
                toolName={t(tool.nameKey)}
                onShareToSocials={onShareToSocials}
            />
        </div>
    </div>
  );
};

export default SearchView;