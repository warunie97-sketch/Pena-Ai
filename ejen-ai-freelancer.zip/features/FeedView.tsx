import React, { useState, useMemo } from 'react';
import type { Tool, Post, PostCategory } from '../types';
import { usePosts } from '../hooks/usePosts';
import { useAuth } from '../contexts/AuthContext';
import FeedPostCard from '../components/FeedPostCard';
import PostEditorModal from '../components/PostEditorModal';
import { useLanguage } from '../contexts/LanguageContext';

interface FeedViewProps {
  tool: Tool;
}

const FeedView: React.FC<FeedViewProps> = ({ tool }) => {
  const { posts, addPost, updatePost, deletePost } = usePosts('community_feed_posts');
  const { currentUser } = useAuth();
  const { t } = useLanguage();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPost, setEditingPost] = useState<Post | null>(null);

  const handleOpenModalForCreate = () => {
    setEditingPost(null);
    setIsModalOpen(true);
  };

  const handleOpenModalForEdit = (post: Post) => {
    setEditingPost(post);
    setIsModalOpen(true);
  };
  
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingPost(null);
  }

  // FIX: Update handleSavePost to match the new signature of PostEditorModal's onSave prop.
  const handleSavePost = (postData: { title: string; content: string; category?: PostCategory }, postId?: string) => {
    if (!currentUser || !postData.category) return;

    const saveData = {
        title: postData.title,
        content: postData.content,
        category: postData.category,
    };

    if (postId && editingPost) {
      updatePost({ ...editingPost, ...saveData });
    } else {
      addPost({ ...saveData, authorId: currentUser.id });
    }
    handleCloseModal();
  };

  const handleDeletePost = (postId: string) => {
      if (window.confirm('Adakah anda pasti mahu memadamkan catatan ini? Tindakan ini tidak boleh dibuat asal.')) {
        deletePost(postId);
      }
  };

  const groupedPosts = useMemo(() => {
    // FIX: Add a check for post.category since it's now optional on the Post type.
    return posts.reduce((acc, post) => {
        if (post.category) {
            (acc[post.category] = acc[post.category] || []).push(post);
        }
        return acc;
    }, {} as Record<PostCategory, Post[]>);
  }, [posts]);

  const categoryOrder: PostCategory[] = ['Puisi', 'Cerpen', 'Esei', 'Novel'];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6 flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
          <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
        </div>
        <button
          onClick={handleOpenModalForCreate}
          className="flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L15.232 5.232z" /></svg>
          Tulis Catatan Baru
        </button>
      </div>

      {posts.length > 0 ? (
        <div className="space-y-8">
            {categoryOrder.map(category => (
                groupedPosts[category] && (
                    <div key={category}>
                        <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-4 border-b-2 border-slate-200 dark:border-slate-700 pb-2">{category}</h3>
                        <div className="space-y-6">
                            {groupedPosts[category].map(post => (
                                <FeedPostCard 
                                    key={post.id} 
                                    post={post}
                                    currentUser={currentUser}
                                    onEdit={() => handleOpenModalForEdit(post)}
                                    onDelete={() => handleDeletePost(post.id)}
                                />
                            ))}
                        </div>
                    </div>
                )
            ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-white dark:bg-slate-800/50 rounded-lg">
          <h3 className="text-xl font-semibold text-slate-900 dark:text-white">Tiada catatan dalam suapan lagi.</h3>
          <p className="text-slate-500 dark:text-slate-400 mt-2">Jadilah yang pertama untuk menerbitkan sesuatu!</p>
        </div>
      )}

      <PostEditorModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onSave={handleSavePost}
        post={editingPost}
        // FIX: Add showCategorySelector to enable the category field in the modal for this view.
        showCategorySelector={true}
      />
    </div>
  );
};

export default FeedView;