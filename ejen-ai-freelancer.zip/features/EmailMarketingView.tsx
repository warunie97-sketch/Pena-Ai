import React, { useState, useCallback, useEffect } from 'react';
import type { Tool } from '../types';
import { generateText } from '../services/geminiService';
import LoadingSpinner from '../components/LoadingSpinner';
import TranslationWidget from '../components/TranslationWidget';
import WordCount from '../components/WordCount';
import { useGemini } from '../contexts/GeminiContext';
import MarkdownRenderer from '../components/MarkdownRenderer';
import { useLanguage } from '../contexts/LanguageContext';

interface EmailMarketingViewProps {
  tool: Tool;
  onShareToSocials: (content: string) => void;
}

const TEMPLATES = [
  {
    id: 'newsletter',
    name: 'Surat Berita',
    description: 'Kongsi kemas kini, artikel, atau berita dengan audiens anda.',
    variables: [
      { id: 'mainHeadline', label: 'Tajuk Utama Surat Berita', placeholder: 'Kemas Kini Terkini dari [Syarikat Anda]' },
      { id: 'introduction', label: 'Pengenalan Ringkas', type: 'textarea', placeholder: 'Satu atau dua ayat untuk menarik minat pembaca.' },
      { id: 'section1Title', label: 'Tajuk Bahagian 1', placeholder: 'Sorotan Produk Bulan Ini' },
      { id: 'section1Content', label: 'Kandungan Bahagian 1', type: 'textarea', placeholder: 'Perihalan terperinci tentang sorotan atau artikel pertama.' },
      { id: 'callToAction', label: 'Seruan Tindak', placeholder: 'Baca Lagi di Blog Kami' },
    ],
    template: (vars: Record<string, string>) => `
**Subjek: ${vars.mainHeadline || '[Tajuk Utama Surat Berita]'}**

Hai [Nama Pelanggan],

${vars.introduction || '[Pengenalan ringkas di sini]'}

### ${vars.section1Title || '[Tajuk Bahagian 1]'}

${vars.section1Content || '[Kandungan terperinci untuk bahagian 1 di sini.]'}

[Masukkan lebih banyak bahagian seperti yang diperlukan...]

**${vars.callToAction || '[Seruan Tindak]'}**

Terima kasih,
[Nama Syarikat Anda]
`
  },
  {
    id: 'promotion',
    name: 'Tawaran Promosi',
    description: 'Umumkan jualan, diskaun, atau tawaran istimewa.',
    variables: [
      { id: 'productName', label: 'Nama Produk/Perkhidmatan', placeholder: 'cth., Koleksi Musim Bunga Kami' },
      { id: 'discount', label: 'Butiran Diskaun', placeholder: 'cth., Diskaun 30% untuk semua item' },
      { id: 'promoCode', label: 'Kod Promo (Pilihan)', placeholder: 'cth., MUSIMBUNGA30' },
      { id: 'endDate', label: 'Tarikh Tamat Tawaran', placeholder: 'cth., 31 Mac' },
      { id: 'callToAction', label: 'Seruan Tindak', placeholder: 'Beli Sekarang dan Jimat!' },
    ],
    template: (vars: Record<string, string>) => `
**Subjek: Tawaran Istimewa! ${vars.discount || '[Diskaun]'} untuk ${vars.productName || '[Nama Produk]'}**

Hai [Nama Pelanggan],

Jangan lepaskan peluang! Dapatkan **${vars.discount || '[diskaun]'}** untuk ${vars.productName || '[nama produk]'} kami untuk masa yang terhad.

${vars.promoCode ? `Gunakan kod **${vars.promoCode}** semasa pembayaran.` : ''}

Tawaran ini akan berakhir pada ${vars.endDate || '[tarikh tamat]'}.

**${vars.callToAction || '[Seruan Tindak]'}**

Selamat membeli-belah,
[Nama Syarikat Anda]
`
  },
  {
    id: 'announcement',
    name: 'Pengumuman',
    description: 'Maklumkan kepada pelanggan tentang produk baru, ciri, atau acara akan datang.',
    variables: [
      { id: 'announcementTitle', label: 'Tajuk Pengumuman', placeholder: 'cth., Memperkenalkan [Produk/Ciri] Baru Kami!' },
      { id: 'details', label: 'Butiran Pengumuman', type: 'textarea', placeholder: 'Terangkan apa yang baru dan mengapa ia menarik.' },
      { id: 'callToAction', label: 'Seruan Tindak', placeholder: 'Ketahui Lebih Lanjut' },
    ],
    template: (vars: Record<string, string>) => `
**Subjek: Pengumuman Menarik: ${vars.announcementTitle || '[Tajuk Pengumuman]'}**

Hai [Nama Pelanggan],

Kami sangat teruja untuk mengumumkan sesuatu yang baru!

${vars.details || '[Butiran terperinci tentang pengumuman di sini.]'}

Kami tidak sabar untuk anda mencubanya.

**${vars.callToAction || '[Seruan Tindak]'}**

Yang benar,
Pasukan [Nama Syarikat Anda]
`
  },
];

const PREDEFINED_TONES = ['Profesional', 'Santai', 'Jenaka', 'Formal'];

const EmailMarketingView: React.FC<EmailMarketingViewProps> = ({ tool, onShareToSocials }) => {
  const { aiInstance } = useGemini();
  const { uiLang, t } = useLanguage();
  
  const [activeTemplateId, setActiveTemplateId] = useState(TEMPLATES[0].id);
  const [variables, setVariables] = useState<Record<string, string>>({});
  const [prompt, setPrompt] =useState('');
  
  const [result, setResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  // State for tone changing in the result section
  const [tone, setTone] = useState('');
  const [isChangingTone, setIsChangingTone] = useState(false);
  const [toneError, setToneError] = useState('');
  const [suggestedTones, setSuggestedTones] = useState<string[]>([]);
  const [isSuggestingTones, setIsSuggestingTones] = useState(false);
  
  const activeTemplate = TEMPLATES.find(t => t.id === activeTemplateId) || TEMPLATES[0];

  useEffect(() => {
      // Reset variables when template changes
      setVariables({});
  }, [activeTemplateId]);

  useEffect(() => {
      // Update prompt whenever variables or template change
      const newPrompt = activeTemplate.template(variables);
      setPrompt(newPrompt);
  }, [variables, activeTemplate]);

  const handleVariableChange = (id: string, value: string) => {
    setVariables(prev => ({ ...prev, [id]: value }));
  };

  const handleGenerate = useCallback(async () => {
    if (!aiInstance) {
      setError('Sila tetapkan Kunci API Gemini anda dalam pengepala.');
      return;
    }
    const hasEmptyRequiredFields = activeTemplate.variables.some(v => !variables[v.id] && v.type !== 'textarea');
    if (hasEmptyRequiredFields) {
        setError('Sila isi semua medan yang diperlukan untuk templat.');
        return;
    }
    
    setIsLoading(true);
    setError('');
    setResult('');

    try {
      const instruction = tool.systemInstruction ? tool.systemInstruction[uiLang] : undefined;
      const generatedText = await generateText(aiInstance, prompt, instruction);
      setResult(generatedText);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [prompt, tool.systemInstruction, variables, activeTemplate, aiInstance, uiLang]);

  const handleChangeTone = useCallback(async () => {
    if (!aiInstance) {
      setToneError('Sila tetapkan Kunci API Gemini anda.');
      return;
    }
    if (!result) {
      setToneError('Tiada hasil untuk diubah nadanya.');
      return;
    }
    if (!tone.trim()) {
      setToneError('Sila masukkan nada yang diingini.');
      return;
    }

    setIsChangingTone(true);
    setToneError('');

    const toneChangePrompt = `Anda adalah seorang pakar linguistik. Ubah nada teks berikut kepada "${tone}" sambil mengekalkan makna asalnya. Pastikan teks akhir adalah dalam Bahasa Malaysia.
Berikan jawapan anda dalam DUA bahagian:
1. **TEKS DIUBAH NADA**: Kembalikan versi teks yang bersih dan telah diubah nada sepenuhnya.
2. **ANALISIS PERUBAHAN**: Selepas teks yang diubah, sediakan senarai terperinci bagi setiap perubahan ketara yang dibuat untuk mencapai nada baharu. Bagi setiap perubahan, gunakan format berikut:
    - **Asal:** "[petik ayat atau frasa asal]"
    - **Diubah:** "[tunjukkan ayat atau frasa yang telah diubah]"
    - **Sebab:** "[jelaskan secara ringkas tujuan perubahan (cth., 'Menggantikan perkataan formal dengan sinonim yang lebih santai', 'Mengubah struktur ayat untuk bunyi yang lebih berjenaka', 'Menambah kata-kata sopan untuk nada profesional')]"

Teks asal:
"""
${result}
"""`;
    
    try {
      const newResult = await generateText(aiInstance, toneChangePrompt);
      setResult(newResult);
    } catch (err) {
      setToneError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    } finally {
      setIsChangingTone(false);
    }
  }, [result, tone, aiInstance]);

  const handleSuggestTones = useCallback(async () => {
    if (!aiInstance) {
        setToneError('Sila tetapkan Kunci API Gemini anda.');
        return;
    }
    if (!result) {
        setToneError('Tiada hasil untuk dianalisis.');
        return;
    }
    setIsSuggestingTones(true);
    setToneError('');
    setSuggestedTones([]);

    const suggestPrompt = `You are a linguistic expert. Analyze the following text and suggest 3-5 alternative tones that would be appropriate for it. For each tone, provide a brief one-word or two-word label. Respond ONLY with a JSON array of strings. The labels should be in Bahasa Malaysia.

    Example response: ["Lebih Meyakinkan", "Formal", "Jenaka", "Empati", "Ringkas"]

    Text to analyze:
    """
    ${result}
    """`;
    
    try {
        const response = await generateText(aiInstance, suggestPrompt);
        const cleanedResponse = response.replace(/```json\n?/, '').replace(/```$/, '').trim();
        const tonesArray = JSON.parse(cleanedResponse);
        if (Array.isArray(tonesArray)) {
            setSuggestedTones(tonesArray);
        }
    } catch (err) {
        setToneError('Gagal mencadangkan nada.');
        console.error(err);
    } finally {
        setIsSuggestingTones(false);
    }
  }, [result, aiInstance]);


  const handleCopy = () => {
    navigator.clipboard.writeText(result);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
        <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Input Panel */}
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Pilih Templat</label>
            <div className="flex flex-col sm:flex-row gap-2 rounded-lg bg-slate-100 dark:bg-slate-700/50 p-1">
              {TEMPLATES.map(template => (
                <button
                  key={template.id}
                  onClick={() => setActiveTemplateId(template.id)}
                  className={`flex-1 py-2 px-3 text-sm font-semibold rounded-md transition-colors text-center ${activeTemplateId === template.id ? 'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'}`}
                >
                  {template.name}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-white dark:bg-slate-800/50 p-4 rounded-lg space-y-4">
            <h3 className="text-lg font-semibold text-slate-900 dark:text-white">{activeTemplate.name} Details</h3>
            {activeTemplate.variables.map(variable => (
              <div key={variable.id}>
                <label htmlFor={variable.id} className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{variable.label}</label>
                {variable.type === 'textarea' ? (
                  <textarea
                    id={variable.id}
                    rows={3}
                    value={variables[variable.id] || ''}
                    onChange={e => handleVariableChange(variable.id, e.target.value)}
                    className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                    placeholder={variable.placeholder}
                  />
                ) : (
                  <input
                    id={variable.id}
                    type="text"
                    value={variables[variable.id] || ''}
                    onChange={e => handleVariableChange(variable.id, e.target.value)}
                    className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                    placeholder={variable.placeholder}
                  />
                )}
              </div>
            ))}
          </div>

          <button
            onClick={handleGenerate}
            disabled={isLoading || !aiInstance}
            className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
          >
            {isLoading ? <LoadingSpinner /> : 'Jana E-mel'}
          </button>
          <p className="text-xs text-slate-500 dark:text-slate-500 text-center">AI akan mengembangkan input anda menjadi e-mel yang digilap berdasarkan templat yang dipilih.</p>
          {error && <p className="text-red-500 dark:text-red-400 text-center">{error}</p>}
        </div>

        {/* Result Panel */}
        <div className="space-y-4">
           <h3 className="text-lg font-semibold text-slate-900 dark:text-white">Hasil E-mel</h3>
           <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg min-h-[300px]">
                {isLoading ? (
                    <div className="flex flex-col items-center justify-center h-full p-6">
                        <LoadingSpinner className="w-8 h-8 text-blue-500" />
                        <p className="mt-4 text-slate-500 dark:text-slate-400">Menulis e-mel anda...</p>
                    </div>
                ) : result ? (
                     <div className="h-full">
                        <div className="flex justify-between items-center p-4 border-b border-slate-200 dark:border-slate-700">
                            <h4 className="text-lg font-semibold text-slate-900 dark:text-white">Pratonton</h4>
                            <div className="flex items-center gap-2">
                            <button onClick={() => onShareToSocials(result)} title="Hantar ke Pengurus Kandungan" className="text-sm bg-purple-600 hover:bg-purple-500 text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">Hantar</button>
                            <button onClick={handleCopy} className="text-sm bg-slate-200 dark:bg-slate-600 hover:bg-slate-300 dark:hover:bg-slate-500 text-slate-700 dark:text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">Salin</button>
                            </div>
                        </div>
                        <div className="p-6">
                            <MarkdownRenderer content={result} />
                            <WordCount text={result} />
                            <TranslationWidget textToTranslate={result} />
                            <div className="mt-6 pt-6 border-t border-slate-200 dark:border-slate-700">
                                <h4 className="text-lg font-semibold text-slate-900 dark:text-white mb-3">Tukar Nada Hasil</h4>
                                <div className="space-y-4 sm:flex sm:gap-4 sm:items-end">
                                    <div className="flex-grow">
                                        <label htmlFor="tone-input-result" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                                            Nada Baharu
                                        </label>
                                        <input
                                            id="tone-input-result"
                                            type="text"
                                            value={tone}
                                            onChange={(e) => setTone(e.target.value)}
                                            className="w-full bg-slate-100 dark:bg-slate-900/50 border border-slate-300 dark:border-slate-600 rounded-md p-3 text-slate-900 dark:text-white"
                                            placeholder="cth., formal, santai, lucu, profesional"
                                        />
                                        <div className="flex flex-wrap gap-2 mt-2">
                                            {PREDEFINED_TONES.map(toneItem => (
                                                <button type="button" key={toneItem} onClick={() => setTone(toneItem)} className="text-xs bg-slate-200 dark:bg-slate-600 hover:bg-slate-300 dark:hover:bg-slate-500 text-slate-700 dark:text-white font-medium py-1 px-3 rounded-full transition-colors">
                                                {toneItem}
                                                </button>
                                            ))}
                                        </div>
                                    </div>
                                    <button
                                        onClick={handleChangeTone}
                                        disabled={isChangingTone || !aiInstance}
                                        className="w-full sm:w-auto flex-shrink-0 flex items-center justify-center bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-3 px-6 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
                                    >
                                        {isChangingTone ? <LoadingSpinner /> : 'Gunakan Nada'}
                                    </button>
                                </div>
                                <div className="mt-4 flex items-center flex-wrap gap-2">
                                    <button type="button" onClick={handleSuggestTones} disabled={isSuggestingTones || !result || !aiInstance} className="text-xs flex items-center gap-1.5 bg-slate-200 dark:bg-slate-600 hover:bg-slate-300 dark:hover:bg-slate-500 text-slate-700 dark:text-white font-medium py-1 px-3 rounded-full transition-colors disabled:opacity-50">
                                        {isSuggestingTones ? <LoadingSpinner className="w-4 h-4" /> : <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3v.01"/><path d="M16.2 3.8v.01"/><path d="M20.2 7.8v.01"/><path d="M21 12v.01"/><path d="M20.2 16.2v.01"/><path d="M16.2 20.2v.01"/><path d="M12 21v.01"/><path d="M7.8 20.2v.01"/><path d="M3.8 16.2v.01"/><path d="M3 12v.01"/><path d="M3.8 7.8v.01"/><path d="M7.8 3.8v.01"/></svg>}
                                        Cadangkan Nada
                                    </button>
                                    {suggestedTones.map(suggestedTone => (
                                        <button
                                            type="button"
                                            key={suggestedTone}
                                            onClick={() => setTone(suggestedTone)}
                                            className="text-xs bg-purple-200 dark:bg-purple-900/50 hover:bg-purple-300 dark:hover:bg-purple-800/50 text-purple-800 dark:text-purple-200 font-medium py-1 px-3 rounded-full transition-colors"
                                        >
                                            {suggestedTone} ✨
                                        </button>
                                    ))}
                                </div>
                                {toneError && <p className="text-red-500 dark:text-red-400 text-center mt-2">{toneError}</p>}
                            </div>
                        </div>
                    </div>
                ) : (
                    <div className="flex items-center justify-center h-full p-6">
                        <p className="text-slate-500 dark:text-slate-400">Hasil e-mel anda akan muncul di sini.</p>
                    </div>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default EmailMarketingView;