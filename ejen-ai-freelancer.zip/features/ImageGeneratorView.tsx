import React, { useState, useCallback, useRef, useEffect } from 'react';
import type { Tool } from '../types';
import { generateImage } from '../services/geminiService';
import LoadingSpinner from '../components/LoadingSpinner';
import HistoryPanel from '../components/HistoryPanel';
import { useHistory } from '../hooks/useHistory';
import { useGemini } from '../contexts/GeminiContext';
import { useLanguage } from '../contexts/LanguageContext';

interface ImageGeneratorViewProps {
  tool: Tool;
  onShareToSocials: (content: string) => void;
}

const ASPECT_RATIOS = [
    { value: '1:1', label: 'Segi Empat Sama (1:1)' },
    { value: '16:9', label: 'Skrin Lebar (16:9)' },
    { value: '9:16', label: 'Potret (9:16)' },
    { value: '4:3', label: 'Landskap (4:3)' },
    { value: '3:4', label: 'Potret (3:4)' },
];

interface CliOutputItem {
  id: number;
  command: string;
  status: 'pending' | 'success' | 'error';
  result?: { imageUrls: string[], enhancedPrompt: string };
  error?: string;
}


const ImageGeneratorView: React.FC<ImageGeneratorViewProps> = ({ tool, onShareToSocials }) => {
  const { aiInstance } = useGemini();
  const { t } = useLanguage();

  // Shared state
  const [error, setError] = useState('');
  const [mode, setMode] = useState<'ui' | 'cli'>('ui');
  
  // UI Mode State
  const [idea, setIdea] = useState('');
  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const [enhancedPrompt, setEnhancedPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [promptCopied, setPromptCopied] = useState(false);
  const { history, addHistoryItem, clearHistory } = useHistory(`history_${tool.id}`);
  const [imageAttachment, setImageAttachment] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const imageFileInputRef = useRef<HTMLInputElement>(null);
  const [aspectRatio, setAspectRatio] = useState('1:1');
  const [numberOfImages, setNumberOfImages] = useState(1);

  // CLI Mode State
  const [cliCommands, setCliCommands] = useState('generate --prompt "kucing memakai topi fedora" --n 2 --aspect 1:1');
  const [cliOutput, setCliOutput] = useState<CliOutputItem[]>([]);
  const [isCliRunning, setIsCliRunning] = useState(false);


  useEffect(() => {
    return () => {
      if (imagePreview) URL.revokeObjectURL(imagePreview);
      imageUrls.forEach(url => URL.revokeObjectURL(url));
      cliOutput.forEach(item => item.result?.imageUrls.forEach(url => URL.revokeObjectURL(url)));
    };
  }, [imagePreview, imageUrls, cliOutput]);

  const handleImageFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      if (imagePreview) {
        URL.revokeObjectURL(imagePreview);
      }
      setImageAttachment(file);
      setImagePreview(URL.createObjectURL(file));
      setError('');
    } else if (file) {
      setError('Sila pilih fail imej yang sah.');
    }
  };

  const handleRemoveImageAttachment = () => {
    if (imagePreview) {
      URL.revokeObjectURL(imagePreview);
    }
    setImageAttachment(null);
    setImagePreview(null);
    if (imageFileInputRef.current) {
      imageFileInputRef.current.value = '';
    }
  };

  const handleGenerate = useCallback(async () => {
    if (!aiInstance) {
        setError('Sila tetapkan Kunci API Gemini anda dalam pengepala.');
        return;
    }
    if (!idea.trim()) {
      setError('Sila masukkan idea untuk imej.');
      return;
    }
    setIsLoading(true);
    setError('');
    setImageUrls([]);
    setEnhancedPrompt('');
    addHistoryItem(idea);
    try {
      const result = await generateImage(aiInstance, idea, imageAttachment, numberOfImages, aspectRatio);
      setImageUrls(result.imageUrls);
      setEnhancedPrompt(result.enhancedPrompt);

    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [idea, imageAttachment, numberOfImages, aspectRatio, addHistoryItem, aiInstance]);

  const parseCliCommand = (command: string): { prompt: string; n: number; aspect: string } => {
    const promptMatch = command.match(/--prompt "([^"]+)"/);
    const nMatch = command.match(/--n (\d+)/);
    const aspectMatch = command.match(/--aspect ([\d:]+)/);

    const prompt = promptMatch ? promptMatch[1] : '';
    const n = nMatch ? parseInt(nMatch[1], 10) : 1;
    const aspect = aspectMatch ? aspectMatch[1] : '1:1';

    if (!prompt) throw new Error('Parameter --prompt "..." diperlukan.');
    
    return { prompt, n: Math.max(1, Math.min(4, n)), aspect };
  };

  const handleRunCli = async () => {
    if (!aiInstance) {
        setError('Sila tetapkan Kunci API Gemini anda dalam pengepala.');
        return;
    }
    setIsCliRunning(true);
    setError('');
    setCliOutput([]);

    const commands = cliCommands.split('\n').filter(cmd => cmd.trim().startsWith('generate'));

    const initialOutput: CliOutputItem[] = commands.map((cmd, index) => ({
        id: index,
        command: cmd,
        status: 'pending',
    }));
    setCliOutput(initialOutput);

    for (let i = 0; i < commands.length; i++) {
        const command = commands[i];
        try {
            const { prompt, n, aspect } = parseCliCommand(command);
            const result = await generateImage(aiInstance, prompt, null, n, aspect);
            setCliOutput(prev => prev.map(item => item.id === i ? { ...item, status: 'success', result } : item));
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'Ralat tidak diketahui';
            setCliOutput(prev => prev.map(item => item.id === i ? { ...item, status: 'error', error: errorMessage } : item));
        }
    }

    setIsCliRunning(false);
  };


  const handleDownload = (url: string, index: number) => {
    const link = document.createElement('a');
    link.href = url;
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    link.download = `EjenAI_Imej_${timestamp}_${index + 1}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleShareImage = async (url: string, shareText: string) => {
    try {
        const response = await fetch(url);
        const blob = await response.blob();
        const file = new File([blob], 'ejen-ai-image.png', { type: blob.type });

        if (navigator.share && navigator.canShare({ files: [file] })) {
            await navigator.share({
                files: [file],
                title: 'Imej Dijana AI',
                text: shareText,
            });
        } else {
            // Fallback for desktop or unsupported browsers
            await navigator.clipboard.writeText(url);
            alert('Perkongsian fail tidak disokong pada pelayar ini. Pautan imej telah disalin ke papan keratan.');
        }
    } catch (error) {
       if (error instanceof Error && !error.message.includes('Abort')) {
        console.error('Error sharing image:', error);
        alert('Gagal berkongsi imej.');
       }
    }
  };


  const handleCopyPrompt = () => {
    if (!enhancedPrompt) return;
    navigator.clipboard.writeText(enhancedPrompt);
    setPromptCopied(true);
    setTimeout(() => setPromptCopied(false), 2000);
  };

  const handleHistorySelect = (selectedIdea: string) => {
    setIdea(selectedIdea);
  };
  

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
        <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
      </div>

      <div className="flex justify-center bg-slate-200 dark:bg-slate-700/50 rounded-lg p-1 mb-6">
        <button
          onClick={() => setMode('ui')}
          className={`flex-1 py-2 px-4 rounded-md text-sm font-semibold transition-colors ${
            mode === 'ui' ? 'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-600'
          }`}
        >
          Mod UI
        </button>
        <button
          onClick={() => setMode('cli')}
          className={`flex-1 py-2 px-4 rounded-md text-sm font-semibold transition-colors ${
            mode === 'cli' ? 'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-600'
          }`}
        >
          Mod CLI
        </button>
      </div>

    {/* --- UI MODE --- */}
    {mode === 'ui' && (
      <div className="space-y-6 animate-fadeInUp">
        <div>
          <label htmlFor="idea-input" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Idea Anda</label>
          <input
            id="idea-input"
            type="text"
            value={idea}
            onChange={(e) => setIdea(e.target.value)}
            className="w-full bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-3 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
            placeholder="cth., Rakaman sinematik seekor rakun angkasawan di Marikh"
          />
          <p className="text-xs text-slate-500 dark:text-slate-500 mt-2">Sila pastikan gesaan anda mematuhi garis panduan kandungan yang selamat untuk mengelakkan hasil yang tidak diingini.</p>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">
            Imej Rujukan (Pilihan)
          </label>
          <p className="text-xs text-slate-500 dark:text-slate-500">
            AI akan cuba menyepadukan ciri-ciri dari imej ini (cth., wajah seseorang) ke dalam hasil akhir.
          </p>
          <div className="flex items-center gap-4">
            <input
              type="file"
              accept="image/*"
              ref={imageFileInputRef}
              onChange={handleImageFileChange}
              className="hidden"
            />
            <button
              onClick={() => imageFileInputRef.current?.click()}
              className="flex items-center justify-center bg-slate-200 hover:bg-slate-300 text-slate-700 dark:bg-slate-600 dark:hover:bg-slate-500 dark:text-white font-medium py-2 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
              Pilih Imej
            </button>
            {imageAttachment && (
              <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-700 pl-3 rounded-full">
                <span className="text-slate-600 dark:text-slate-300 text-sm truncate max-w-xs">{imageAttachment.name}</span>
                <button onClick={handleRemoveImageAttachment} className="text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white p-1.5 rounded-full transition-transform hover:scale-110" aria-label="Buang lampiran imej">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                </button>
              </div>
            )}
          </div>
          {imagePreview && (
            <div className="mt-2 bg-slate-200/50 dark:bg-slate-900/50 p-2 rounded-lg inline-block">
              <img src={imagePreview} alt="Image Preview" className="max-h-32 w-auto rounded-md" />
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
                <label htmlFor="aspect-ratio-select" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Nisbah Aspek</label>
                <select id="aspect-ratio-select" value={aspectRatio} onChange={(e) => setAspectRatio(e.target.value)} className="w-full bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-3 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500">
                    {ASPECT_RATIOS.map(ratio => <option key={ratio.value} value={ratio.value}>{ratio.label}</option>)}
                </select>
            </div>
            <div>
                <label htmlFor="num-images-input" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Bilangan Imej</label>
                <input id="num-images-input" type="number" value={numberOfImages} onChange={(e) => setNumberOfImages(Math.max(1, Math.min(4, parseInt(e.target.value) || 1)))} min="1" max="4" className="w-full bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-3 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500" />
            </div>
        </div>

        <HistoryPanel history={history} onSelect={handleHistorySelect} onClear={clearHistory} />

        <button
          onClick={handleGenerate}
          disabled={isLoading || !aiInstance}
          className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-3 px-6 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
        >
          {isLoading ? <LoadingSpinner /> : 'Jana'}
        </button>

        {error && <p className="text-red-500 dark:text-red-400 text-center">{error}</p>}
      </div>
     )}

    {/* --- CLI MODE --- */}
    {mode === 'cli' && (
        <div className="space-y-6 animate-fadeInUp">
            <div>
                <label htmlFor="cli-input" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Editor Perintah</label>
                 <textarea
                    id="cli-input"
                    rows={8}
                    value={cliCommands}
                    onChange={(e) => setCliCommands(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-600 rounded-md p-3 text-white font-mono text-sm focus:ring-2 focus:ring-blue-500"
                    placeholder={`generate --prompt "gesaan anda di sini" --n 1 --aspect 1:1`}
                />
            </div>
             <details className="bg-slate-100 dark:bg-slate-900/50 rounded-lg">
                <summary className="cursor-pointer p-3 text-sm font-medium text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white">Bantuan Perintah</summary>
                <div className="p-4 border-t border-slate-200 dark:border-slate-700 text-xs text-slate-500 dark:text-slate-400 space-y-2">
                    <p>Setiap baris mesti bermula dengan `generate`.</p>
                    <p><strong>Flags:</strong></p>
                    <ul className="list-disc list-inside pl-4">
                        <li>`--prompt "your prompt"`: (Diperlukan) Perihalan imej anda. Mesti dalam tanda petikan.</li>
                        <li>`--n [number]`: (Pilihan) Bilangan imej untuk dijana (1-4). Lalai: 1.</li>
                        <li>`--aspect [ratio]`: (Pilihan) Nisbah aspek. Pilihan: 1:1, 16:9, 9:16, 4:3, 3:4. Lalai: 1:1.</li>
                    </ul>
                    <p><strong>Contoh:</strong> `generate --prompt "robot sedang melayari di lautan digital" --n 2 --aspect 16:9`</p>
                </div>
            </details>
            <button
                onClick={handleRunCli}
                disabled={isCliRunning || !aiInstance}
                className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 dark:disabled:bg-slate-600 text-white font-bold py-3 px-4 rounded-md"
            >
                {isCliRunning ? <LoadingSpinner /> : 'Jalankan Perintah'}
            </button>
             {error && <p className="text-red-500 dark:text-red-400 text-center">{error}</p>}
        </div>
    )}

    {/* --- UI OUTPUT --- */}
      {mode === 'ui' && (
      <div className="mt-8">
        {isLoading && (
          <div className="flex flex-col items-center justify-center bg-white dark:bg-slate-800 aspect-square rounded-lg shadow-lg">
            <LoadingSpinner className="w-12 h-12 text-blue-500" />
            <p className="mt-4 text-slate-500 dark:text-slate-400">Menjana imej anda...</p>
          </div>
        )}
        {imageUrls.length > 0 && !isLoading && (
          <div className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-lg space-y-4">
              <div className="bg-slate-100 dark:bg-slate-900/50 p-3 rounded-md">
                  <div className="flex justify-between items-center mb-1">
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-semibold">Gesaan Dipertingkat Digunakan:</p>
                    <button
                      onClick={handleCopyPrompt}
                      className="text-xs bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-white font-medium py-1 px-2 rounded-md transition-all duration-200 hover:scale-105 active:scale-95 w-24 flex-shrink-0"
                    >
                      {promptCopied ? 'Disalin!' : 'Salin Gesaan'}
                    </button>
                  </div>
                  <p className="text-sm text-slate-700 dark:text-slate-300 italic">"{enhancedPrompt}"</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {imageUrls.map((url, index) => (
                    <div key={index} className="space-y-2">
                        <img src={url} alt={`${idea} - ${index + 1}`} className="w-full h-auto rounded-md" />
                        <div className="flex items-center justify-center gap-2">
                            <button onClick={() => onShareToSocials(enhancedPrompt)} title="Hantar ke Pengurus Kandungan" className="flex-1 flex items-center justify-center gap-1 bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-3 rounded-md transition-all duration-200">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="18" height="18" x="3" y="4" rx="2" ry="2" /><line x1="16" x2="16" y1="2" y2="6" /><line x1="8" x2="8" y1="2" y2="6" /><line x1="3" x2="21" y1="10" y2="10" /></svg>
                            </button>
                            <button onClick={() => handleShareImage(url, enhancedPrompt || idea)} className="flex-1 flex items-center justify-center gap-1 bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-2 px-3 rounded-md transition-all duration-200">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" x2="12" y1="2" y2="15"/></svg>
                            </button>
                            <button onClick={() => handleDownload(url, index)} className="flex-1 flex items-center justify-center gap-1 bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-3 rounded-md transition-all duration-200">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>
                            </button>
                        </div>
                    </div>
                ))}
              </div>
          </div>
        )}
      </div>
      )}

      {/* --- CLI OUTPUT --- */}
      {mode === 'cli' && cliOutput.length > 0 && (
        <div className="mt-8 space-y-4">
            <h3 className="text-xl font-semibold text-slate-900 dark:text-white">Log Output</h3>
            {cliOutput.map(item => (
                <div key={item.id} className="bg-white dark:bg-slate-800 p-4 rounded-lg">
                    <p className="font-mono text-sm text-slate-500 dark:text-slate-400 break-all">{`> ${item.command}`}</p>
                    <div className="mt-4">
                        {item.status === 'pending' && <div className="flex items-center gap-2"><LoadingSpinner className="w-4 h-4" /><span className="text-slate-500">Menjana...</span></div>}
                        {item.status === 'error' && <p className="text-red-500 dark:text-red-400">Ralat: {item.error}</p>}
                        {item.status === 'success' && item.result && (
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                                {item.result.imageUrls.map((url, index) => (
                                     <div key={index} className="space-y-2">
                                        <img src={url} alt={`Result for ${item.command} - ${index + 1}`} className="w-full h-auto rounded-md" />
                                        <div className="flex items-center justify-center gap-1">
                                            <button onClick={() => handleShareImage(url, item.result?.enhancedPrompt || '')} title="Kongsi" className="flex-1 p-2 bg-cyan-600 hover:bg-cyan-700 rounded-md text-white"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="mx-auto"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" x2="12" y1="2" y2="15"/></svg></button>
                                            <button onClick={() => handleDownload(url, index)} title="Muat Turun" className="flex-1 p-2 bg-green-600 hover:bg-green-700 rounded-md text-white"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="mx-auto"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg></button>
                                        </div>
                                     </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            ))}
        </div>
      )}
    </div>
  );
};

export default ImageGeneratorView;