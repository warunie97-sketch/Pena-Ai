import React, { useState, useCallback, useRef, useEffect } from 'react';
import type { Tool } from '../types';
import { generateText, generateTextWithThinking } from '../services/geminiService';
import { parseFileForText } from '../utils/fileParsers';
import LoadingSpinner from '../components/LoadingSpinner';
import TranslationWidget from '../components/TranslationWidget';
import WordCount from '../components/WordCount';
import HistoryPanel from '../components/HistoryPanel';
import { useSpeechRecognition } from '../hooks/useSpeechRecognition';
import { useAutoSave } from '../hooks/useAutoSave';
import { useHistory } from '../hooks/useHistory';
import { useGemini } from '../contexts/GeminiContext';
import { ToolId } from '../types';
import MarkdownToolbar from '../components/MarkdownToolbar';
import MarkdownRenderer from '../components/MarkdownRenderer';
import { useLanguage } from '../contexts/LanguageContext';
import ReadAloudButton from '../components/ReadAloudButton';

interface GenericTextViewProps {
  tool: Tool;
  onShareToSocials: (content: string) => void;
}

const PREDEFINED_TONES = ['Profesional', 'Santai', 'Jenaka', 'Formal'];

const GenericTextView: React.FC<GenericTextViewProps> = ({ tool, onShareToSocials }) => {
  const { aiInstance } = useGemini();
  const { uiLang, t } = useLanguage();
  const [prompt, setPrompt] = useState('');
  const [keyIdeas, setKeyIdeas] = useState('');
  const [seoKeywords, setSeoKeywords] = useState('');
  const [seoTone, setSeoTone] = useState('');
  const [imageAttachment, setImageAttachment] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [documentAttachment, setDocumentAttachment] = useState<File | null>(null);
  const [extractedText, setExtractedText] = useState<string | null>(null);
  const [isParsing, setIsParsing] = useState(false);

  const [result, setResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [isThinkingMode, setIsThinkingMode] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // State for tone changing in the result section
  const [tone, setTone] = useState('');
  const [isChangingTone, setIsChangingTone] = useState(false);
  const [toneError, setToneError] = useState('');
  const [suggestedTones, setSuggestedTones] = useState<string[]>([]);
  const [isSuggestingTones, setIsSuggestingTones] = useState(false);

  const saveStatus = useAutoSave(`draft_${tool.id}`, prompt, setPrompt);
  const { history, addHistoryItem, clearHistory } = useHistory(`history_${tool.id}`);

  const { isListening, startListening, stopListening, hasRecognitionSupport } = useSpeechRecognition(
    (transcript) => setPrompt(prev => prev + transcript)
  );
  
  useEffect(() => {
    return () => {
      if (imagePreview) {
        URL.revokeObjectURL(imagePreview);
      }
    };
  }, [imagePreview]);

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    handleRemoveAttachment(); // Clear previous attachments
    setError('');

    if (file.type.startsWith('image/')) {
      setImageAttachment(file);
      setImagePreview(URL.createObjectURL(file));
    } else {
      setDocumentAttachment(file);
      setIsParsing(true);
      try {
        const text = await parseFileForText(file);
        setExtractedText(text);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Gagal memparsing fail.');
        handleRemoveAttachment(); // Clear if parsing fails
      } finally {
        setIsParsing(false);
      }
    }
  };

  const handleRemoveAttachment = () => {
    if (imagePreview) {
      URL.revokeObjectURL(imagePreview);
    }
    setImageAttachment(null);
    setImagePreview(null);
    setDocumentAttachment(null);
    setExtractedText(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleGenerate = useCallback(async () => {
    if (!aiInstance) {
      setError('Sila tetapkan Kunci API Gemini anda dalam pengepala.');
      return;
    }
    if (!prompt.trim()) {
      setError('Sila masukkan gesaan.');
      return;
    }
    setIsLoading(true);
    setError('');
    setResult('');
    addHistoryItem(prompt);

    let finalPrompt = prompt;
    if (tool.id === ToolId.IdeaGenerator && keyIdeas.trim()) {
        finalPrompt = `${prompt}\n\nSila gabungkan idea-idea utama berikut dalam jawapan anda: ${keyIdeas}`;
    } else if (tool.id === ToolId.SeoArticle) {
        let seoAdditions = '';
        if (seoKeywords.trim()) {
            seoAdditions += `\n\nSila pastikan untuk memasukkan kata kunci berikut secara semula jadi: ${seoKeywords}`;
        }
        if (seoTone.trim()) {
            seoAdditions += `\nSila tulis dalam nada berikut: ${seoTone}`;
        }
        if (seoAdditions) {
            finalPrompt = `${prompt}${seoAdditions}`;
        }
    }

    try {
      const instruction = tool.systemInstruction ? tool.systemInstruction[uiLang] : undefined;
      let generatedText: string;
      if (isThinkingMode) {
        generatedText = await generateTextWithThinking(aiInstance, finalPrompt, instruction, imageAttachment, extractedText);
      } else {
        generatedText = await generateText(aiInstance, finalPrompt, instruction, imageAttachment, extractedText);
      }
      setResult(generatedText);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [prompt, keyIdeas, seoKeywords, seoTone, tool.id, tool.systemInstruction, addHistoryItem, imageAttachment, extractedText, aiInstance, uiLang, isThinkingMode]);
  
  const handleChangeTone = useCallback(async () => {
    if (!aiInstance) {
      setToneError('Sila tetapkan Kunci API Gemini anda.');
      return;
    }
    if (!result) {
      setToneError('Tiada hasil untuk diubah nadanya.');
      return;
    }
    if (!tone.trim()) {
      setToneError('Sila masukkan nada yang diingini.');
      return;
    }

    setIsChangingTone(true);
    setToneError('');

    const toneChangePrompt = `Anda adalah seorang pakar linguistik. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti 'Ia bukan X, tetapi Y' atau 'Ia bukan X. Ia adalah Y.'. Ubah nada teks berikut kepada "${tone}" sambil mengekalkan makna asalnya. Pastikan teks akhir adalah dalam Bahasa Malaysia.
Berikan jawapan anda dalam DUA bahagian:
1. **TEKS DIUBAH NADA**: Kembalikan versi teks yang bersih dan telah diubah nada sepenuhnya.
2. **ANALISIS PERUBAHAN**: Selepas teks yang diubah, sediakan senarai terperinci bagi setiap perubahan ketara yang dibuat untuk mencapai nada baharu. Bagi setiap perubahan, gunakan format berikut:
    - **Asal:** "[petik ayat atau frasa asal]"
    - **Diubah:** "[tunjukkan ayat atau frasa yang telah diubah]"
    - **Sebab:** "[jelaskan secara ringkas tujuan perubahan (cth., 'Menggantikan perkataan formal dengan sinonim yang lebih santai', 'Mengubah struktur ayat untuk bunyi yang lebih berjenaka', 'Menambah kata-kata sopan untuk nada profesional')]"

Teks asal:
"""
${result}
"""`;
    
    try {
      const newResult = await generateText(aiInstance, toneChangePrompt);
      setResult(newResult);
    } catch (err) {
      setToneError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    } finally {
      setIsChangingTone(false);
    }
  }, [result, tone, aiInstance]);

  const handleSuggestTones = useCallback(async () => {
    if (!aiInstance) {
        setToneError('Sila tetapkan Kunci API Gemini anda.');
        return;
    }
    if (!result) {
        setToneError('Tiada hasil untuk dianalisis.');
        return;
    }
    setIsSuggestingTones(true);
    setToneError('');
    setSuggestedTones([]);

    const suggestPrompt = `You are a linguistic expert. Analyze the following text and suggest 3-5 alternative tones that would be appropriate for it. For each tone, provide a brief one-word or two-word label. Respond ONLY with a JSON array of strings. The labels should be in Bahasa Malaysia.

    Example response: ["Lebih Meyakinkan", "Formal", "Jenaka", "Empati", "Ringkas"]

    Text to analyze:
    """
    ${result}
    """`;
    
    try {
        const response = await generateText(aiInstance, suggestPrompt);
        // The API might return the JSON inside a markdown block, so we need to clean it.
        const cleanedResponse = response.replace(/```json\n?/, '').replace(/```$/, '').trim();
        const tonesArray = JSON.parse(cleanedResponse);
        if (Array.isArray(tonesArray)) {
            setSuggestedTones(tonesArray);
        }
    } catch (err) {
        setToneError('Gagal mencadangkan nada.');
        console.error(err);
    } finally {
        setIsSuggestingTones(false);
    }
  }, [result, aiInstance]);

  const handleCopy = () => {
    navigator.clipboard.writeText(result);
  };
  
  const handleHistorySelect = (selectedPrompt: string) => {
    setPrompt(selectedPrompt);
  };

  const handleExport = (format: 'txt' | 'md') => {
    if (!result) return;

    const toolName = t(tool.nameKey).replace(/\s+/g, '_');
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const fileName = `${toolName}_${timestamp}.${format}`;
    
    const mimeType = format === 'md' ? 'text/markdown' : 'text/plain';
    const blob = new Blob([result], { type: `${mimeType};charset=utf-8` });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
  };

  const handleShare = async () => {
    if (!result) return;
    try {
      if (navigator.share) {
        await navigator.share({
          title: `Hasil dari ${t(tool.nameKey)}`,
          text: result,
        });
      } else {
        await navigator.clipboard.writeText(result);
        alert('Hasil disalin ke papan keratan!');
      }
    } catch (error) {
       if (error instanceof Error && !error.message.includes('Abort')) {
        console.error('Error sharing:', error);
      }
    }
  };


  const getSaveStatusMessage = () => {
    switch (saveStatus) {
        case 'saving': return 'Menyimpan...';
        case 'saved': return 'Disimpan';
        default: return 'Perubahan belum disimpan';
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
        <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
      </div>

      <div className="space-y-6">
        <div>
            <div className="flex justify-between items-center mb-2">
                <label htmlFor="prompt" className="block text-sm font-medium text-slate-700 dark:text-slate-300">
                    Gesaan Anda
                </label>
                <span className={`text-xs ${saveStatus === 'saved' ? 'text-slate-400 dark:text-slate-500' : 'text-slate-500 dark:text-slate-400'}`}>{getSaveStatusMessage()}</span>
            </div>
          <div className="relative bg-slate-100 dark:bg-slate-700 rounded-md border border-slate-300 dark:border-slate-600 focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-blue-500 transition-all">
            <MarkdownToolbar textareaRef={textareaRef} onValueChange={setPrompt} />
            <textarea
              ref={textareaRef}
              id="prompt"
              rows={5}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="w-full bg-transparent p-3 text-slate-900 dark:text-white placeholder-slate-500 dark:placeholder-slate-400 focus:outline-none resize-y"
              placeholder={`cth., Tulis catatan blog tentang faedah kerja jarak jauh... atau klik mikrofon untuk bercakap.`}
            />
            {hasRecognitionSupport && (
              <button
                onClick={isListening ? stopListening : startListening}
                className={`absolute right-3 top-3 p-2 rounded-full transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-200 dark:focus:ring-offset-slate-700 focus:ring-blue-500 hover:scale-110 active:scale-100 ${
                  isListening ? 'bg-red-500 text-white animate-pulse' : 'bg-slate-300 text-slate-600 dark:bg-slate-600 dark:text-slate-300 hover:bg-slate-400 dark:hover:bg-slate-500'
                }`}
                aria-label={isListening ? 'Berhenti merakam' : 'Mula input suara'}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M5 3a3 3 0 0 1 6 0v5a3 3 0 0 1-6 0V3z"/><path d="M3.5 6.5A.5.5 0 0 1 4 7v1a4 4 0 0 0 8 0V7a.5.5 0 0 1 1 0v1a5 5 0 0 1-4.5 4.975V15h3a.5.5 0 0 1 0 1h-7a.5.5 0 0 1 0-1h3v-2.025A5 5 0 0 1 3 8V7a.5.5 0 0 1 .5-.5z"/></svg>
              </button>
            )}
          </div>
          <div className="flex justify-between items-center mt-2">
            <p className="text-xs text-slate-500 dark:text-slate-500 pr-4">Sila pastikan gesaan anda mematuhi garis panduan kandungan yang selamat untuk mengelakkan hasil yang tidak diingini.</p>
            <WordCount text={prompt} />
          </div>
        </div>

        {tool.id === ToolId.IdeaGenerator && (
          <div className="mt-4">
            <label htmlFor="key-ideas" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
              Idea Utama / Kata Kunci (Pilihan)
            </label>
            <input
              id="key-ideas"
              type="text"
              value={keyIdeas}
              onChange={(e) => setKeyIdeas(e.target.value)}
              className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-3 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
              placeholder="cth., naga, angkasa, persahabatan"
            />
            <p className="text-xs text-slate-500 dark:text-slate-500 mt-1">Pisahkan idea dengan koma.</p>
          </div>
        )}

        {tool.id === ToolId.SeoArticle && (
            <div className="mt-4 space-y-4">
                <div>
                    <label htmlFor="seo-keywords" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                        Kata Kunci (Pilihan)
                    </label>
                    <input
                        id="seo-keywords"
                        type="text"
                        value={seoKeywords}
                        onChange={(e) => setSeoKeywords(e.target.value)}
                        className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-3 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                        placeholder="cth., pemasaran digital, petua SEO, kandungan berkualiti"
                    />
                    <p className="text-xs text-slate-500 dark:text-slate-500 mt-1">Pisahkan kata kunci dengan koma.</p>
                </div>
                <div>
                    <label htmlFor="seo-tone" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                        Nada Penulisan (Pilihan)
                    </label>
                    <input
                        id="seo-tone"
                        type="text"
                        value={seoTone}
                        onChange={(e) => setSeoTone(e.target.value)}
                        className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-3 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                        placeholder="cth., Profesional, Informatif, Santai"
                    />
                    <div className="flex flex-wrap gap-2 mt-2">
                        {PREDEFINED_TONES.map(t => (
                            <button type="button" key={t} onClick={() => setSeoTone(t)} className="text-xs bg-slate-200 dark:bg-slate-600 hover:bg-slate-300 dark:hover:bg-slate-500 text-slate-700 dark:text-white font-medium py-1 px-3 rounded-full transition-colors">
                            {t}
                            </button>
                        ))}
                    </div>
                </div>
            </div>
        )}
        
        <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">
                Lampirkan Fail untuk Konteks (Pilihan)
            </label>
            <div className="flex items-center gap-4">
                <input type="file" accept="image/*,.pdf,.docx,.txt" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
                <button onClick={() => fileInputRef.current?.click()} className="flex items-center justify-center bg-slate-200 hover:bg-slate-300 text-slate-700 dark:bg-slate-600 dark:hover:bg-slate-500 dark:text-white font-medium py-2 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">
                     <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
                    Pilih Fail
                </button>
                 {(imageAttachment || documentAttachment) && (
                    <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-700 pl-3 rounded-full">
                         <span className="text-slate-600 dark:text-slate-300 text-sm truncate max-w-xs">{imageAttachment?.name || documentAttachment?.name}</span>
                        <button onClick={handleRemoveAttachment} className="text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white p-1.5 rounded-full transition-transform hover:scale-110" aria-label="Remove attachment">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                        </button>
                    </div>
                )}
            </div>
            {isParsing && (
                 <div className="flex items-center text-sm text-slate-500 dark:text-slate-400 mt-2">
                    <LoadingSpinner className="w-4 h-4 mr-2" />
                    <span>Memparsing dokumen...</span>
                </div>
            )}
             {imagePreview && (
                <div className="mt-2 bg-slate-200/50 dark:bg-slate-900/50 p-2 rounded-lg inline-block">
                    <img src={imagePreview} alt="Preview" className="max-h-32 w-auto rounded-md" />
                </div>
            )}
        </div>

        <div className="flex items-center justify-between bg-slate-100 dark:bg-slate-700/50 p-3 rounded-lg">
            <div className="flex items-center gap-3">
                <label htmlFor="thinking-mode" className="font-medium text-slate-700 dark:text-slate-300">
                    Thinking Mode
                </label>
                <div className="group relative">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-500 dark:text-slate-400"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
                    <div className="absolute bottom-full mb-2 w-64 bg-slate-800 text-white text-xs rounded py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                        Membolehkan penaakulan yang lebih mendalam untuk pertanyaan kompleks menggunakan Gemini 2.5 Pro. Mungkin mengambil masa lebih lama untuk menjana.
                    </div>
                </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" checked={isThinkingMode} onChange={(e) => setIsThinkingMode(e.target.checked)} className="sr-only peer" id="thinking-mode" />
                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-slate-600 peer-checked:bg-blue-600"></div>
            </label>
        </div>

        <HistoryPanel history={history} onSelect={handleHistorySelect} onClear={clearHistory} />

        <button
          onClick={handleGenerate}
          disabled={isLoading || isParsing || !aiInstance}
          className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
        >
          {isLoading ? <LoadingSpinner /> : 'Jana'}
        </button>

        {error && <p className="text-red-500 dark:text-red-400 text-center">{error}</p>}
      </div>
      
      {tool.id === 'customer-support' && (
        <div className="mt-8">
          <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-4 text-center">Contoh Penggunaan</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-100 dark:bg-slate-900/50 p-4 rounded-lg">
              <p className="font-semibold text-slate-700 dark:text-slate-300 mb-2">Senario: Pertanyaan Lazim</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-2"><strong>Gesaan Anda:</strong> "Seorang bakal pelanggan ingin tahu jika kami menawarkan diskaun untuk pesanan pukal 'Perancang Pro' kami. Mereka ingin membeli 50 unit."</p>
              <p className="text-xs text-slate-500 dark:text-slate-400"><strong>Respons AI:</strong> "Itu soalan yang bagus! Ya, kami ada menawarkan diskaun untuk pesanan pukal. Untuk pesanan 50 Perancang Pro, kami boleh tawarkan diskaun 15%. Jika anda berminat, saya boleh sediakan invois khas untuk anda. Beritahu sahaja!"</p>
            </div>
            <div className="bg-slate-100 dark:bg-slate-900/50 p-4 rounded-lg">
              <p className="font-semibold text-slate-700 dark:text-slate-300 mb-2">Senario: Menjawab Soalan Lazim</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-2"><strong>Gesaan Anda:</strong> `Seorang pelanggan bertanya: "Berapa lama masa yang diambil untuk penghantaran?"`</p>
              <p className="text-xs text-slate-500 dark:text-slate-400"><strong>Respons AI:</strong> "Hai! Penghantaran standard kami biasanya mengambil masa 3-5 hari bekerja untuk pesanan domestik. Penghantaran antarabangsa boleh mengambil masa 7-14 hari bekerja, bergantung pada kastam. Anda akan menerima nombor penjejakan melalui e-mel sebaik sahaja pesanan anda dihantar!"</p>
            </div>
            <div className="bg-slate-100 dark:bg-slate-900/50 p-4 rounded-lg">
              <p className="font-semibold text-slate-700 dark:text-slate-300 mb-2">Senario: Penyelesaian Masalah</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-2"><strong>Gesaan Anda:</strong> `"SmartGadget X" baru pengguna tidak boleh dihidupkan. Mereka telah menekan butang kuasa.`</p>
              <p className="text-xs text-slate-500 dark:text-slate-400"><strong>Respons AI:</strong> "Saya minta maaf mendengar anda menghadapi masalah dengan SmartGadget X baru anda. Mari kita cuba beberapa perkara. Pertama, sila pastikan peranti telah dicas sekurang-kurangnya 30 minit menggunakan kabel yang disertakan. Kemudian, tekan dan tahan butang kuasa selama 10 saat penuh. Jika ia masih tidak hidup, sila maklumkan kepada saya."</p>
            </div>
            <div className="bg-slate-100 dark:bg-slate-900/50 p-4 rounded-lg">
              <p className="font-semibold text-slate-700 dark:text-slate-300 mb-2">Senario: Soalan Polisi</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-2"><strong>Gesaan Anda:</strong> `Pelanggan bertanya: "Apakah polisi pemulangan anda?"`</p>
              <p className="text-xs text-slate-500 dark:text-slate-400"><strong>Respons AI:</strong> "Kami mempunyai polisi pemulangan 30 hari tanpa soal. Jika anda tidak berpuas hati sepenuhnya dengan pembelian anda, anda boleh memulangkannya dalam masa 30 hari selepas penerimaan untuk bayaran balik penuh. Hanya lawati halaman pemulangan kami di [Laman Web Anda]/returns untuk memulakan proses."</p>
            </div>
          </div>
        </div>
      )}

      {result && (
        <div className="mt-8 bg-white dark:bg-slate-800 rounded-lg shadow-lg">
          <div className="flex justify-between items-center p-4 border-b border-slate-200 dark:border-slate-700 flex-wrap gap-2">
            <h3 className="text-xl font-semibold text-slate-900 dark:text-white">Hasil</h3>
            <div className="flex items-center gap-2">
              <ReadAloudButton textToRead={result} />
              <button onClick={() => onShareToSocials(result)} title="Hantar ke Pengurus Kandungan" className="text-sm bg-purple-600 hover:bg-purple-500 text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95 flex items-center gap-1.5">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="18" height="18" x="3" y="4" rx="2" ry="2" /><line x1="16" x2="16" y1="2" y2="6" /><line x1="8" x2="8" y1="2" y2="6" /><line x1="3" x2="21" y1="10" y2="10" /></svg>
                Hantar ke Pengurus
              </button>
              <button onClick={handleShare} title="Kongsi" className="p-2 text-sm bg-cyan-600 hover:bg-cyan-500 text-white font-medium rounded-md transition-all duration-200 hover:scale-105 active:scale-95">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" x2="12" y1="2" y2="15"/></svg>
              </button>
              <button onClick={handleCopy} className="text-sm bg-slate-200 hover:bg-slate-300 text-slate-700 dark:bg-slate-600 dark:hover:bg-slate-500 dark:text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">Salin</button>
              <button onClick={() => handleExport('txt')} className="text-sm bg-green-600 hover:bg-green-500 text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">Eksport .txt</button>
              <button onClick={() => handleExport('md')} className="text-sm bg-green-600 hover:bg-green-500 text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">Eksport .md</button>
            </div>
          </div>
          <div className="p-6">
            <MarkdownRenderer content={result} />
            <WordCount text={result} />
            <TranslationWidget textToTranslate={result} />
            <div className="mt-6 pt-6 border-t border-slate-200 dark:border-slate-700">
                <h4 className="text-lg font-semibold text-slate-900 dark:text-white mb-3">Tukar Nada Hasil</h4>
                <div className="space-y-4 sm:flex sm:gap-4 sm:items-end">
                    <div className="flex-grow">
                        <label htmlFor="tone-input-result" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                            Nada Baharu
                        </label>
                        <input
                            id="tone-input-result"
                            type="text"
                            value={tone}
                            onChange={(e) => setTone(e.target.value)}
                            className="w-full bg-slate-100 dark:bg-slate-900/50 border border-slate-300 dark:border-slate-600 rounded-md p-3 text-slate-900 dark:text-white"
                            placeholder="cth., formal, santai, lucu, profesional"
                        />
                         <div className="flex flex-wrap gap-2 mt-2">
                            {PREDEFINED_TONES.map(toneItem => (
                                <button type="button" key={toneItem} onClick={() => setTone(toneItem)} className="text-xs bg-slate-200 dark:bg-slate-600 hover:bg-slate-300 dark:hover:bg-slate-500 text-slate-700 dark:text-white font-medium py-1 px-3 rounded-full transition-colors">
                                {toneItem}
                                </button>
                            ))}
                        </div>
                    </div>
                    <button
                        onClick={handleChangeTone}
                        disabled={isChangingTone || !aiInstance}
                        className="w-full sm:w-auto flex-shrink-0 flex items-center justify-center bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-3 px-6 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
                    >
                        {isChangingTone ? <LoadingSpinner /> : 'Gunakan Nada'}
                    </button>
                </div>
                <div className="mt-4 flex items-center flex-wrap gap-2">
                    <button type="button" onClick={handleSuggestTones} disabled={isSuggestingTones || !result || !aiInstance} className="text-xs flex items-center gap-1.5 bg-slate-200 dark:bg-slate-600 hover:bg-slate-300 dark:hover:bg-slate-500 text-slate-700 dark:text-white font-medium py-1 px-3 rounded-full transition-colors disabled:opacity-50">
                        {isSuggestingTones ? <LoadingSpinner className="w-4 h-4" /> : <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3v.01"/><path d="M16.2 3.8v.01"/><path d="M20.2 7.8v.01"/><path d="M21 12v.01"/><path d="M20.2 16.2v.01"/><path d="M16.2 20.2v.01"/><path d="M12 21v.01"/><path d="M7.8 20.2v.01"/><path d="M3.8 16.2v.01"/><path d="M3 12v.01"/><path d="M3.8 7.8v.01"/><path d="M7.8 3.8v.01"/></svg>}
                        Cadangkan Nada
                    </button>
                     {suggestedTones.map(suggestedTone => (
                        <button
                            type="button"
                            key={suggestedTone}
                            onClick={() => setTone(suggestedTone)}
                            className="text-xs bg-purple-200 dark:bg-purple-900/50 hover:bg-purple-300 dark:hover:bg-purple-800/50 text-purple-800 dark:text-purple-200 font-medium py-1 px-3 rounded-full transition-colors"
                        >
                            {suggestedTone} ✨
                        </button>
                    ))}
                </div>
                {toneError && <p className="text-red-500 dark:text-red-400 text-center mt-2">{toneError}</p>}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GenericTextView;