import React, { useState, useMemo } from 'react';
import type { Tool, Post, PostCategory } from '../types';
import { usePosts } from '../hooks/usePosts';
import BlogPostCard from '../components/BlogPostCard';
import PostEditorModal from '../components/PostEditorModal';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';

interface BlogViewProps {
  tool: Tool;
}

const BlogView: React.FC<BlogViewProps> = ({ tool }) => {
  const { currentUser } = useAuth();
  const blogKey = currentUser ? `my_blog_posts_${currentUser.id}` : null;
  const { posts, addPost, updatePost, deletePost } = usePosts(blogKey);
  const { t } = useLanguage();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPost, setEditingPost] = useState<Post | null>(null);

  const handleOpenModalForCreate = () => {
    setEditingPost(null);
    setIsModalOpen(true);
  };

  const handleOpenModalForEdit = (post: Post) => {
    setEditingPost(post);
    setIsModalOpen(true);
  };
  
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingPost(null);
  }

  const handleSavePost = (postData: { title: string; content: string; category?: PostCategory }, postId?: string) => {
    // For "My Blog", we don't use categories, so we destructure it out and don't use it.
    const { category, ...blogPostData } = postData;
    if (postId && editingPost) {
      updatePost({ ...editingPost, ...blogPostData });
    } else {
      addPost(blogPostData);
    }
    handleCloseModal();
  };

  const handleDeletePost = (postId: string) => {
      if (window.confirm('Adakah anda pasti mahu memadamkan catatan ini? Tindakan ini tidak boleh dibuat asal.')) {
        deletePost(postId);
      }
  };

  const sortedPosts = useMemo(() => {
    return [...posts].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }, [posts]);

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6 flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
          <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
        </div>
        <button
          onClick={handleOpenModalForCreate}
          className="flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L15.232 5.232z" /></svg>
          Tulis Catatan Baru
        </button>
      </div>

      {sortedPosts.length > 0 ? (
        <div className="space-y-6">
            {sortedPosts.map(post => (
                <BlogPostCard 
                    key={post.id} 
                    post={post}
                    onEdit={() => handleOpenModalForEdit(post)}
                    onDelete={() => handleDeletePost(post.id)}
                />
            ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-white dark:bg-slate-800/50 rounded-lg">
          <h3 className="text-xl font-semibold text-slate-900 dark:text-white">Tiada catatan dalam blog anda lagi.</h3>
          <p className="text-slate-500 dark:text-slate-400 mt-2">Jadilah yang pertama untuk menulis sesuatu!</p>
        </div>
      )}

      <PostEditorModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onSave={handleSavePost}
        post={editingPost}
        showCategorySelector={false}
      />
    </div>
  );
};

export default BlogView;