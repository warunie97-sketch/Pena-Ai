import React from 'react';
import { TOOLS } from '../constants';
import { ToolId } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

const WelcomeView: React.FC = () => {
  const { t } = useLanguage();

  const featuredToolIds = [
    ToolId.ContentWriting,
    ToolId.ContentManagement,
    ToolId.AdsManagement,
    ToolId.PhotoGenerator,
    ToolId.VideoGenerator,
    ToolId.TextEditing,
  ];

  const featuredTools = TOOLS.filter(tool => featuredToolIds.includes(tool.id));

  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
        <div className="text-center lg:text-left">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 dark:text-white mb-4 leading-tight">
            Cetuskan Potensi Kreatif Anda dengan <span className="text-blue-600 dark:text-blue-500">Ejen AI</span>
          </h1>
          <p className="text-lg sm:text-xl text-slate-500 dark:text-slate-400">
            Daripada idea menjadi realiti—lebih pantas dari biasa. Ejen AI ialah pembantu peribadi anda untuk menghasilkan kandungan yang memukau, visual yang menawan, dan strategi yang berkesan.
          </p>
        </div>
        <div className="flex items-center justify-center p-4">
            <svg width="100%" height="100%" viewBox="0 0 300 300" xmlns="http://www.w3.org/2000/svg" className="max-w-xs lg:max-w-sm">
                <defs>
                    <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" style={{stopColor: '#3B82F6', stopOpacity: 1}} />
                        <stop offset="100%" style={{stopColor: '#60A5FA', stopOpacity: 1}} />
                    </linearGradient>
                    <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
                        <feGaussianBlur stdDeviation="10" result="coloredBlur"/>
                        <feMerge>
                            <feMergeNode in="coloredBlur"/>
                            <feMergeNode in="SourceGraphic"/>
                        </feMerge>
                    </filter>
                </defs>
                <circle cx="150" cy="150" r="120" fill="url(#grad1)" opacity="0.1" filter="url(#glow)" />
                <path d="M150 30 V270 M30 150 H270 M75 75 L225 225 M75 225 L225 75" stroke="url(#grad1)" strokeWidth="1.5" opacity="0.3"/>
                <circle cx="150" cy="150" r="70" fill="none" stroke="#60A5FA" strokeWidth="2" strokeDasharray="10 5" opacity="0.7">
                    <animateTransform attributeName="transform" type="rotate" from="0 150 150" to="360 150 150" dur="20s" repeatCount="indefinite"/>
                </circle>
                <circle cx="150" cy="150" r="100" fill="none" stroke="#3B82F6" strokeWidth="2" strokeDasharray="5 10" opacity="0.5">
                    <animateTransform attributeName="transform" type="rotate" from="360 150 150" to="0 150 150" dur="30s" repeatCount="indefinite"/>
                </circle>
                 <text x="50%" y="50%" textAnchor="middle" dy=".3em" fontSize="90" fontWeight="bold" fill="currentColor" className="text-slate-800 dark:text-white">AI</text>
            </svg>
        </div>
      </div>

      {/* Featured Tools Section */}
      <div>
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-6 text-center lg:text-left">Mula dengan Alatan Pilihan Kami</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredTools.map(tool => (
            <div 
              key={tool.id} 
              className="bg-white dark:bg-slate-800/50 p-6 rounded-xl shadow-md hover:shadow-lg hover:shadow-blue-500/10 dark:hover:shadow-blue-500/20 transition-all duration-300 transform hover:-translate-y-1"
            >
              <div className="flex items-center gap-4 mb-3">
                <span className="text-blue-500 dark:text-blue-400 bg-blue-100 dark:bg-blue-900/30 p-2 rounded-lg">{tool.icon}</span>
                <h3 className="text-lg font-bold text-slate-800 dark:text-white">{t(tool.nameKey)}</h3>
              </div>
              <p className="text-sm text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default WelcomeView;