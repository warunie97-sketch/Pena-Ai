import React, { useState, useCallback, useEffect } from 'react';
import type { Tool } from '../types';
import { generateWithMaps, SearchResultWithMaps } from '../services/geminiService';
import LoadingSpinner from '../components/LoadingSpinner';
import MapResultDisplay from '../components/MapResultDisplay';
import { useGemini } from '../contexts/GeminiContext';
import { useLanguage } from '../contexts/LanguageContext';
import InteractiveMap from '../components/InteractiveMap';

interface LocalDiscoveryViewProps {
  tool: Tool;
  onShareToSocials: (content: string) => void;
}

const LocalDiscoveryView: React.FC<LocalDiscoveryViewProps> = ({ tool, onShareToSocials }) => {
  const { aiInstance } = useGemini();
  const { uiLang, t } = useLanguage();
  const [prompt, setPrompt] = useState('');
  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [locationError, setLocationError] = useState('');
  
  const [result, setResult] = useState<SearchResultWithMaps | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    setLocationError('');
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
        },
        (err) => {
          setLocationError(`Gagal mendapatkan lokasi: ${err.message}. Sila benarkan akses lokasi untuk menggunakan ciri ini.`);
        }
      );
    } else {
      setLocationError('Geolokasi tidak disokong oleh pelayar ini.');
    }
  }, []);

  const handleGenerate = useCallback(async () => {
    if (!aiInstance) {
      setError('Sila tetapkan Kunci API Gemini anda dalam pengepala.');
      return;
    }
    if (!location) {
      setError('Tidak dapat mendapatkan lokasi anda. Sila benarkan akses lokasi.');
      return;
    }
    if (!prompt.trim()) {
      setError('Sila masukkan pertanyaan carian.');
      return;
    }

    setIsLoading(true);
    setError('');
    setResult(null);
    try {
      const instruction = tool.systemInstruction ? tool.systemInstruction[uiLang] : undefined;
      const searchResult = await generateWithMaps(aiInstance, prompt, location, instruction);
      setResult(searchResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [prompt, tool.systemInstruction, aiInstance, uiLang, location]);

  const mapLocations = result?.sources.filter(s => s.maps && s.maps.latLng).map(s => s.maps!);

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
        <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
      </div>

      <div className="space-y-6">
        <div>
          <label htmlFor="prompt" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
            Apakah yang anda cari?
          </label>
          <textarea
            id="prompt"
            rows={3}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-3 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
            placeholder={`cth., Cadangkan beberapa restoran Itali yang bagus berdekatan.`}
          />
        </div>
        
        {locationError && (
             <p className="text-yellow-600 dark:text-yellow-400 text-center bg-yellow-100 dark:bg-yellow-900/20 p-3 rounded-md">{locationError}</p>
        )}

        <button
          onClick={handleGenerate}
          disabled={isLoading || !location || !aiInstance}
          className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
        >
          {isLoading ? <LoadingSpinner /> : 'Cari'}
        </button>

        {error && <p className="text-red-500 dark:text-red-400 text-center">{error}</p>}
      </div>

      {location && mapLocations && mapLocations.length > 0 && !isLoading && (
        <div className="mt-8">
            <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-4">Peta Interaktif</h3>
            <div className="rounded-lg overflow-hidden shadow-lg">
                <InteractiveMap 
                    center={{ lat: location.latitude, lng: location.longitude }}
                    locations={mapLocations}
                />
            </div>
        </div>
      )}

       <div className="mt-8">
            <MapResultDisplay
                isLoading={isLoading}
                result={result}
                error={error}
                toolName={t(tool.nameKey)}
                onShareToSocials={onShareToSocials}
            />
        </div>
    </div>
  );
};

export default LocalDiscoveryView;