import React, { useState, useRef, useCallback, useEffect } from 'react';
import type { Tool } from '../types';
import { useGemini } from '../contexts/GeminiContext';
import { useLanguage } from '../contexts/LanguageContext';
import { transcribeAudio } from '../services/geminiService';
import LoadingSpinner from '../components/LoadingSpinner';
import MarkdownRenderer from '../components/MarkdownRenderer';

interface AudioTranscriptionViewProps {
  tool: Tool;
  onShareToSocials: (content: string) => void;
}

const AudioTranscriptionView: React.FC<AudioTranscriptionViewProps> = ({ tool, onShareToSocials }) => {
  const { aiInstance } = useGemini();
  const { aiLang, t } = useLanguage();

  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [transcription, setTranscription] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  useEffect(() => {
    return () => {
      if (audioUrl) {
        URL.revokeObjectURL(audioUrl);
      }
    };
  }, [audioUrl]);

  const resetAudioState = () => {
      setAudioBlob(null);
      if (audioUrl) {
          URL.revokeObjectURL(audioUrl);
      }
      setAudioUrl(null);
      setTranscription('');
      if (fileInputRef.current) {
          fileInputRef.current.value = '';
      }
  }

  const handleStartRecording = async () => {
    resetAudioState();
    setError('');

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);
      audioChunksRef.current = [];

      mediaRecorderRef.current.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorderRef.current.onstop = () => {
        const newAudioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        setAudioBlob(newAudioBlob);
        setAudioUrl(URL.createObjectURL(newAudioBlob));
        stream.getTracks().forEach(track => track.stop()); // Stop microphone access
      };

      mediaRecorderRef.current.start();
      setIsRecording(true);
    } catch (err) {
      setError(t('audioTranscription.micError'));
    }
  };

  const handleStopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (isRecording) {
        handleStopRecording();
    }
    resetAudioState();
    setError('');

    const file = e.target.files?.[0];
    if (file && file.type.startsWith('audio/')) {
        setAudioBlob(file);
        setAudioUrl(URL.createObjectURL(file));
    } else if(file) {
        setError('Sila pilih fail audio yang sah.');
    }
  };

  const handleTranscribe = useCallback(async () => {
    if (!aiInstance) {
      setError('Sila tetapkan Kunci API Gemini anda.');
      return;
    }
    if (!audioBlob) {
      setError('Sila rakam atau muat naik audio terlebih dahulu.');
      return;
    }

    setIsLoading(true);
    setError('');
    setTranscription('');

    try {
      const result = await transcribeAudio(aiInstance, audioBlob, aiLang);
      setTranscription(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ralat tidak dijangka semasa transkripsi.');
    } finally {
      setIsLoading(false);
    }
  }, [aiInstance, audioBlob, aiLang]);
  
  const handleDownloadSource = () => {
    if (!audioUrl || !audioBlob) return;
    const link = document.createElement('a');
    link.href = audioUrl;
    const extension = audioBlob.type.split('/')[1] || 'audio';
    link.download = `sumber_audio_${Date.now()}.${extension}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadTranscription = () => {
      if (!transcription) return;
      const blob = new Blob([transcription], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `transkripsi_${Date.now()}.txt`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
        <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
      </div>

      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg text-center flex flex-col items-center justify-center">
                <h3 className="text-xl font-semibold mb-4 text-slate-900 dark:text-white">{t('audioTranscription.recordAudio')}</h3>
                {isRecording ? (
                    <button onClick={handleStopRecording} className="bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-full text-lg animate-pulse w-48">
                    {t('audioTranscription.stopRecording')}
                    </button>
                ) : (
                    <button onClick={handleStartRecording} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-full text-lg w-48">
                    {t('audioTranscription.startRecording')}
                    </button>
                )}
            </div>
             <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg text-center flex flex-col items-center justify-center">
                <h3 className="text-xl font-semibold mb-4 text-slate-900 dark:text-white">{t('audioTranscription.uploadAudio')}</h3>
                <input ref={fileInputRef} type="file" accept="audio/*" onChange={handleFileChange} className="hidden" />
                 <button onClick={() => fileInputRef.current?.click()} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-full text-lg w-48">
                    Pilih Fail
                </button>
            </div>
        </div>

        {audioUrl && (
            <div className="mt-6 bg-white dark:bg-slate-800 p-4 rounded-lg shadow-lg">
                <h4 className="text-lg font-semibold mb-2 text-slate-900 dark:text-white">{t('audioTranscription.preview')}</h4>
                <audio src={audioUrl} controls className="w-full" />
                <div className="flex justify-end mt-2">
                    <button onClick={handleDownloadSource} className="text-sm bg-slate-200 hover:bg-slate-300 dark:bg-slate-600 dark:hover:bg-slate-500 text-slate-700 dark:text-white font-medium py-1 px-3 rounded-md">
                        {t('audioTranscription.downloadSource')}
                    </button>
                </div>
            </div>
        )}

        <button
          onClick={handleTranscribe}
          disabled={isLoading || !audioBlob || !aiInstance}
          className="w-full flex items-center justify-center bg-green-600 hover:bg-green-700 disabled:bg-slate-400 dark:disabled:bg-slate-600 text-white font-bold py-3 px-4 rounded-md transition-all duration-200 text-lg"
        >
          {isLoading ? <LoadingSpinner /> : t('audioTranscription.transcribe')}
        </button>

        {error && <p className="text-red-500 dark:text-red-400 text-center">{error}</p>}
      </div>

      {isLoading && <div className="mt-8 text-center"><LoadingSpinner className="w-10 h-10 mx-auto" /><p className="mt-2 text-slate-500 dark:text-slate-400">Mentranskripsi audio...</p></div>}

      {transcription && !isLoading && (
        <div className="mt-8 bg-white dark:bg-slate-800 rounded-lg shadow-lg">
           <div className="flex justify-between items-center p-4 border-b border-slate-200 dark:border-slate-700">
             <h3 className="text-2xl font-bold text-slate-900 dark:text-white">{t('audioTranscription.transcription')}</h3>
             <div className="flex items-center gap-2">
                <button onClick={() => onShareToSocials(transcription)} title="Hantar ke Pengurus Kandungan" className="text-sm bg-purple-600 hover:bg-purple-500 text-white font-medium py-1 px-3 rounded-md">Hantar</button>
                <button onClick={handleDownloadTranscription} className="text-sm bg-green-600 hover:bg-green-500 text-white font-medium py-1 px-3 rounded-md">{t('audioTranscription.downloadTxt')}</button>
             </div>
           </div>
           <div className="p-6">
            <MarkdownRenderer content={transcription} />
          </div>
        </div>
      )}
    </div>
  );
};

export default AudioTranscriptionView;
