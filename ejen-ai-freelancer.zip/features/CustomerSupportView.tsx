import React, { useState, useCallback } from 'react';
import type { Tool } from '../types';
import { useGemini } from '../contexts/GeminiContext';
import { generateTextLite } from '../services/geminiService';
import LoadingSpinner from '../components/LoadingSpinner';
import MarkdownRenderer from '../components/MarkdownRenderer';
import { useLanguage } from '../contexts/LanguageContext';

interface CustomerSupportViewProps {
  tool: Tool;
  onShareToSocials: (content: string) => void;
}

const CustomerSupportView: React.FC<CustomerSupportViewProps> = ({ tool, onShareToSocials }) => {
  const { aiInstance } = useGemini();
  const { t } = useLanguage();
  const [prompt, setPrompt] = useState('');
  const [result, setResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleGenerate = useCallback(async (customPrompt?: string) => {
    const query = customPrompt || prompt;
    if (!aiInstance) {
      setError('Sila tetapkan Kunci API Gemini anda.');
      return;
    }
    if (!query.trim()) {
      setError('Sila masukkan pertanyaan pelanggan.');
      return;
    }
    setIsLoading(true);
    setError('');
    try {
      const systemInstruction = 'Anda adalah pembantu sokongan pelanggan yang membantu dan berempati. Hasilkan respons yang jelas, ringkas, dan mesra kepada pertanyaan pelanggan berdasarkan gesaan pengguna. Utamakan kependekkan dan kelajuan. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti \'Ia bukan X, tetapi Y\' atau \'Ia bukan X. Ia adalah Y.\'.';
      const generatedText = await generateTextLite(aiInstance, query, systemInstruction);
      setResult(generatedText);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ralat tidak dijangka.');
    } finally {
      setIsLoading(false);
    }
  }, [aiInstance, prompt]);
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
        <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
      </div>

      <div className="space-y-6">
        <div>
          <label htmlFor="prompt-support" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
            Pertanyaan Pelanggan
          </label>
          <textarea
            id="prompt-support"
            rows={4}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full bg-slate-100 dark:bg-slate-700 p-3 rounded-md"
            placeholder="cth., Pelanggan bertanya tentang polisi pemulangan kami."
          />
        </div>

        <button onClick={() => handleGenerate()} disabled={isLoading || !aiInstance} className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-md disabled:bg-slate-500">
          {isLoading ? <LoadingSpinner /> : 'Jana Respons'}
        </button>

        {error && <p className="text-red-500 dark:text-red-400 text-center">{error}</p>}
      </div>

      {result && (
        <div className="mt-8 bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg">
          <h3 className="text-2xl font-bold mb-4">Cadangan Respons</h3>
          <MarkdownRenderer content={result} />
        </div>
      )}
    </div>
  );
};

export default CustomerSupportView;