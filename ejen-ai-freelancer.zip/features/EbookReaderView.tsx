import React, { useState, useRef, useCallback, useMemo } from 'react';
import type { Tool } from '../types';
import PdfViewer from '../components/PdfViewer';
import SummaryModal from '../components/SummaryModal';
import BookmarkPanel from '../components/BookmarkPanel';
import { generateText, generateWithSearch, SearchResult } from '../services/geminiService';
import SearchResultDisplay from '../components/SearchResultDisplay';
import KeywordSearchResultPanel from '../components/KeywordSearchResultPanel';
import LoadingSpinner from '../components/LoadingSpinner';
import { useBookmarks } from '../hooks/useBookmarks';
import type { PDFDocumentProxy } from 'pdfjs-dist/types/src/display/api';
import { useGemini } from '../contexts/GeminiContext';
import { useLanguage } from '../contexts/LanguageContext';

interface EbookReaderViewProps {
  tool: Tool;
  onShareToSocials: (content: string) => void;
}

const EbookReaderView: React.FC<EbookReaderViewProps> = ({ tool, onShareToSocials }) => {
  const { aiInstance } = useGemini();
  const { uiLang, t } = useLanguage();
  const [file, setFile] = useState<File | null>(null);
  const [fileUrl, setFileUrl] = useState<string | null>(null);
  const [pdfDocument, setPdfDocument] = useState<PDFDocumentProxy | null>(null);
  const [error, setError] = useState('');

  const [isSummaryModalOpen, setIsSummaryModalOpen] = useState(false);
  const [summary, setSummary] = useState('');
  const [isSummarizing, setIsSummarizing] = useState(false);
  
  const [currentPage, setCurrentPage] = useState(1);
  const documentId = useMemo(() => file ? `${file.name}-${file.size}` : null, [file]);
  const { bookmarks, addBookmark, removeBookmark } = useBookmarks(documentId);

  const [selectedText, setSelectedText] = useState('');
  const [searchResult, setSearchResult] = useState<SearchResult | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState('');
  
  const [keywordSearchResults, setKeywordSearchResults] = useState<number[]>([]);
  const [isKeywordSearching, setIsKeywordSearching] = useState(false);
  const [keywordSearchError, setKeywordSearchError] = useState('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
      setPdfDocument(null);
      setCurrentPage(1); // Reset to first page
      const url = URL.createObjectURL(selectedFile);
      if (fileUrl) {
        URL.revokeObjectURL(fileUrl);
      }
      setFileUrl(url);
      setError('');
      setSummary('');
      setSearchResult(null);
      setSelectedText('');
      setKeywordSearchResults([]);
      setKeywordSearchError('');
    } else {
      setError('Sila pilih fail PDF yang sah.');
      setFile(null);
      setFileUrl(null);
      setPdfDocument(null);
    }
  };

  const triggerFileSelect = () => fileInputRef.current?.click();

  const handleSummarize = async () => {
    if (!pdfDocument) {
      setError('Sila tunggu PDF selesai dimuatkan sebelum membuat ringkasan.');
      return;
    }
    if (!aiInstance) {
        setError('Sila tetapkan Kunci API Gemini anda untuk membuat ringkasan.');
        return;
    }
    
    setIsSummaryModalOpen(true);
    setIsSummarizing(true);
    setSummary('');
    setError('');

    try {
        let fullText = '';
        for (let i = 1; i <= pdfDocument.numPages; i++) {
            const page = await pdfDocument.getPage(i);
            const textContent = await page.getTextContent();
            const pageText = (textContent.items as { str: string }[]).map(item => item.str).join(' ');
            fullText += pageText + '\n\n';
        }
        
        if (!fullText.trim()) {
            throw new Error("Tidak dapat mengekstrak sebarang teks daripada PDF. Dokumen mungkin berasaskan imej atau kosong.");
        }

        const prompt = `Sila berikan ringkasan padat bagi kandungan dokumen berikut:\n\n---\n\n${fullText}`;
        const systemInstructions = {
          ms: 'Anda adalah pembantu yang berguna yang meringkaskan dokumen. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti \'Ia bukan X, tetapi Y\' atau \'Ia bukan X. Ia adalah Y.\'.',
          en: 'You are a helpful assistant who summarizes documents. Avoid repetitive sentence structures, especially comparison patterns like \'It\'s not X, but Y\' or \'It\'s not X. It is Y.\'.',
        };
        const instruction = systemInstructions[uiLang];
        const generatedSummary = await generateText(aiInstance, prompt, instruction);
        setSummary(generatedSummary);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unexpected error occurred.';
      setError(`Gagal menjana ringkasan: ${errorMessage}`);
      setSummary('');
      setIsSummaryModalOpen(false);
    } finally {
      setIsSummarizing(false);
    }
  };

  const handleTextSelect = useCallback((text: string) => {
    setSelectedText(text);
  }, []);

  const handleSearchSelectedText = useCallback(async () => {
    if (!selectedText) return;
    if (!aiInstance) {
        setSearchError('Sila tetapkan Kunci API Gemini anda untuk menggunakan carian.');
        return;
    }

    setIsSearching(true);
    setSearchError('');
    setSearchResult(null);
    setKeywordSearchResults([]); // Clear other results

    try {
      const result = await generateWithSearch(aiInstance, selectedText);
      setSearchResult(result);
    } catch (err) {
      setSearchError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    } finally {
      setIsSearching(false);
    }
  }, [selectedText, aiInstance]);

  const handleKeywordSearch = useCallback(async () => {
    if (!selectedText || !pdfDocument) return;
    
    setIsKeywordSearching(true);
    setKeywordSearchError('');
    setKeywordSearchResults([]);
    setSearchResult(null); // Clear other results

    try {
      const results: number[] = [];
      const searchText = selectedText.toLowerCase();
      for (let i = 1; i <= pdfDocument.numPages; i++) {
        const page = await pdfDocument.getPage(i);
        const textContent = await page.getTextContent();
        const pageText = (textContent.items as { str: string }[])
          .map(item => item.str)
          .join(' ')
          .toLowerCase();
        
        if (pageText.includes(searchText)) {
          results.push(i);
        }
      }
      setKeywordSearchResults(results);
    } catch (err) {
        setKeywordSearchError('Gagal melakukan carian kata kunci dalam dokumen.');
    } finally {
        setIsKeywordSearching(false);
    }
  }, [selectedText, pdfDocument]);


  return (
    <div className="max-w-7xl mx-auto flex flex-col h-full">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6 flex-shrink-0">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
        <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
      </div>

      <div className="flex-grow flex flex-col md:flex-row gap-6 min-h-0">
        <div className="md:w-1/4 lg:w-1/5 flex flex-col space-y-4">
          <div 
            className="border-2 border-dashed border-slate-400 dark:border-slate-600 rounded-lg p-6 text-center cursor-pointer hover:border-blue-500 transition flex-grow flex flex-col justify-center"
            onClick={triggerFileSelect}
          >
            <input
              type="file"
              accept="application/pdf"
              ref={fileInputRef}
              onChange={handleFileChange}
              className="hidden"
            />
            <p className="text-slate-500 dark:text-slate-400">
              {file ? `Dimuatkan: ${file.name}` : 'Klik untuk memuat naik PDF'}
            </p>
            {file && <span className="text-xs text-slate-400 dark:text-slate-500 mt-1">Klik sekali lagi untuk menukar fail</span>}
          </div>
          <button
            onClick={handleSummarize}
            disabled={!pdfDocument || isSummarizing || !aiInstance}
            className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-md transition-colors duration-200"
          >
            {isSummarizing ? <LoadingSpinner /> : 'Ringkaskan Dokumen'}
          </button>
          <p className="text-xs text-slate-400 dark:text-slate-500 -mt-2 text-center">Tindakan AI tertakluk pada garis panduan kandungan selamat.</p>
          
          {pdfDocument && (
            <BookmarkPanel
                bookmarks={bookmarks}
                onJumpToPage={setCurrentPage}
                onDeleteBookmark={removeBookmark}
            />
          )}

          {error && <p className="text-red-500 dark:text-red-400 text-center text-sm">{error}</p>}
        </div>

        <div className="md:w-3/4 lg:w-4/5 flex-grow bg-slate-100 dark:bg-slate-900 rounded-lg shadow-inner overflow-hidden">
          {fileUrl ? (
            <PdfViewer 
                fileUrl={fileUrl}
                page={currentPage}
                onPageChange={setCurrentPage}
                onDocumentLoad={setPdfDocument} 
                onTextSelect={handleTextSelect}
                onAddBookmark={addBookmark}
                bookmarks={bookmarks}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <p className="text-slate-400 dark:text-slate-500">PDF anda akan dipaparkan di sini</p>
            </div>
          )}
        </div>
      </div>

      {selectedText && (
        <div className="fixed bottom-6 right-6 z-20 bg-white dark:bg-slate-800 shadow-2xl rounded-lg p-4 w-full max-w-lg border border-slate-200 dark:border-slate-600 animate-fadeInUp">
            <div className="flex justify-between items-start gap-4">
                <div>
                    <p className="text-sm font-medium text-slate-500 dark:text-slate-400">Teks Dipilih:</p>
                    <p className="text-slate-900 dark:text-white font-semibold mt-1 italic line-clamp-2">"{selectedText}"</p>
                </div>
                <button onClick={() => setSelectedText('')} className="text-slate-500 dark:text-slate-500 hover:text-slate-900 dark:hover:text-white" aria-label="Close selection"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3">
                <button onClick={handleSearchSelectedText} disabled={isSearching || !aiInstance} className="w-full flex items-center justify-center bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-600 text-white font-bold py-2 px-4 rounded-md transition">
                    {isSearching ? <LoadingSpinner className="w-5 h-5" /> : 'Penyelidikan AI'}
                </button>
                <button onClick={handleKeywordSearch} disabled={isKeywordSearching} className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 disabled:bg-slate-600 text-white font-bold py-2 px-4 rounded-md transition">
                    {isKeywordSearching ? <LoadingSpinner className="w-5 h-5" /> : 'Cari dalam Teks'}
                </button>
            </div>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-3 text-center">Pastikan teks yang dipilih mematuhi garis panduan kandungan selamat sebelum menggunakan Penyelidikan AI.</p>
        </div>
      )}
      
      {(isSearching || searchResult || searchError) && (
        <div className="mt-8">
            <SearchResultDisplay
                isLoading={isSearching}
                result={searchResult}
                error={searchError}
                toolName={t(tool.nameKey)}
                onShareToSocials={onShareToSocials}
            />
        </div>
      )}

      {(isKeywordSearching || keywordSearchResults.length > 0 || keywordSearchError) && (
        <div className="mt-8">
            <KeywordSearchResultPanel
                isLoading={isKeywordSearching}
                results={keywordSearchResults}
                error={keywordSearchError}
                onJumpToPage={setCurrentPage}
            />
        </div>
       )}

      <SummaryModal 
        isOpen={isSummaryModalOpen}
        onClose={() => setIsSummaryModalOpen(false)}
        summary={summary}
        isLoading={isSummarizing}
        onShareToSocials={onShareToSocials}
      />
    </div>
  );
};

export default EbookReaderView;