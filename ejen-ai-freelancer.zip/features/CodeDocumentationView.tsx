import React, { useState, useCallback, useRef } from 'react';
import type { Tool } from '../types';
import { useGemini } from '../contexts/GeminiContext';
import { generateText, fetchCodeFromUrl } from '../services/geminiService';
import { parseFileForText } from '../utils/fileParsers';
import LoadingSpinner from '../components/LoadingSpinner';
import MarkdownRenderer from '../components/MarkdownRenderer';
import { useLanguage } from '../contexts/LanguageContext';

interface CodeDocumentationViewProps {
  tool: Tool;
  onShareToSocials: (content: string) => void;
}

type InputMode = 'code' | 'file' | 'url';

const CodeDocumentationView: React.FC<CodeDocumentationViewProps> = ({ tool, onShareToSocials }) => {
  const { aiInstance } = useGemini();
  const { uiLang, t } = useLanguage();

  const [inputMode, setInputMode] = useState<InputMode>('code');
  const [code, setCode] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [parsedFileContent, setParsedFileContent] = useState<string | null>(null);
  const [url, setUrl] = useState('');
  
  const [result, setResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isParsing, setIsParsing] = useState(false);
  const [isFetchingUrl, setIsFetchingUrl] = useState(false);
  const [error, setError] = useState('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    setFile(selectedFile);
    setIsParsing(true);
    setError('');
    setParsedFileContent(null);

    try {
      const content = await parseFileForText(selectedFile);
      setParsedFileContent(content);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Gagal memparsing fail.');
      setFile(null);
    } finally {
      setIsParsing(false);
    }
  };

  const handleGenerate = useCallback(async () => {
    if (!aiInstance) {
        setError('Sila tetapkan Kunci API Gemini anda.');
        return;
    }
    
    setIsLoading(true);
    setError('');
    setResult('');
    
    try {
        let codeToDocument = '';
        
        if (inputMode === 'code') {
            if (!code.trim()) throw new Error('Sila masukkan kod untuk didokumenkan.');
            codeToDocument = code;
        } else if (inputMode === 'file') {
            if (!parsedFileContent) throw new Error('Fail belum diparsing atau kosong.');
            codeToDocument = parsedFileContent;
        } else if (inputMode === 'url') {
            if (!url.trim()) throw new Error('Sila masukkan URL.');
            setIsFetchingUrl(true);
            try {
                codeToDocument = await fetchCodeFromUrl(aiInstance, url);
            } catch (fetchErr) {
                throw new Error(t('codeDoc.fetchError'));
            } finally {
                setIsFetchingUrl(false);
            }
        }

        if (!codeToDocument.trim()) {
            throw new Error('Tiada kandungan kod ditemui untuk didokumenkan.');
        }

        const instruction = tool.systemInstruction?.[uiLang];
        const generatedText = await generateText(aiInstance, codeToDocument, instruction);
        setResult(generatedText);

    } catch (err) {
        setError(err instanceof Error ? err.message : 'Ralat tidak dijangka.');
    } finally {
        setIsLoading(false);
    }
  }, [aiInstance, code, parsedFileContent, url, inputMode, tool.systemInstruction, uiLang, t]);

  const handleExport = (format: 'txt' | 'md') => {
    if (!result) return;
    const fileName = `dokumentasi_kod_${Date.now()}.${format}`;
    const blob = new Blob([result], { type: format === 'md' ? 'text/markdown' : 'text/plain' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
        <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
      </div>

      <div className="space-y-6">
        <div className="flex justify-start bg-slate-200 dark:bg-slate-700/50 rounded-lg p-1 w-max">
            {(['code', 'file', 'url'] as InputMode[]).map(mode => (
                <button
                    key={mode}
                    onClick={() => setInputMode(mode)}
                    className={`py-1 px-4 rounded-md text-sm font-semibold transition-colors ${
                        inputMode === mode ? 'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-600'
                    }`}
                >
                    {t(`codeDoc.${mode}Input`)}
                </button>
            ))}
        </div>

        <div>
            {inputMode === 'code' && (
                <textarea
                    rows={12}
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full bg-slate-900 text-white font-mono p-3 rounded-md border border-slate-700 focus:ring-2 focus:ring-blue-500"
                    placeholder={t('codeDoc.codePlaceholder')}
                />
            )}
            {inputMode === 'file' && (
                <div className="space-y-3">
                    <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
                    <button onClick={() => fileInputRef.current?.click()} className="flex items-center justify-center bg-slate-200 hover:bg-slate-300 text-slate-700 dark:bg-slate-600 dark:hover:bg-slate-500 dark:text-white font-medium py-2 px-4 rounded-md">
                        {t('codeDoc.selectFile')}
                    </button>
                    {isParsing && <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400"><LoadingSpinner className="w-4 h-4" /><span>{t('codeDoc.parsingFile')}</span></div>}
                    {file && !isParsing && <p className="text-sm text-slate-600 dark:text-slate-300">Fail dipilih: {file.name}</p>}
                </div>
            )}
            {inputMode === 'url' && (
                <input
                    type="url"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    className="w-full bg-slate-100 dark:bg-slate-700 p-3 rounded-md border border-slate-300 dark:border-slate-600 focus:ring-2 focus:ring-blue-500"
                    placeholder={t('codeDoc.urlPlaceholder')}
                />
            )}
        </div>

        <button onClick={handleGenerate} disabled={isLoading || isParsing || isFetchingUrl || !aiInstance} className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-md disabled:bg-slate-500">
            {isLoading || isFetchingUrl ? <LoadingSpinner /> : 'Jana Dokumentasi'}
            {isFetchingUrl && <span className="ml-2">{t('codeDoc.fetchingUrl')}</span>}
        </button>

        {error && <p className="text-red-500 dark:text-red-400 text-center">{error}</p>}
      </div>

      {result && (
        <div className="mt-8 bg-white dark:bg-slate-800 rounded-lg shadow-lg">
          <div className="flex justify-between items-center p-4 border-b border-slate-200 dark:border-slate-700">
            <h3 className="text-xl font-bold">Dokumentasi yang Dijana</h3>
            <div className="flex items-center gap-2">
                <button onClick={() => handleExport('txt')} className="text-sm bg-green-600 hover:bg-green-500 text-white font-medium py-1 px-3 rounded-md">Eksport .txt</button>
                <button onClick={() => handleExport('md')} className="text-sm bg-green-600 hover:bg-green-500 text-white font-medium py-1 px-3 rounded-md">Eksport .md</button>
            </div>
          </div>
          <div className="p-6">
            <MarkdownRenderer content={result} />
          </div>
        </div>
      )}
    </div>
  );
};

export default CodeDocumentationView;