import React, { useState } from 'react';
import type { Tool, Project } from '../types';
import { useProjects } from '../hooks/useProjects';
import ProjectCard from '../components/ProjectCard';
import ProjectModal from '../components/ProjectModal';
import CalendarView from '../components/CalendarView';
import { useLanguage } from '../contexts/LanguageContext';

interface ProjectManagerViewProps {
  tool: Tool;
}

const ProjectManagerView: React.FC<ProjectManagerViewProps> = ({ tool }) => {
  const { projects, addProject, updateProject, deleteProject } = useProjects();
  const { t } = useLanguage();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [viewMode, setViewMode] = useState<'list' | 'calendar'>('list');

  const handleOpenModalForCreate = () => {
    setEditingProject(null);
    setIsModalOpen(true);
  };

  const handleOpenModalForEdit = (project: Project) => {
    setEditingProject(project);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingProject(null);
  };

  const handleSaveProject = (projectData: Omit<Project, 'id'>) => {
    if (editingProject) {
      updateProject({ ...projectData, id: editingProject.id });
    } else {
      addProject(projectData);
    }
    handleCloseModal();
  };

  const handleDeleteProject = (projectId: string) => {
    if (window.confirm('Adakah anda pasti mahu memadamkan projek ini? Tindakan ini tidak boleh dibuat asal.')) {
        deleteProject(projectId);
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
        <div className="flex justify-between items-start mb-4">
            <div>
                <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
                <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
            </div>
            <button
              onClick={handleOpenModalForCreate}
              className="flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-md transition-all duration-200 hover:scale-105 active:scale-95 flex-shrink-0"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
              Tambah Projek Baru
            </button>
        </div>
        <div className="flex justify-start bg-slate-200 dark:bg-slate-700/50 rounded-lg p-1 w-max">
            <button
              onClick={() => setViewMode('list')}
              className={`py-1 px-4 rounded-md text-sm font-semibold transition-colors ${
                viewMode === 'list' ? 'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-600'
              }`}
            >
              Senarai
            </button>
            <button
              onClick={() => setViewMode('calendar')}
              className={`py-1 px-4 rounded-md text-sm font-semibold transition-colors ${
                viewMode === 'calendar' ? 'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-600'
              }`}
            >
              Kalendar
            </button>
        </div>
      </div>

      {viewMode === 'list' && (
        projects.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map(project => (
              <ProjectCard
                key={project.id}
                project={project}
                onEdit={() => handleOpenModalForEdit(project)}
                onDelete={() => handleDeleteProject(project.id)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-white dark:bg-slate-800/50 rounded-lg">
            <h3 className="text-xl font-semibold text-slate-900 dark:text-white">Tiada Projek Ditemui</h3>
            <p className="text-slate-500 dark:text-slate-400 mt-2">Mula dengan menambah projek pertama anda!</p>
          </div>
        )
      )}

      {viewMode === 'calendar' && (
        <CalendarView projects={projects} />
      )}

      <ProjectModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onSave={handleSaveProject}
        project={editingProject}
      />
    </div>
  );
};

export default ProjectManagerView;