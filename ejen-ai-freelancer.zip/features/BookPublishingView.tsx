import React, { useState, useCallback, useRef, useEffect } from 'react';
import type { Tool } from '../types';
import { useGemini } from '../contexts/GeminiContext';
import { generateTextWithThinking } from '../services/geminiService';
import LoadingSpinner from '../components/LoadingSpinner';
import MarkdownRenderer from '../components/MarkdownRenderer';
import { useLanguage } from '../contexts/LanguageContext';

interface BookPublishingViewProps {
  tool: Tool;
  onShareToSocials: (content: string) => void;
}

type SubTool = 'outline' | 'chapter' | 'character' | 'synopsis' | 'proposal';

const BookPublishingView: React.FC<BookPublishingViewProps> = ({ tool, onShareToSocials }) => {
  const { aiInstance } = useGemini();
  const { uiLang, t } = useLanguage();
  
  const [activeSubTool, setActiveSubTool] = useState<SubTool>('outline');

  // --- Input State ---
  const [outlineIdea, setOutlineIdea] = useState('');
  const [outlineGenre, setOutlineGenre] = useState('');
  const [outlineAudience, setOutlineAudience] = useState('');

  const [chapterTitle, setChapterTitle] = useState('');
  const [chapterPlotPoints, setChapterPlotPoints] = useState('');
  const [chapterStyle, setChapterStyle] = useState('');
  const [chapterWordCount, setChapterWordCount] = useState('');

  const [charName, setCharName] = useState('');
  const [charTraits, setCharTraits] = useState('');

  const [synopsisSummary, setSynopsisSummary] = useState('');
  const [proposalSummary, setProposalSummary] = useState('');

  // --- Common State ---
  const [result, setResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const resultRef = useRef<HTMLDivElement>(null);

  const handleGenerate = useCallback(async () => {
    if (!aiInstance) {
      setError('Sila tetapkan Kunci API Gemini anda.');
      return;
    }
    
    setIsLoading(true);
    setError('');
    setResult('');

    let prompt = '';
    let systemInstruction = '';

    try {
        switch(activeSubTool) {
            case 'outline':
                if (!outlineIdea.trim()) throw new Error('Sila masukkan idea buku atau tema.');
                prompt = `Book Idea/Theme: ${outlineIdea}\nGenre: ${outlineGenre}\nTarget Audience: ${outlineAudience}`;
                systemInstruction = `Anda adalah pakar merangka buku. Berdasarkan idea, genre, dan sasaran audiens pengguna, cipta rangka buku yang terperinci dan tersusun rapi dalam format Markdown. **Semua output MESTI dalam Bahasa Malaysia.** Rangka tersebut harus merangkumi bahagian (jika berkenaan), bab dengan tajuk deskriptif, dan butiran ringkas di bawah setiap bab yang mencadangkan plot utama, topik, atau babak. Pastikan tajuk bab menggunakan tajuk ## atau ###. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti 'Ia bukan X, tetapi Y' atau 'Ia bukan X. Ia adalah Y.'.`;
                break;
            case 'chapter':
                if (!chapterTitle.trim()) throw new Error('Sila masukkan tajuk bab atau topik.');
                let chapterPrompt = `Chapter Title/Topic: ${chapterTitle}\nKey Plot Points/Keywords: ${chapterPlotPoints}\nWriting Style/Tone: ${chapterStyle}`;
                if (chapterWordCount) {
                    chapterPrompt += `\nTarget Word Count: ~${chapterWordCount} words`;
                }
                prompt = chapterPrompt;
                systemInstruction = `Anda adalah seorang penulis jemputan yang pakar. Tulis sebuah bab buku yang menarik berdasarkan tajuk/topik yang diberikan. Jika disediakan, masukkan isi plot utama dan patuhi gaya penulisan yang dinyatakan. Jika jumlah perkataan sasaran diberikan, cuba patuhi anggaran tersebut. **Semua output MESTI dalam Bahasa Malaysia.** Bab tersebut hendaklah menarik, mempunyai rentak yang baik, dan konsisten dengan format buku. Output hendaklah dalam format Markdown. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti 'Ia bukan X, tetapi Y' atau 'Ia bukan X. Ia adalah Y.'.`;
                break;
            case 'character':
                if (!charName.trim()) throw new Error('Sila masukkan nama watak.');
                prompt = `Character Name: ${charName}\nBasic Traits/Role: ${charTraits}`;
                systemInstruction = `Anda adalah pakar pembangunan watak. Cipta profil watak yang terperinci berdasarkan nama dan sifat asas yang diberikan. **Semua output MESTI dalam Bahasa Malaysia.** Profil tersebut hendaklah dalam format Markdown dan merangkumi bahagian-bahagian untuk: Penampilan Fizikal, Sifat Personaliti, Latar Belakang, Motivasi/Matlamat, dan Hubungan Penting. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti 'Ia bukan X, tetapi Y' atau 'Ia bukan X. Ia adalah Y.'.`;
                break;
            case 'synopsis':
                if (!synopsisSummary.trim()) throw new Error('Sila masukkan ringkasan plot utama.');
                prompt = `Main Plot Summary:\n${synopsisSummary}`;
                systemInstruction = `Anda adalah seorang penulis iklan profesional yang pakar dalam blurb buku. Berdasarkan ringkasan plot yang diberikan, tulis sinopsis buku yang menawan dan persuasif (sekitar 150-200 patah perkataan) yang sesuai untuk kulit belakang buku. **Semua output MESTI dalam Bahasa Malaysia.** Ia harus memperkenalkan watak utama, konflik utama, dan pertaruhan, diakhiri dengan cangkuk untuk menarik minat pembaca. Output hendaklah dalam format Markdown. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti 'Ia bukan X, tetapi Y' atau 'Ia bukan X. Ia adalah Y.'.`;
                break;
            case 'proposal':
                if (!proposalSummary.trim()) throw new Error('Sila masukkan ringkasan plot penuh.');
                prompt = `Main Plot Summary (including spoilers and ending):\n${proposalSummary}`;
                systemInstruction = `Anda adalah pembantu ejen sastera yang pakar. Berdasarkan ringkasan plot yang diberikan, cipta cadangan buku yang komprehensif dalam format Markdown. **Semua output MESTI dalam Bahasa Malaysia.** Cadangan tersebut mesti merangkumi bahagian-bahagian berikut, setiap satu dilabelkan dengan jelas menggunakan tajuk: **Logline**, **Premis**, **Sinopsis Penuh** (ringkasan terperinci keseluruhan plot, termasuk pengakhiran), dan **Sinopsis Bab-demi-Bab**. Untuk sinopsis bab, berikan ringkasan satu atau dua ayat yang ringkas untuk *setiap bab* yang diperlukan untuk merangkumi keseluruhan plot. Jangan meringkaskan atau memotong senarai bab. Jika plot membayangkan 35 bab, anda mesti mengeluarkan kesemua 35 ringkasan bab. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti 'Ia bukan X, tetapi Y' atau 'Ia bukan X. Ia adalah Y.'.`;
                break;
        }

        const generatedText = await generateTextWithThinking(aiInstance, prompt, systemInstruction);
        setResult(generatedText);
    } catch (err) {
        setError(err instanceof Error ? err.message : 'Ralat tidak dijangka.');
    } finally {
        setIsLoading(false);
    }
  }, [aiInstance, activeSubTool, outlineIdea, outlineGenre, outlineAudience, chapterTitle, chapterPlotPoints, chapterStyle, chapterWordCount, charName, charTraits, synopsisSummary, proposalSummary]);

  const handleChapterClick = useCallback((title: string) => {
    setActiveSubTool('chapter');
    setChapterTitle(title);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  useEffect(() => {
    const handleClick = (event: MouseEvent) => {
        if (activeSubTool === 'outline' && result) {
            const target = event.target as HTMLElement;
            const heading = target.closest('h2, h3');
            if (heading && heading.textContent) {
                const title = heading.textContent.replace(/^#+\s*/, '');
                handleChapterClick(title);
            }
        }
    };
    
    const container = resultRef.current;
    container?.addEventListener('click', handleClick);

    return () => {
        container?.removeEventListener('click', handleClick);
    };
  }, [activeSubTool, result, handleChapterClick]);

  const renderInputs = () => {
    switch(activeSubTool) {
        case 'outline':
            return (
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium">Idea Buku / Tema</label>
                        <textarea rows={3} value={outlineIdea} onChange={e => setOutlineIdea(e.target.value)} className="w-full mt-1 p-2 bg-slate-100 dark:bg-slate-700 rounded-md" placeholder="cth., Novel fantasi tentang naga di angkasa lepas" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium">Genre</label>
                        <input type="text" value={outlineGenre} onChange={e => setOutlineGenre(e.target.value)} className="w-full mt-1 p-2 bg-slate-100 dark:bg-slate-700 rounded-md" placeholder="cth., Fiksyen Sains, Fantasi Epik" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium">Sasaran Audiens</label>
                        <input type="text" value={outlineAudience} onChange={e => setOutlineAudience(e.target.value)} className="w-full mt-1 p-2 bg-slate-100 dark:bg-slate-700 rounded-md" placeholder="cth., Dewasa muda, Peminat Hard Sci-Fi" />
                    </div>
                </div>
            );
        case 'chapter':
             return (
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium">Tajuk Bab / Topik</label>
                        <input type="text" value={chapterTitle} onChange={e => setChapterTitle(e.target.value)} className="w-full mt-1 p-2 bg-slate-100 dark:bg-slate-700 rounded-md" placeholder="cth., Bab 1: Penemuan" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium">Isi Penting / Kata Kunci (Pilihan)</label>
                        <textarea rows={3} value={chapterPlotPoints} onChange={e => setChapterPlotPoints(e.target.value)} className="w-full mt-1 p-2 bg-slate-100 dark:bg-slate-700 rounded-md" placeholder="cth., watak utama menemui artifak purba, menerima mesej misteri" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium">Gaya Penulisan (Pilihan)</label>
                            <input type="text" value={chapterStyle} onChange={e => setChapterStyle(e.target.value)} className="w-full mt-1 p-2 bg-slate-100 dark:bg-slate-700 rounded-md" placeholder="cth., tegang, penuh aksi" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium">Jumlah Perkataan (Pilihan)</label>
                            <input type="number" value={chapterWordCount} onChange={e => setChapterWordCount(e.target.value)} className="w-full mt-1 p-2 bg-slate-100 dark:bg-slate-700 rounded-md" placeholder="cth., 1500" />
                        </div>
                    </div>
                </div>
            );
        case 'character':
            return (
                <div className="space-y-4">
                     <div>
                        <label className="block text-sm font-medium">Nama Watak</label>
                        <input type="text" value={charName} onChange={e => setCharName(e.target.value)} className="w-full mt-1 p-2 bg-slate-100 dark:bg-slate-700 rounded-md" placeholder="cth., Elara Vance" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium">Sifat Asas / Peranan</label>
                        <textarea rows={3} value={charTraits} onChange={e => setCharTraits(e.target.value)} className="w-full mt-1 p-2 bg-slate-100 dark:bg-slate-700 rounded-md" placeholder="cth., Protagonis, ahli sihir muda yang keberatan dari sebuah kampung kecil" />
                    </div>
                </div>
            );
        case 'synopsis':
            return (
                 <div>
                    <label className="block text-sm font-medium">Ringkasan Plot Utama</label>
                    <textarea rows={6} value={synopsisSummary} onChange={e => setSynopsisSummary(e.target.value)} className="w-full mt-1 p-2 bg-slate-100 dark:bg-slate-700 rounded-md" placeholder="Tampal ringkasan buku anda atau perihalan plot di sini..." />
                </div>
            );
        case 'proposal':
            return (
                 <div>
                    <label className="block text-sm font-medium">Ringkasan Plot Penuh (termasuk pengakhiran)</label>
                    <textarea rows={6} value={proposalSummary} onChange={e => setProposalSummary(e.target.value)} className="w-full mt-1 p-2 bg-slate-100 dark:bg-slate-700 rounded-md" placeholder="Tampal ringkasan penuh buku anda di sini, dari awal hingga akhir..." />
                </div>
            );
    }
  }

  const subTools: { id: SubTool, name: string }[] = [
      { id: 'outline', name: 'Rangka Buku' },
      { id: 'chapter', name: 'Penulis Bab' },
      { id: 'character', name: 'Profil Watak' },
      { id: 'synopsis', name: 'Penulis Sinopsis' },
      { id: 'proposal', name: 'Proposal Buku' },
  ];
  
  const currentToolName = subTools.find(st => st.id === activeSubTool)?.name;

  return (
    <div className="max-w-7xl mx-auto">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
        <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Panel: Inputs */}
        <div className="lg:col-span-1 space-y-6">
            <div className="flex flex-col sm:flex-row lg:flex-col gap-2 rounded-lg bg-slate-100 dark:bg-slate-900/50 p-1">
                {subTools.map(st => (
                    <button
                        key={st.id}
                        onClick={() => setActiveSubTool(st.id)}
                        className={`flex-1 py-2 px-3 text-sm font-semibold rounded-md transition-colors text-center ${activeSubTool === st.id ? 'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'}`}
                    >
                        {st.name}
                    </button>
                ))}
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-lg space-y-4 text-slate-800 dark:text-slate-200">
                {renderInputs()}
            </div>
            
            <button onClick={handleGenerate} disabled={isLoading || !aiInstance} className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-md disabled:bg-slate-500">
              {isLoading ? <LoadingSpinner /> : `Jana ${currentToolName}`}
            </button>
            {error && <p className="text-red-500 dark:text-red-400 text-center">{error}</p>}
        </div>

        {/* Right Panel: Results */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white">Hasil</h3>
                {result && (
                    <button onClick={() => onShareToSocials(result)} title="Hantar ke Pengurus Kandungan" className="text-sm bg-purple-600 hover:bg-purple-500 text-white font-medium py-2 px-4 rounded-md transition-all">
                        Hantar
                    </button>
                )}
            </div>

            {isLoading ? (
                <div className="flex flex-col items-center justify-center min-h-[400px]">
                    <LoadingSpinner className="w-10 h-10" />
                    <p className="mt-4 text-slate-500 dark:text-slate-400">Menulis...</p>
                </div>
            ) : result ? (
                 <div
                    ref={resultRef}
                    className={`max-h-[70vh] overflow-y-auto pr-2 ${activeSubTool === 'outline' ? 'cursor-pointer' : ''}`}
                >
                    {activeSubTool === 'outline' && 
                        <div className="mb-4 p-3 bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300 text-sm rounded-lg border border-blue-200 dark:border-blue-800">
                           💡 Petua: Klik pada mana-mana tajuk bab dalam rangka di bawah untuk mula menulis bab tersebut secara automatik!
                        </div>
                    }
                    <MarkdownRenderer content={result} />
                </div>
            ) : (
                 <div className="flex flex-col items-center justify-center min-h-[400px] text-center text-slate-500 dark:text-slate-400">
                    <p>Hasil anda akan muncul di sini.</p>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default BookPublishingView;