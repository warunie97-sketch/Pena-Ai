import React, { useState, useEffect, useCallback } from 'react';
import type { Tool, SocialPost, ContentIdea, SocialPlatform } from '../types';
import CalendarView from '../components/CalendarView';
import { useGemini } from '../contexts/GeminiContext';
import { generateContentPlan } from '../services/geminiService';
import LoadingSpinner from '../components/LoadingSpinner';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import MarkdownRenderer from '../components/MarkdownRenderer';

interface ContentManagerViewProps {
  tool: Tool;
  sharedContent: string;
  clearSharedContent: () => void;
}

const useSocialPosts = (key: string | null) => {
    const [posts, setPosts] = useState<SocialPost[]>([]);

    useEffect(() => {
        if (!key) return;
        try {
            const stored = localStorage.getItem(key);
            if (stored) setPosts(JSON.parse(stored));
        } catch (e) {
            console.error("Failed to load posts", e);
        }
    }, [key]);

    const addPost = useCallback((postData: Omit<SocialPost, 'id'>) => {
        setPosts(prev => {
            const newPost = { ...postData, id: Date.now().toString() };
            const updatedPosts = [...prev, newPost];
            if (key) localStorage.setItem(key, JSON.stringify(updatedPosts));
            return updatedPosts;
        });
    }, [key]);

    return { posts, addPost };
};

const ScheduleModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onSave: (post: Omit<SocialPost, 'id'>) => void;
  initialContent: string;
  t: (key: string, replacements?: Record<string, string | number>) => string;
}> = ({ isOpen, onClose, onSave, initialContent, t }) => {
  const [content, setContent] = useState('');
  const [platform, setPlatform] = useState<SocialPlatform>('Facebook');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  useEffect(() => {
    setContent(initialContent);
    // Reset other fields for new post
    setDate(new Date().toISOString().split('T')[0]);
    setPlatform('Facebook');
  }, [initialContent, isOpen]);

  if (!isOpen) return null;

  const handleSave = () => {
    onSave({ content, platform, scheduledDate: date });
    onClose();
  };
  
  const handleOverlayClick = (e: React.MouseEvent) => {
      if (e.target === e.currentTarget) onClose();
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4" onClick={handleOverlayClick}>
        <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-lg" onClick={e => e.stopPropagation()}>
            <div className="p-6 border-b border-slate-200 dark:border-slate-700">
                <h2 className="text-2xl font-bold text-slate-900 dark:text-white">{t('tools.content_management.schedulingPost')}</h2>
            </div>
            <div className="p-6 space-y-4">
                <div>
                    <label htmlFor="post-content" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">{t('tools.content_management.postContent')}</label>
                    <textarea id="post-content" rows={6} value={content} onChange={e => setContent(e.target.value)} className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-2" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="platform" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">{t('tools.content_management.platform')}</label>
                        <select id="platform" value={platform} onChange={e => setPlatform(e.target.value as SocialPlatform)} className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-2">
                            <option>Facebook</option>
                            <option>Twitter</option>
                            <option>Instagram</option>
                            <option>LinkedIn</option>
                        </select>
                    </div>
                    <div>
                        <label htmlFor="date" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">{t('tools.content_management.date')}</label>
                        <input id="date" type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-2" />
                    </div>
                </div>
            </div>
            <div className="p-4 bg-slate-100 dark:bg-slate-900/50 flex justify-end gap-3 rounded-b-lg">
                <button onClick={onClose} className="bg-slate-200 hover:bg-slate-300 text-slate-800 dark:bg-slate-600 dark:hover:bg-slate-500 dark:text-white font-medium py-2 px-4 rounded-md">{t('tools.content_management.close')}</button>
                <button onClick={handleSave} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-md">{t('tools.content_management.saveSchedule')}</button>
            </div>
        </div>
    </div>
  );
};

const ContentManagerView: React.FC<ContentManagerViewProps> = ({ tool, sharedContent, clearSharedContent }) => {
    const { aiInstance } = useGemini();
    const { currentUser } = useAuth();
    const { t, aiLang } = useLanguage();
    const storageKey = currentUser ? `content_manager_posts_${currentUser.id}` : null;
    const { posts, addPost } = useSocialPosts(storageKey);
    
    const [topic, setTopic] = useState('');
    const [ideas, setIdeas] = useState<ContentIdea[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [schedulingContent, setSchedulingContent] = useState('');

    useEffect(() => {
        if (sharedContent) {
            handleSchedule(sharedContent);
            clearSharedContent();
        }
    }, [sharedContent, clearSharedContent]);

    const handleGeneratePlan = useCallback(async () => {
        if (!aiInstance) {
            setError('Sila tetapkan Kunci API Gemini anda.');
            return;
        }
        if (!topic.trim()) {
            setError('Sila masukkan topik utama.');
            return;
        }
        setIsLoading(true);
        setError('');
        setIdeas([]);
        try {
            const plan = await generateContentPlan(aiInstance, topic, aiLang);
            setIdeas(plan);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Gagal menjana pelan kandungan.');
        } finally {
            setIsLoading(false);
        }
    }, [aiInstance, topic, aiLang]);

    const handleSchedule = (content: string) => {
        setSchedulingContent(content);
        setIsModalOpen(true);
    };

    const handleSavePost = (postData: Omit<SocialPost, 'id'>) => {
        addPost(postData);
    };
    
    const calendarProjects = posts.map(p => ({
        id: p.id,
        name: `[${p.platform}] ${p.content.substring(0, 30)}...`,
        deadline: p.scheduledDate,
        client: p.platform,
        status: 'Dalam Proses' as const,
        priority: 'Sederhana' as const,
        assignee: '', estimatedHours: 0, notes: p.content,
    }));


    return (
        <div className="max-w-7xl mx-auto">
            <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
                <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
                <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-1 space-y-6">
                    <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg">
                        <h3 className="text-xl font-bold mb-4">{t('tools.content_management.generatePlan')}</h3>
                        <div>
                            <label htmlFor="topic-input" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">{t('tools.content_management.mainTopic')}</label>
                            <input id="topic-input" type="text" value={topic} onChange={e => setTopic(e.target.value)} className="w-full bg-slate-100 dark:bg-slate-700 p-3 rounded-md border border-slate-300 dark:border-slate-600" placeholder={t('tools.content_management.topicPlaceholder')} />
                        </div>
                        <button onClick={handleGeneratePlan} disabled={isLoading || !aiInstance} className="w-full mt-4 flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-md disabled:bg-slate-500">
                            {isLoading ? <LoadingSpinner /> : t('tools.content_management.generatePlan')}
                        </button>
                        {error && <p className="text-red-500 dark:text-red-400 text-center mt-2 text-sm">{error}</p>}
                    </div>
                    {ideas.length > 0 && (
                        <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg">
                            <h3 className="text-xl font-bold mb-4">{t('tools.content_management.planSuggestions')}</h3>
                            <div className="max-h-96 overflow-y-auto space-y-4">
                                {ideas.map(idea => (
                                    <div key={idea.day} className="bg-slate-100 dark:bg-slate-900/50 p-3 rounded-md">
                                        <p className="font-bold text-sm">Hari {idea.day}: {idea.topic_idea}</p>
                                        <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 italic">"{idea.post_draft}"</p>
                                        <button onClick={() => handleSchedule(idea.post_draft)} className="text-xs mt-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-1 px-3 rounded-md">{t('tools.content_management.schedulePost')}</button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
                <div className="lg:col-span-2">
                    <CalendarView projects={calendarProjects} />
                </div>
            </div>

            <ScheduleModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSavePost}
                initialContent={schedulingContent}
                t={t}
            />
        </div>
    );
};

export default ContentManagerView;