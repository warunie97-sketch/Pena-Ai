import React, { useState, useCallback, useEffect, useRef } from 'react';
import type { Tool } from '../types';
import { useGemini } from '../contexts/GeminiContext';
import { generateTextFromVideo } from '../services/geminiService';
import LoadingSpinner from '../components/LoadingSpinner';
import MarkdownRenderer from '../components/MarkdownRenderer';
import { useLanguage } from '../contexts/LanguageContext';

interface VideoAnalysisViewProps {
  tool: Tool;
  onShareToSocials: (content: string) => void;
}

const VideoAnalysisView: React.FC<VideoAnalysisViewProps> = ({ tool, onShareToSocials }) => {
  const { aiInstance } = useGemini();
  const { t } = useLanguage();
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('Transkripsikan audio dalam video ini.');
  const [result, setResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    return () => {
        if(videoPreviewUrl) {
            URL.revokeObjectURL(videoPreviewUrl);
        }
    }
  }, [videoPreviewUrl]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('video/')) {
      setVideoFile(file);
      const url = URL.createObjectURL(file);
      if (videoPreviewUrl) URL.revokeObjectURL(videoPreviewUrl);
      setVideoPreviewUrl(url);
      setError('');
    } else if (file) {
      setError('Sila pilih fail video yang sah.');
      setVideoFile(null);
      setVideoPreviewUrl(null);
    } else {
        setVideoFile(null);
        setVideoPreviewUrl(null);
    }
  };
  
  const handleGenerate = useCallback(async () => {
    if (!aiInstance) {
      setError('Sila tetapkan Kunci API Gemini anda.');
      return;
    }
    if (!videoFile) {
      setError('Sila muat naik fail video.');
      return;
    }
    setIsLoading(true);
    setError('');
    try {
      const generatedText = await generateTextFromVideo(aiInstance, prompt, videoFile);
      setResult(generatedText);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Ralat tidak dijangka.');
    } finally {
      setIsLoading(false);
    }
  }, [aiInstance, videoFile, prompt]);

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
        <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Muat Naik Video</label>
          <input ref={fileInputRef} type="file" accept="video/*" onChange={handleFileChange} className="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"/>
        </div>

        {videoPreviewUrl && (
          <video src={videoPreviewUrl} controls className="w-full rounded-lg" />
        )}
        
        <div>
          <label htmlFor="prompt-video" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Permintaan Anda</label>
          <textarea id="prompt-video" rows={3} value={prompt} onChange={e => setPrompt(e.target.value)} className="w-full bg-slate-100 dark:bg-slate-700 p-2 rounded-md" />
        </div>

        <button onClick={handleGenerate} disabled={isLoading || !videoFile || !aiInstance} className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-md disabled:bg-slate-500">
          {isLoading ? <LoadingSpinner /> : 'Analisis Video'}
        </button>

        {error && <p className="text-red-500 dark:text-red-400 text-center">{error}</p>}
      </div>
      
      {result && (
        <div className="mt-8 bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg">
          <h3 className="text-2xl font-bold mb-4">Hasil Analisis</h3>
          <MarkdownRenderer content={result} />
        </div>
      )}
    </div>
  );
};

export default VideoAnalysisView;
