import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import ToolUsageChart from '../components/ToolUsageChart';

const DashboardView: React.FC = () => {
    const { t } = useLanguage();
    const { currentUser } = useAuth();

  return (
    <div className="space-y-12">
      <div className="text-left">
        <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 dark:text-white mb-2 leading-tight">
          {t('dashboard.welcome')} {currentUser?.id && <span>, {currentUser.id}</span>}!
        </h1>
        <p className="text-lg text-slate-500 dark:text-slate-400">
          {t('dashboard.description')}
        </p>
      </div>

      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg">
          <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-4">{t('dashboard.topTools')}</h2>
          <ToolUsageChart />
      </div>
      
       <div className="bg-white/50 dark:bg-slate-800/50 p-8 rounded-lg shadow-lg text-center">
            <h2 className="text-2xl font-bold text-slate-800 dark:text-white">{t('dashboard.readyToCreate')}</h2>
            <p className="mt-2 text-slate-600 dark:text-slate-400">{t('dashboard.selectTool')}</p>
       </div>
    </div>
  );
};

export default DashboardView;