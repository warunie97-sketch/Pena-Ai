import React, { useState, useCallback, useRef, useEffect } from 'react';
import type { Tool } from '../types';
import { generateText, generateTextWithThinking } from '../services/geminiService';
import { parseFileForText } from '../utils/fileParsers';
import LoadingSpinner from '../components/LoadingSpinner';
import TranslationWidget from '../components/TranslationWidget';
import WordCount from '../components/WordCount';
import HistoryPanel from '../components/HistoryPanel';
import { useSpeechRecognition } from '../hooks/useSpeechRecognition';
import { useAutoSave } from '../hooks/useAutoSave';
import { useHistory } from '../hooks/useHistory';
import { useGemini } from '../contexts/GeminiContext';
import MarkdownToolbar from '../components/MarkdownToolbar';
import MarkdownRenderer from '../components/MarkdownRenderer';
import { useLanguage } from '../contexts/LanguageContext';
import ReadAloudButton from '../components/ReadAloudButton';

interface TextEditorViewProps {
  tool: Tool;
  onShareToSocials: (content: string) => void;
}

type EditAction = 'proofread' | 'summarize' | 'rephrase' | 'change-tone' | 'analyze-refine';

const PREDEFINED_TONES = ['Profesional', 'Santai', 'Jenaka', 'Formal'];

const TextEditorView: React.FC<TextEditorViewProps> = ({ tool, onShareToSocials }) => {
  const { aiInstance } = useGemini();
  const { t } = useLanguage();
  const [text, setText] = useState('');
  const [tone, setTone] = useState('');
  const [imageAttachment, setImageAttachment] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [documentAttachment, setDocumentAttachment] = useState<File | null>(null);
  const [extractedText, setExtractedText] = useState<string | null>(null);
  const [isParsing, setIsParsing] = useState(false);

  const [result, setResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [activeAction, setActiveAction] = useState<EditAction | null>(null);
  const [isThinkingMode, setIsThinkingMode] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const saveStatus = useAutoSave(`draft_${tool.id}`, text, setText);
  const { history, addHistoryItem, clearHistory } = useHistory(`history_${tool.id}`);

  const { isListening, startListening, stopListening, hasRecognitionSupport } = useSpeechRecognition(
    (transcript) => setText(prev => prev + transcript)
  );

  useEffect(() => {
    return () => {
      if (imagePreview) {
        URL.revokeObjectURL(imagePreview);
      }
    };
  }, [imagePreview]);
  
  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    handleRemoveAttachment();
    setError('');

    if (file.type.startsWith('image/')) {
      setImageAttachment(file);
      setImagePreview(URL.createObjectURL(file));
    } else {
      setDocumentAttachment(file);
      setIsParsing(true);
      try {
        const text = await parseFileForText(file);
        setExtractedText(text);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Gagal memparsing fail.');
        handleRemoveAttachment();
      } finally {
        setIsParsing(false);
      }
    }
  };

  const handleRemoveAttachment = () => {
    if (imagePreview) {
      URL.revokeObjectURL(imagePreview);
    }
    setImageAttachment(null);
    setImagePreview(null);
    setDocumentAttachment(null);
    setExtractedText(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleEdit = useCallback(async (action: EditAction) => {
    if (!aiInstance) {
      setError('Sila tetapkan Kunci API Gemini anda dalam pengepala.');
      return;
    }
    if (!text.trim()) {
      setError('Sila masukkan teks untuk disunting.');
      return;
    }
    if (action === 'change-tone' && !tone.trim()) {
      setError('Sila masukkan nada yang diingini.');
      return;
    }

    setIsLoading(true);
    setError('');
    setResult('');
    setActiveAction(action);
    addHistoryItem(text);
    
    let prompt = '';
    switch (action) {
      case 'proofread':
        prompt = `Anda adalah seorang penyemak pruf yang teliti. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti 'Ia bukan X, tetapi Y' atau 'Ia bukan X. Ia adalah Y.'. Semak pruf teks berikut untuk sebarang kesilapan tatabahasa, ejaan, tanda baca, atau kejanggalan ayat dalam Bahasa Malaysia.
Berikan jawapan anda dalam DUA bahagian:
1. **TEKS DIPERBAIKI**: Kembalikan versi teks yang bersih dan diperbetulkan sepenuhnya.
2. **ANALISIS PERUBAHAN**: Selepas teks yang diperbaiki, sediakan senarai terperinci bagi setiap perubahan yang dibuat. Bagi setiap perubahan, gunakan format berikut:
    - **Asal:** "[petik ayat atau frasa asal yang mengandungi kesilapan]"
    - **Diperbaiki:** "[tunjukkan ayat atau frasa yang telah diperbaiki]"
    - **Sebab:** "[jelaskan secara ringkas sebab pembetulan dibuat (cth., 'Kesalahan ejaan', 'Struktur ayat tidak betul', 'Tanda baca tidak tepat')]"

Teks asal:
"""
${text}
"""`;
        break;
      case 'summarize':
        prompt = `Ringkaskan teks berikut secara padat dalam Bahasa Malaysia. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti 'Ia bukan X, tetapi Y' atau 'Ia bukan X. Ia adalah Y.'.\n\nTeks: "${text}"`;
        break;
      case 'rephrase':
        prompt = `Anda adalah seorang editor yang pakar. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti 'Ia bukan X, tetapi Y' atau 'Ia bukan X. Ia adalah Y.'. Ubah ayat teks berikut untuk meningkatkan kejelasan, aliran, dan impak sambil mengekalkan makna asalnya. Pastikan teks akhir adalah dalam Bahasa Malaysia.
Berikan jawapan anda dalam DUA bahagian:
1. **TEKS DIUBAH AYAT**: Kembalikan versi teks yang bersih dan telah diubah ayat sepenuhnya.
2. **ANALISIS PERUBAHAN**: Selepas teks yang diubah ayat, sediakan senarai terperinci bagi setiap perubahan ketara yang dibuat. Bagi setiap perubahan, gunakan format berikut:
    - **Asal:** "[petik ayat atau frasa asal]"
    - **Diubah:** "[tunjukkan ayat atau frasa yang telah diubah]"
    - **Sebab:** "[jelaskan secara ringkas tujuan perubahan (cth., 'Untuk menjadikan ayat lebih ringkas dan padat', 'Menggunakan perkataan yang lebih berkesan', 'Memperbaiki aliran antara ayat')]"

Teks asal:
"""
${text}
"""`;
        break;
      case 'change-tone':
        prompt = `Anda adalah seorang pakar linguistik. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti 'Ia bukan X, tetapi Y' atau 'Ia bukan X. Ia adalah Y.'. Ubah nada teks berikut kepada "${tone}" sambil mengekalkan makna asalnya. Pastikan teks akhir adalah dalam Bahasa Malaysia.
Berikan jawapan anda dalam DUA bahagian:
1. **TEKS DIUBAH NADA**: Kembalikan versi teks yang bersih dan telah diubah nada sepenuhnya.
2. **ANALISIS PERUBAHAN**: Selepas teks yang diubah, sediakan senarai terperinci bagi setiap perubahan ketara yang dibuat untuk mencapai nada baharu. Bagi setiap perubahan, gunakan format berikut:
    - **Asal:** "[petik ayat atau frasa asal]"
    - **Diubah:** "[tunjukkan ayat atau frasa yang telah diubah]"
    - **Sebab:** "[jelaskan secara ringkas tujuan perubahan (cth., 'Menggantikan perkataan formal dengan sinonim yang lebih santai', 'Mengubah struktur ayat untuk bunyi yang lebih berjenaka', 'Menambah kata-kata sopan untuk nada profesional')]"

Teks asal:
"""
${text}
"""`;
        break;
      case 'analyze-refine':
        prompt = `Anda adalah seorang editor pakar dan jurulatih komunikasi. Tugas anda adalah untuk menganalisis dan memperhalusi teks berikut. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti 'Ia bukan X, tetapi Y' atau 'Ia bukan X. Ia adalah Y.'.

Sila berikan jawapan anda dalam TIGA bahagian yang jelas:

1.  **ANALISIS & CADANGAN NADA**:
    *   **Nada Asal**: Terangkan secara ringkas nada semasa teks (cth., "Tidak formal dan terus terang", "Teknikal tetapi sedikit tidak jelas").
    *   **Cadangan Nada**: Berdasarkan kandungan, cadangkan TIGA nada alternatif yang boleh meningkatkan mesej, dengan menerangkan faedah setiap satu. Format sebagai senarai:
        *   **Nada 1 (cth., Lebih Meyakinkan):** *Faedah:* "Nada ini akan lebih berkesan untuk salinan pemasaran, menggalakkan pembaca untuk mengambil tindakan."
        *   **Nada 2 (cth., Lebih Berempati):** *Faedah:* "Nada ini akan membina hubungan yang lebih kukuh dengan pelanggan yang mencari sokongan."
        *   **Nada 3 (cth., Lebih Mudah & Jelas):** *Faedah:* "Nada ini akan menjadikan maklumat kompleks lebih mudah diakses oleh audiens umum."

2.  **TEKS YANG DIPERHALUSI**:
    *   Pertama, semak pruf teks asal untuk sebarang kesilapan tatabahasa, ejaan, dan tanda baca.
    *   Kemudian, tulis semula teks yang telah diperbetulkan itu ke dalam satu versi yang diperbaiki dan tunggal. Versi ini harus mengamalkan nada yang secara amnya lebih profesional, jelas, dan berkesan, menggabungkan semangat cadangan terbaik anda. Jangan nyatakan secara eksplisit nada mana yang anda pilih; hanya berikan teks akhir yang telah digilap.

3.  **LOG PERUBAHAN TERPERINCI**:
    *   Sediakan senarai komprehensif bagi semua perubahan penting yang dibuat antara teks asal dan teks yang diperhalusi. Kelompokkan mereka ke dalam dua kategori: "Pembetulan" dan "Penambahbaikan Gaya & Nada".
    *   Untuk setiap perubahan, gunakan format ini:
        - **Asal:** "[petik frasa atau ayat asal]"
        - **Diperhalusi:** "[tunjukkan frasa atau ayat yang diperhalusi]"
        - **Sebab:** "[jelaskan mengapa perubahan itu dibuat (cth., 'Membetulkan kesilapan ejaan', 'Menyusun semula ayat untuk aliran yang lebih baik', 'Menggantikan jargon dengan istilah yang lebih mudah untuk meningkatkan kejelasan', 'Mengubah perkataan untuk bunyi yang lebih yakin dan profesional')]"

Teks asal untuk dianalisis dan diperhalusi:
"""
${text}
"""`;
        break;
    }

    try {
      let generatedText: string;
      if (isThinkingMode) {
        generatedText = await generateTextWithThinking(aiInstance, prompt, undefined, imageAttachment, extractedText);
      } else {
        generatedText = await generateText(aiInstance, prompt, undefined, imageAttachment, extractedText);
      }
      setResult(generatedText);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
      setActiveAction(null);
    }
  }, [text, tone, addHistoryItem, imageAttachment, extractedText, aiInstance, isThinkingMode]);

  const handleCopy = () => {
    navigator.clipboard.writeText(result);
  };
  
  const handleHistorySelect = (selectedText: string) => {
    setText(selectedText);
  };

  const handleExport = (format: 'txt' | 'md') => {
    if (!result) return;

    const toolName = t(tool.nameKey).replace(/\s+/g, '_');
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const fileName = `${toolName}_${timestamp}.${format}`;
    
    const mimeType = format === 'md' ? 'text/markdown' : 'text/plain';
    const blob = new Blob([result], { type: `${mimeType};charset=utf-8` });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
  };

  const handleShare = async () => {
    if (!result) return;
    try {
      if (navigator.share) {
        await navigator.share({
          title: `Teks Disunting dari ${t(tool.nameKey)}`,
          text: result,
        });
      } else {
        await navigator.clipboard.writeText(result);
        alert('Hasil disalin ke papan keratan!');
      }
    } catch (error) {
       if (error instanceof Error && !error.message.includes('Abort')) {
        console.error('Error sharing:', error);
      }
    }
  };

  const actionButtons: { id: EditAction, label: string }[] = [
    { id: 'proofread', label: 'Semak Pruf' },
    { id: 'summarize', label: 'Ringkaskan' },
    { id: 'rephrase', label: 'Ubah Ayat' },
  ];
  
  const getSaveStatusMessage = () => {
    switch (saveStatus) {
        case 'saving': return 'Menyimpan...';
        case 'saved': return 'Disimpan';
        default: return 'Perubahan belum disimpan';
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
        <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
      </div>

      <div className="space-y-6">
        <div>
          <div className="flex justify-between items-center mb-2">
            <label htmlFor="text-input" className="block text-sm font-medium text-slate-700 dark:text-slate-300">
              Teks Anda
            </label>
             <span className={`text-xs ${saveStatus === 'saved' ? 'text-slate-400 dark:text-slate-500' : 'text-slate-500 dark:text-slate-400'}`}>{getSaveStatusMessage()}</span>
          </div>
          <div className="relative bg-slate-100 dark:bg-slate-700 rounded-md border border-slate-300 dark:border-slate-600 focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-blue-500 transition-all">
            <MarkdownToolbar textareaRef={textareaRef} onValueChange={setText} />
            <textarea
              ref={textareaRef}
              id="text-input"
              rows={8}
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="w-full bg-transparent p-3 text-slate-900 dark:text-white placeholder-slate-500 dark:placeholder-slate-400 focus:outline-none resize-y"
              placeholder="Tampal atau imlak teks anda di sini..."
            />
            {hasRecognitionSupport && (
                <button
                    onClick={isListening ? stopListening : startListening}
                    className={`absolute right-3 top-3 p-2 rounded-full transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-200 dark:focus:ring-offset-slate-700 focus:ring-blue-500 hover:scale-110 active:scale-100 ${
                    isListening ? 'bg-red-500 text-white animate-pulse' : 'bg-slate-300 text-slate-600 dark:bg-slate-600 dark:text-slate-300 hover:bg-slate-400 dark:hover:bg-slate-500'
                    }`}
                    aria-label={isListening ? 'Berhenti merakam' : 'Mula input suara'}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16"><path d="M5 3a3 3 0 0 1 6 0v5a3 3 0 0 1-6 0V3z"/><path d="M3.5 6.5A.5.5 0 0 1 4 7v1a4 4 0 0 0 8 0V7a.5.5 0 0 1 1 0v1a5 5 0 0 1-4.5 4.975V15h3a.5.5 0 0 1 0 1h-7a.5.5 0 0 1 0-1h3v-2.025A5 5 0 0 1 3 8V7a.5.5 0 0 1 .5-.5z"/></svg>
                </button>
            )}
          </div>
          <div className="flex justify-between items-center mt-2">
            <p className="text-xs text-slate-500 dark:text-slate-500 pr-4">Sila pastikan teks anda mematuhi garis panduan kandungan yang selamat untuk mengelakkan hasil yang tidak diingini.</p>
            <WordCount text={text} />
          </div>
        </div>

        <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">
                Lampirkan Fail untuk Konteks (Pilihan)
            </label>
             <div className="flex items-center gap-4">
                <input type="file" accept="image/*,.pdf,.docx,.txt" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
                <button onClick={() => fileInputRef.current?.click()} className="flex items-center justify-center bg-slate-200 hover:bg-slate-300 text-slate-700 dark:bg-slate-600 dark:hover:bg-slate-500 dark:text-white font-medium py-2 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">
                     <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
                    Pilih Fail
                </button>
                 {(imageAttachment || documentAttachment) && (
                    <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-700 pl-3 rounded-full">
                         <span className="text-slate-600 dark:text-slate-300 text-sm truncate max-w-xs">{imageAttachment?.name || documentAttachment?.name}</span>
                        <button onClick={handleRemoveAttachment} className="text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white p-1.5 rounded-full transition-transform hover:scale-110" aria-label="Remove attachment">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                        </button>
                    </div>
                )}
            </div>
            {isParsing && (
                 <div className="flex items-center text-sm text-slate-500 dark:text-slate-400 mt-2">
                    <LoadingSpinner className="w-4 h-4 mr-2" />
                    <span>Memparsing dokumen...</span>
                </div>
            )}
             {imagePreview && (
                <div className="mt-2 bg-slate-200/50 dark:bg-slate-900/50 p-2 rounded-lg inline-block">
                    <img src={imagePreview} alt="Preview" className="max-h-32 w-auto rounded-md" />
                </div>
            )}
        </div>
        
        <div className="flex items-center justify-between bg-slate-100 dark:bg-slate-700/50 p-3 rounded-lg">
            <div className="flex items-center gap-3">
                <label htmlFor="thinking-mode-editor" className="font-medium text-slate-700 dark:text-slate-300">
                    Thinking Mode
                </label>
                <div className="group relative">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-500 dark:text-slate-400"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
                    <div className="absolute bottom-full mb-2 w-64 bg-slate-800 text-white text-xs rounded py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                        Membolehkan penaakulan yang lebih mendalam untuk pertanyaan kompleks menggunakan Gemini 2.5 Pro. Mungkin mengambil masa lebih lama untuk menjana.
                    </div>
                </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" checked={isThinkingMode} onChange={(e) => setIsThinkingMode(e.target.checked)} className="sr-only peer" id="thinking-mode-editor" />
                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-slate-600 peer-checked:bg-blue-600"></div>
            </label>
        </div>
        
        <HistoryPanel history={history} onSelect={handleHistorySelect} onClear={clearHistory} />

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {actionButtons.map(({ id, label }) => (
            <button
              key={id}
              onClick={() => handleEdit(id)}
              disabled={isLoading || isParsing || !aiInstance}
              className="flex items-center justify-center bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
            >
              {isLoading && activeAction === id ? <LoadingSpinner /> : label}
            </button>
          ))}
          <button
            key="analyze-refine"
            onClick={() => handleEdit('analyze-refine')}
            disabled={isLoading || isParsing || !aiInstance}
            className="flex items-center justify-center bg-teal-600 hover:bg-teal-700 disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
          >
            {isLoading && activeAction === 'analyze-refine' ? <LoadingSpinner /> : 'Analisis & Perhalusi'}
          </button>
        </div>

        <div className="space-y-4 sm:space-y-0 sm:flex sm:gap-4 sm:items-end border-t border-slate-200 dark:border-slate-700 pt-6">
            <div className="flex-grow">
                <label htmlFor="tone-input" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                    Tukar Nada
                </label>
                <input
                    id="tone-input"
                    type="text"
                    value={tone}
                    onChange={(e) => setTone(e.target.value)}
                    className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-3 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                    placeholder="cth., formal, santai, lucu, profesional"
                />
                 <div className="flex flex-wrap gap-2 mt-2">
                    {PREDEFINED_TONES.map(t => (
                        <button type="button" key={t} onClick={() => setTone(t)} className="text-xs bg-slate-200 dark:bg-slate-600 hover:bg-slate-300 dark:hover:bg-slate-500 text-slate-700 dark:text-white font-medium py-1 px-3 rounded-full transition-colors">
                        {t}
                        </button>
                    ))}
                </div>
            </div>
            <button
                onClick={() => handleEdit('change-tone')}
                disabled={isLoading || isParsing || !aiInstance}
                className="w-full sm:w-auto flex-shrink-0 flex items-center justify-center bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-3 px-6 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
            >
                {isLoading && activeAction === 'change-tone' ? <LoadingSpinner /> : 'Gunakan Nada'}
            </button>
        </div>

        {error && <p className="text-red-500 dark:text-red-400 text-center">{error}</p>}
      </div>

      {result && (
        <div className="mt-8 bg-white dark:bg-slate-800 rounded-lg shadow-lg">
          <div className="flex justify-between items-center p-4 border-b border-slate-200 dark:border-slate-700 flex-wrap gap-2">
            <h3 className="text-xl font-semibold text-slate-900 dark:text-white">Hasil</h3>
            <div className="flex items-center gap-2">
              <ReadAloudButton textToRead={result} />
              <button onClick={() => onShareToSocials(result)} title="Hantar ke Pengurus Kandungan" className="text-sm bg-purple-600 hover:bg-purple-500 text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95 flex items-center gap-1.5">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="18" height="18" x="3" y="4" rx="2" ry="2" /><line x1="16" x2="16" y1="2" y2="6" /><line x1="8" x2="8" y1="2" y2="6" /><line x1="3" x2="21" y1="10" y2="10" /></svg>
                Hantar ke Pengurus
              </button>
               <button onClick={handleShare} title="Kongsi" className="p-2 text-sm bg-cyan-600 hover:bg-cyan-500 text-white font-medium rounded-md transition-all duration-200 hover:scale-105 active:scale-95">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" x2="12" y1="2" y2="15"/></svg>
              </button>
              <button onClick={handleCopy} className="text-sm bg-slate-200 hover:bg-slate-300 text-slate-700 dark:bg-slate-600 dark:hover:bg-slate-500 dark:text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">Salin</button>
              <button onClick={() => handleExport('txt')} className="text-sm bg-green-600 hover:bg-green-500 text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">Eksport .txt</button>
              <button onClick={() => handleExport('md')} className="text-sm bg-green-600 hover:bg-green-500 text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">Eksport .md</button>
            </div>
          </div>
          <div className="p-6">
            <MarkdownRenderer content={result} />
            <WordCount text={result} />
            <TranslationWidget textToTranslate={result} />
          </div>
        </div>
      )}
    </div>
  );
};

export default TextEditorView;