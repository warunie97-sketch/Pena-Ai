import React, { useState, useEffect } from 'react';
import type { Tool } from '../types';
import { useUTM, UTMParams } from '../contexts/UTMContext';
import { appendUTMParams } from '../utils/urlUtils';
import { useLanguage } from '../contexts/LanguageContext';

interface UTMSettingsViewProps {
  tool: Tool;
}

const UTMSettingsView: React.FC<UTMSettingsViewProps> = ({ tool }) => {
  const { getUTMParams, setGlobalUTMParams } = useUTM();
  const { t } = useLanguage();
  const [formState, setFormState] = useState<UTMParams>(getUTMParams());
  const [testUrl, setTestUrl] = useState('https://www.example.com');
  const [generatedUrl, setGeneratedUrl] = useState('');
  const [saved, setSaved] = useState(false);
  const [copied, setCopied] = useState(false);


  useEffect(() => {
    setFormState(getUTMParams());
  }, [getUTMParams]);
  
  useEffect(() => {
    const newUrl = appendUTMParams(testUrl, formState);
    setGeneratedUrl(newUrl);
  }, [testUrl, formState]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormState({
      ...formState,
      [e.target.name]: e.target.value,
    });
  };

  const handleSave = () => {
    setGlobalUTMParams(formState);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleCopy = () => {
      navigator.clipboard.writeText(generatedUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
  };

  const utmFields: { name: keyof UTMParams; label: string; placeholder: string }[] = [
    { name: 'utm_source', label: 'Source', placeholder: 'cth., surat berita, google' },
    { name: 'utm_medium', label: 'Medium', placeholder: 'cth., e-mel, cpc' },
    { name: 'utm_campaign', label: 'Campaign Name', placeholder: 'cth., jualan_musim_bunga' },
    { name: 'utm_term', label: 'Campaign Term', placeholder: 'cth., kasut_lari' },
    { name: 'utm_content', label: 'Campaign Content', placeholder: 'cth., pautan_logo, pautan_teks' },
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
        <h2 className="text-3xl font-bold text-white mb-2">{t(tool.nameKey)}</h2>
        <p className="text-slate-400">{t(tool.descriptionKey)}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Settings Form */}
        <div className="space-y-4 bg-slate-800/50 p-6 rounded-lg">
           <h3 className="text-xl font-semibold text-white">Parameter Lalai Global</h3>
           <p className="text-sm text-slate-400">Nilai-nilai ini akan digunakan secara automatik di seluruh aplikasi.</p>
          {utmFields.map(field => (
            <div key={field.name}>
              <label htmlFor={field.name} className="block text-sm font-medium text-slate-300 mb-1">{field.label}</label>
              <input
                type="text"
                id={field.name}
                name={field.name}
                value={formState[field.name] || ''}
                onChange={handleChange}
                placeholder={field.placeholder}
                className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-white focus:ring-2 focus:ring-blue-500"
              />
            </div>
          ))}
          <button
            onClick={handleSave}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-md transition-colors"
          >
            {saved ? 'Tersimpan!' : 'Simpan Tetapan'}
          </button>
        </div>

        {/* URL Builder/Tester */}
        <div className="space-y-4 bg-slate-800/50 p-6 rounded-lg">
          <h3 className="text-xl font-semibold text-white">Penguji Pembina URL</h3>
           <p className="text-sm text-slate-400">Gunakan ini untuk menguji tetapan anda dan menjana URL sekali sahaja.</p>
          <div>
            <label htmlFor="test-url" className="block text-sm font-medium text-slate-300 mb-1">URL Sasaran</label>
            <input
              type="url"
              id="test-url"
              value={testUrl}
              onChange={(e) => setTestUrl(e.target.value)}
              placeholder="https://www.example.com"
              className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-white focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">URL yang Dijana</label>
            <div className="bg-slate-900/50 p-3 rounded-md text-slate-300 break-all text-sm relative">
                {generatedUrl}
                <button onClick={handleCopy} className="absolute top-2 right-2 text-xs bg-slate-600 hover:bg-slate-500 text-white font-medium py-1 px-2 rounded-md w-16">
                    {copied ? 'Disalin!' : 'Salin'}
                </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UTMSettingsView;