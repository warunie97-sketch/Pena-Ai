import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { Tool } from '../types';
import { useGemini } from '../contexts/GeminiContext';
import { LiveServerMessage, Modality, Blob as GenaiBlob } from '@google/genai';
import { encode } from '../utils/audioUtils';
import { decode, decodeAudioData } from '../utils/audioUtils';
import { useLanguage } from '../contexts/LanguageContext';

interface LiveChatViewProps {
  tool: Tool;
  onShareToSocials: (content: string) => void;
}

interface TranscriptionTurn {
  user: string;
  model: string;
}

const LiveChatView: React.FC<LiveChatViewProps> = ({ tool, onShareToSocials }) => {
  const { aiInstance } = useGemini();
  const { t } = useLanguage();
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [error, setError] = useState('');
  const [transcriptionHistory, setTranscriptionHistory] = useState<TranscriptionTurn[]>([]);
  const [currentTranscription, setCurrentTranscription] = useState({ user: '', model: '' });

  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const nextStartTimeRef = useRef(0);
  const audioSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const createBlob = (data: Float32Array): GenaiBlob => {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) {
        int16[i] = data[i] * 32768;
    }
    return {
        data: encode(new Uint8Array(int16.buffer)),
        mimeType: 'audio/pcm;rate=16000',
    };
  }
  
  const startSession = useCallback(async () => {
    if (!aiInstance) {
      setError('Sila tetapkan Kunci API Gemini anda.');
      return;
    }
    setError('');
    setIsSessionActive(true);
    setTranscriptionHistory([]);
    setCurrentTranscription({ user: '', model: '' });

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      nextStartTimeRef.current = 0;
      
      const sessionPromise = aiInstance.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
          onopen: () => {
            if (!inputAudioContextRef.current) return;
            const source = inputAudioContextRef.current.createMediaStreamSource(stream);
            mediaStreamSourceRef.current = source;
            const scriptProcessor = inputAudioContextRef.current.createScriptProcessor(4096, 1, 1);
            scriptProcessorRef.current = scriptProcessor;

            scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
              const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              sessionPromiseRef.current?.then((session) => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioContextRef.current.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.outputTranscription) {
              const text = message.serverContent.outputTranscription.text;
              setCurrentTranscription(prev => ({...prev, model: prev.model + text}));
            } else if (message.serverContent?.inputTranscription) {
              const text = message.serverContent.inputTranscription.text;
              setCurrentTranscription(prev => ({...prev, user: prev.user + text}));
            }

            if (message.serverContent?.turnComplete) {
              setTranscriptionHistory(prev => [...prev, currentTranscription]);
              setCurrentTranscription({ user: '', model: '' });
            }

            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio && outputAudioContextRef.current) {
              const outputCtx = outputAudioContextRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
              
              const audioBytes = decode(base64Audio);
              const audioBuffer = await decodeAudioData(audioBytes, outputCtx, 24000, 1);
              const source = outputCtx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(outputCtx.destination);
              
              audioSourcesRef.current.add(source);
              source.onended = () => audioSourcesRef.current.delete(source);
              
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
            }

            if (message.serverContent?.interrupted) {
              for (const source of audioSourcesRef.current) {
                source.stop();
              }
              audioSourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e: ErrorEvent) => {
            console.error('Live session error:', e);
            setError('Ralat sesi: ' + e.message);
            setIsSessionActive(false);
          },
          onclose: (e: CloseEvent) => {
            setIsSessionActive(false);
            // Cleanup
            scriptProcessorRef.current?.disconnect();
            mediaStreamSourceRef.current?.disconnect();
            stream.getTracks().forEach(track => track.stop());
            inputAudioContextRef.current?.close();
            outputAudioContextRef.current?.close();
          },
        },
        config: {
          responseModalities: [Modality.AUDIO],
          inputAudioTranscription: {},
          outputAudioTranscription: {},
        }
      });
      sessionPromiseRef.current = sessionPromise;

    } catch (err) {
      setError(err instanceof Error ? err.message : 'Gagal memulakan sesi.');
      setIsSessionActive(false);
    }
  }, [aiInstance, currentTranscription]);

  const stopSession = useCallback(async () => {
    sessionPromiseRef.current?.then(session => session.close());
    setIsSessionActive(false);
  }, []);

  return (
    <div className="max-w-4xl mx-auto">
        <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
            <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
            <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
        </div>

        <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg">
            {!isSessionActive ? (
                <button onClick={startSession} disabled={!aiInstance} className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-6 rounded-full text-lg disabled:bg-slate-500">
                    Mula Sembang Langsung
                </button>
            ) : (
                <button onClick={stopSession} className="w-full flex items-center justify-center bg-red-600 hover:bg-red-700 text-white font-bold py-4 px-6 rounded-full text-lg">
                    Tamatkan Sesi
                </button>
            )}

            {error && <p className="text-red-500 dark:text-red-400 text-center mt-4">{error}</p>}
            
            <div className="mt-6 space-y-4 max-h-[50vh] overflow-y-auto p-4 bg-slate-100 dark:bg-slate-900/50 rounded-lg">
                {transcriptionHistory.map((turn, index) => (
                    <div key={index} className="space-y-2">
                        <p><strong className="text-slate-800 dark:text-slate-200">Anda:</strong> <span className="text-slate-600 dark:text-slate-400">{turn.user}</span></p>
                        <p><strong className="text-blue-600 dark:text-blue-400">AI:</strong> <span className="text-slate-600 dark:text-slate-300">{turn.model}</span></p>
                    </div>
                ))}
                 {(currentTranscription.user || currentTranscription.model) && (
                    <div className="space-y-2 opacity-70">
                        {currentTranscription.user && <p><strong className="text-slate-800 dark:text-slate-200">Anda:</strong> <span className="text-slate-600 dark:text-slate-400">{currentTranscription.user}</span></p>}
                        {currentTranscription.model && <p><strong className="text-blue-600 dark:text-blue-400">AI:</strong> <span className="text-slate-600 dark:text-slate-300">{currentTranscription.model}</span></p>}
                    </div>
                )}
            </div>
        </div>
    </div>
  );
};

export default LiveChatView;
