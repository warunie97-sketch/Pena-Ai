import React, { useState, useCallback, useRef, useEffect } from 'react';
import type { Tool } from '../types';
import { useGemini } from '../contexts/GeminiContext';
import { Chat, GenerateContentResponse } from '@google/genai';
import LoadingSpinner from '../components/LoadingSpinner';
import MarkdownRenderer from '../components/MarkdownRenderer';
import { useLanguage } from '../contexts/LanguageContext';

interface ChatbotViewProps {
  tool: Tool;
}

interface Message {
    role: 'user' | 'model';
    content: string;
}

const ChatbotView: React.FC<ChatbotViewProps> = ({ tool }) => {
    const { aiInstance } = useGemini();
    const { t } = useLanguage();
    const [chat, setChat] = useState<Chat | null>(null);
    const [messages, setMessages] = useState<Message[]>([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (aiInstance) {
            const newChat = aiInstance.chats.create({
                model: 'gemini-2.5-flash',
            });
            setChat(newChat);
            setMessages([]);
        }
    }, [aiInstance]);
    
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, isLoading]);

    const handleSend = useCallback(async () => {
        if (!chat || !input.trim()) return;
        
        const userMessage: Message = { role: 'user', content: input };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);
        setError('');

        try {
            const response: GenerateContentResponse = await chat.sendMessage({ message: input });
            const modelMessage: Message = { role: 'model', content: response.text };
            setMessages(prev => [...prev, modelMessage]);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, [chat, input]);

    return (
        <div className="max-w-4xl mx-auto flex flex-col h-[calc(100vh-12rem)]">
            <div className="bg-white dark:bg-slate-800 p-6 rounded-t-lg shadow-lg">
                <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
                <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
            </div>
            
            <div className="flex-grow bg-white dark:bg-slate-800/50 p-4 overflow-y-auto">
                <div className="space-y-4">
                    {messages.map((msg, i) => (
                        <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-xl p-3 rounded-lg ${msg.role === 'user' ? 'bg-blue-500 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-900 dark:text-white'}`}>
                                <MarkdownRenderer content={msg.content} />
                            </div>
                        </div>
                    ))}
                    {isLoading && (
                         <div className="flex justify-start">
                            <div className="max-w-xl p-3 rounded-lg bg-slate-200 dark:bg-slate-700">
                                <LoadingSpinner className="w-5 h-5" />
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-b-lg shadow-lg">
                {error && <p className="text-red-500 dark:text-red-400 text-center mb-2">{error}</p>}
                <div className="flex items-center gap-4">
                    <input 
                        type="text"
                        value={input}
                        onChange={e => setInput(e.target.value)}
                        onKeyPress={e => e.key === 'Enter' && !isLoading && handleSend()}
                        className="flex-grow bg-slate-100 dark:bg-slate-700 p-3 rounded-full border border-slate-300 dark:border-slate-600 focus:ring-2 focus:ring-blue-500"
                        placeholder="Type your message..."
                        disabled={isLoading || !aiInstance}
                    />
                    <button onClick={handleSend} disabled={isLoading || !input.trim() || !aiInstance} className="bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-full disabled:bg-slate-500">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ChatbotView;
