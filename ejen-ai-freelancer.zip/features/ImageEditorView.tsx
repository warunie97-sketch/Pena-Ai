

import React, { useState, useCallback, useRef, useEffect } from 'react';
import type { Tool } from '../types';
import { editImage } from '../services/geminiService';
import LoadingSpinner from '../components/LoadingSpinner';
import HistoryPanel from '../components/HistoryPanel';
import { useHistory } from '../hooks/useHistory';
import { useGemini } from '../contexts/GeminiContext';
import { useLanguage } from '../contexts/LanguageContext';

interface ImageEditorViewProps {
  tool: Tool;
  onShareToSocials: (content: string) => void;
}

interface HistoryState {
  imageUrl: string;
  prompt: string;
  textResult: string | null;
}

const ImageEditorView: React.FC<ImageEditorViewProps> = ({ tool, onShareToSocials }) => {
  const { aiInstance } = useGemini();
  const { t } = useLanguage();
  const [prompt, setPrompt] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [history, setHistory] = useState<HistoryState[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { history: promptHistory, addHistoryItem, clearHistory } = useHistory(`history_${tool.id}`);

  // Cleanup object URLs on unmount
  useEffect(() => {
    return () => {
      history.forEach(state => URL.revokeObjectURL(state.imageUrl));
    };
  }, [history]);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Revoke any previous object URLs to prevent memory leaks
      history.forEach(state => URL.revokeObjectURL(state.imageUrl));

      const newOriginalUrl = URL.createObjectURL(file);
      setImageFile(file);
      setHistory([{
        imageUrl: newOriginalUrl,
        prompt: 'Imej Asal',
        textResult: null
      }]);
      setHistoryIndex(0);
      setError('');
      setPrompt('');
    }
  };

  const handleGenerate = useCallback(async () => {
    if (!aiInstance) {
      setError('Sila tetapkan Kunci API Gemini anda dalam pengepala.');
      return;
    }
    if (!prompt.trim()) {
      setError('Sila masukkan gesaan untuk menerangkan suntingan anda.');
      return;
    }
    if (!imageFile) {
      setError('Sila muat naik imej untuk disunting.');
      return;
    }

    setIsLoading(true);
    setError('');
    addHistoryItem(prompt);

    try {
      const result = await editImage(aiInstance, prompt, imageFile);
      if (result.imageUrl) {
        const newHistoryState: HistoryState = {
          imageUrl: result.imageUrl,
          prompt: prompt,
          textResult: result.text
        };

        // Create a new branch if we've undone steps
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push(newHistoryState);
        
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
      } else {
        throw new Error("AI tidak memulangkan imej. Sila cuba gesaan yang berbeza.");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [prompt, imageFile, history, historyIndex, addHistoryItem, aiInstance]);

  const triggerFileSelect = () => fileInputRef.current?.click();

  const handleUndo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
    }
  };
  
  const handleHistorySelect = (selectedPrompt: string) => {
    setPrompt(selectedPrompt);
  };

  const currentImageState = history[historyIndex];

  const handleDownload = async () => {
    if (!currentImageState) return;
    const link = document.createElement('a');
    link.href = currentImageState.imageUrl;
    link.download = `EjenAI_Suntingan_${new Date().toISOString().replace(/[:.]/g, '-')}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleShare = async () => {
    if (!currentImageState) return;
    try {
        const response = await fetch(currentImageState.imageUrl);
        const blob = await response.blob();
        const file = new File([blob], 'ejen-ai-edited-image.png', { type: blob.type });

        if (navigator.share && navigator.canShare({ files: [file] })) {
            await navigator.share({
                files: [file],
                title: 'Imej Disunting dengan AI',
                text: currentImageState.prompt,
            });
        } else {
            await navigator.clipboard.writeText(currentImageState.imageUrl);
            alert('Perkongsian fail tidak disokong. Pautan imej telah disalin.');
        }
    } catch (error) {
       if (error instanceof Error && !error.message.includes('Abort')) {
        console.error('Error sharing image:', error);
        alert('Gagal berkongsi imej.');
       }
    }
  };


  return (
    <div className="max-w-6xl mx-auto">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
        <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)} (Dikuasakan oleh Nano Banana)</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Input Section */}
        <div className="space-y-6">
          <div 
            className="border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-lg p-6 text-center cursor-pointer hover:border-blue-500 transition-all duration-200"
            onClick={triggerFileSelect}
          >
            <input
              type="file"
              accept="image/*"
              ref={fileInputRef}
              onChange={handleFileChange}
              className="hidden"
            />
            {currentImageState ? (
                <img src={history[0].imageUrl} alt="Original upload" className="max-h-64 mx-auto rounded-md" />
            ) : (
                <div className="text-slate-500 dark:text-slate-400">
                    <p>Klik untuk memuat naik imej</p>
                    <p className="text-xs">PNG, JPG, WEBP, dll.</p>
                </div>
            )}
          </div>
          
          <div>
            <label htmlFor="prompt-editor" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
              Gesaan Penyuntingan
            </label>
            <textarea
              id="prompt-editor"
              rows={3}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="w-full bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-3 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
              placeholder="cth., 'tambahkan cermin mata hitam pada kucing' atau 'jadikan langit kelihatan seperti matahari terbenam'"
            />
            <p className="text-xs text-slate-500 dark:text-slate-500 mt-2">Sila pastikan gesaan anda mematuhi garis panduan kandungan yang selamat untuk mengelakkan hasil yang tidak diingini.</p>
          </div>

          <HistoryPanel history={promptHistory} onSelect={handleHistorySelect} onClear={clearHistory} />

          <button
            onClick={handleGenerate}
            disabled={isLoading || !imageFile || !aiInstance}
            className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
          >
            {isLoading ? <LoadingSpinner /> : 'Gunakan Suntingan AI'}
          </button>
          {error && <p className="text-red-500 dark:text-red-400 text-center">{error}</p>}
        </div>

        {/* Output Section */}
        <div className="flex flex-col bg-white dark:bg-slate-800 rounded-lg p-4 min-h-[400px]">
            <div className="flex-grow flex items-center justify-center">
              {isLoading ? (
                <>
                  <LoadingSpinner className="w-12 h-12 text-blue-500" />
                  <p className="mt-4 text-slate-500 dark:text-slate-400">Menggunakan magis AI...</p>
                </>
              ) : currentImageState ? (
                <img src={currentImageState.imageUrl} alt="Edited result" className="max-h-[400px] w-auto rounded-md" />
              ) : (
                <p className="text-slate-400 dark:text-slate-500">Imej yang disunting akan muncul di sini</p>
              )}
            </div>
            {currentImageState?.textResult && <p className="mt-4 text-slate-600 dark:text-slate-300 text-center italic">"{currentImageState.textResult}"</p>}
             {currentImageState && (
                <div className="flex items-center justify-center gap-2 mt-4 pt-4 border-t border-slate-200 dark:border-slate-700">
                    <button onClick={() => onShareToSocials(currentImageState.prompt)} title="Hantar ke Pengurus Kandungan" className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95 disabled:opacity-50" disabled={currentImageState.prompt === 'Imej Asal'}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect width="18" height="18" x="3" y="4" rx="2" ry="2" /><line x1="16" x2="16" y1="2" y2="6" /><line x1="8" x2="8" y1="2" y2="6" /><line x1="3" x2="21" y1="10" y2="10" /></svg>
                        Hantar ke Pengurus
                    </button>
                    <button onClick={handleShare} className="flex items-center gap-2 bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-2 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" x2="12" y1="2" y2="15"/></svg>
                        Kongsi
                    </button>
                     <button onClick={handleDownload} className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>
                        Muat Turun
                    </button>
                </div>
            )}
        </div>
      </div>

      {history.length > 0 && (
        <div className="mt-8 bg-white dark:bg-slate-800 rounded-lg shadow-lg p-4">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-slate-900 dark:text-white">Sejarah Suntingan</h3>
                <div className="flex items-center gap-2">
                    <button onClick={handleUndo} disabled={historyIndex <= 0} className="px-3 py-1 bg-slate-200 dark:bg-slate-600 rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-300 dark:hover:bg-slate-500 transition-all duration-200 hover:scale-105 active:scale-95 text-sm flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 3v6h6"/><path d="M21 12A9 9 0 0 0 6 5.3L3 9"/></svg>
                        Buat Asal
                    </button>
                    <button onClick={handleRedo} disabled={historyIndex >= history.length - 1} className="px-3 py-1 bg-slate-200 dark:bg-slate-600 rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-300 dark:hover:bg-slate-500 transition-all duration-200 hover:scale-105 active:scale-95 text-sm flex items-center gap-2">
                        Buat Semula
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 3v6h-6"/><path d="M3 12a9 9 0 0 0 15 6.7l3-3.7"/></svg>
                    </button>
                </div>
            </div>
            <div className="flex overflow-x-auto space-x-3 pb-3">
                {history.map((state, index) => (
                    <div 
                        key={index}
                        onClick={() => setHistoryIndex(index)}
                        className="relative flex-shrink-0 cursor-pointer group"
                        title={state.prompt}
                    >
                        <img 
                            src={state.imageUrl}
                            alt={`History step ${index + 1}`}
                            className={`w-24 h-24 object-cover rounded-md border-4 transition-all ${index === historyIndex ? 'border-blue-500' : 'border-transparent group-hover:border-slate-300 dark:group-hover:border-slate-500'}`}
                        />
                        <div className="absolute bottom-0 left-0 bg-black bg-opacity-60 text-white text-xs font-bold rounded-br-md rounded-tl-md px-1.5 py-0.5">
                            {index === 0 ? 'Asal' : index}
                        </div>
                    </div>
                ))}
            </div>
        </div>
      )}
    </div>
  );
};

export default ImageEditorView;