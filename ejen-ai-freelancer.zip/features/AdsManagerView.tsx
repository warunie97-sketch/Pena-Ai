import React, { useState, useCallback } from 'react';
import type { Tool } from '../types';
import { useGemini } from '../contexts/GeminiContext';
import { generateAdCampaign, AdCampaignResult } from '../services/geminiService';
import LoadingSpinner from '../components/LoadingSpinner';
import { useLanguage } from '../contexts/LanguageContext';
import MarkdownRenderer from '../components/MarkdownRenderer';

interface AdsManagerViewProps {
  tool: Tool;
  onShareToSocials: (content: string) => void;
}

const PLATFORMS = ['Google Ads', 'Facebook', 'Instagram', 'LinkedIn', 'TikTok'];

const AdsManagerView: React.FC<AdsManagerViewProps> = ({ tool, onShareToSocials }) => {
  const { aiInstance } = useGemini();
  const { aiLang, t } = useLanguage();
  
  const [productName, setProductName] = useState('');
  const [productDescription, setProductDescription] = useState('');
  const [targetAudience, setTargetAudience] = useState('');
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [cta, setCta] = useState('');
  const [budget, setBudget] = useState('');

  const [result, setResult] = useState<AdCampaignResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handlePlatformToggle = (platform: string) => {
    setSelectedPlatforms(prev => 
      prev.includes(platform) ? prev.filter(p => p !== platform) : [...prev, platform]
    );
  };

  const handleGenerate = useCallback(async () => {
    if (!aiInstance) {
      setError('Sila tetapkan Kunci API Gemini anda.');
      return;
    }
    if (!productName || !productDescription || !targetAudience || selectedPlatforms.length === 0 || !cta || !budget) {
        setError('Sila isi semua medan.');
        return;
    }

    setIsLoading(true);
    setError('');
    setResult(null);

    try {
        const campaignResult = await generateAdCampaign(aiInstance, productName, productDescription, targetAudience, selectedPlatforms, cta, budget, aiLang);
        setResult(campaignResult);
    } catch (err) {
        setError(err instanceof Error ? `Gagal menjana kempen: ${err.message}` : 'Ralat tidak dijangka berlaku.');
    } finally {
        setIsLoading(false);
    }
  }, [aiInstance, productName, productDescription, targetAudience, selectedPlatforms, cta, budget, aiLang]);

  return (
    <div className="max-w-4xl mx-auto">
        <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
            <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
            <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
        </div>

        <div className="space-y-6">
            {/* Form fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Nama Produk/Perkhidmatan</label>
                    <input type="text" value={productName} onChange={e => setProductName(e.target.value)} className="w-full bg-slate-100 dark:bg-slate-700 p-2 rounded-md" />
                </div>
                 <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Penerangan Produk</label>
                    <input type="text" value={productDescription} onChange={e => setProductDescription(e.target.value)} className="w-full bg-slate-100 dark:bg-slate-700 p-2 rounded-md" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Sasaran Audiens</label>
                    <input type="text" value={targetAudience} onChange={e => setTargetAudience(e.target.value)} className="w-full bg-slate-100 dark:bg-slate-700 p-2 rounded-md" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Seruan Tindak (CTA)</label>
                    <input type="text" value={cta} onChange={e => setCta(e.target.value)} className="w-full bg-slate-100 dark:bg-slate-700 p-2 rounded-md" />
                </div>
                 <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Maklumat Belanjawan</label>
                    <input type="text" value={budget} onChange={e => setBudget(e.target.value)} className="w-full bg-slate-100 dark:bg-slate-700 p-2 rounded-md" />
                </div>
            </div>
            
            <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Pilih Platform</label>
                <div className="flex flex-wrap gap-2">
                    {PLATFORMS.map(p => (
                        <button key={p} onClick={() => handlePlatformToggle(p)} className={`py-2 px-4 rounded-full text-sm font-semibold transition-colors ${selectedPlatforms.includes(p) ? 'bg-blue-600 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200'}`}>
                            {p}
                        </button>
                    ))}
                </div>
            </div>

            <button onClick={handleGenerate} disabled={isLoading || !aiInstance} className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-md disabled:bg-slate-500">
                {isLoading ? <LoadingSpinner /> : 'Jana Kempen Iklan'}
            </button>

            {error && <p className="text-red-500 dark:text-red-400 text-center">{error}</p>}
        </div>

        {result && (
            <div className="mt-8 bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg">
                <h3 className="text-2xl font-bold mb-4">Cadangan Kempen</h3>
                <div className="space-y-6">
                    {result.campaignSuggestions.map((camp, i) => (
                        <div key={i} className="border-t pt-4">
                            <h4 className="text-xl font-semibold">{camp.campaign_name} ({camp.platform})</h4>
                            <pre className="bg-slate-100 dark:bg-slate-900 p-4 rounded-md text-sm whitespace-pre-wrap overflow-x-auto">
                                {JSON.stringify(camp, null, 2)}
                            </pre>
                        </div>
                    ))}
                </div>
            </div>
        )}
    </div>
  );
};

export default AdsManagerView;
