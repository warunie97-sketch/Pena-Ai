import React, { useState, useCallback, useEffect } from 'react';
import type { Tool } from '../types';
import { generateAnimationFrames, AnimationGenerationStatus } from '../services/geminiService';
import LoadingSpinner from '../components/LoadingSpinner';
import HistoryPanel from '../components/HistoryPanel';
import { useHistory } from '../hooks/useHistory';
import { useGemini } from '../contexts/GeminiContext';
import { useLanguage } from '../contexts/LanguageContext';

interface AnimationGeneratorViewProps {
  tool: Tool;
  onShareToSocials: (content: string) => void;
}

// Player component to display animation
const AnimationPlayer: React.FC<{ frames: string[]; fps: number; aspectRatio: '16:9' | '9:16'; currentFrame: number; setCurrentFrame: (frame: number) => void; }> = ({ frames, fps, aspectRatio, currentFrame, setCurrentFrame }) => {
    const aspectClass = aspectRatio === '16:9' ? 'aspect-video' : 'aspect-[9/16]';

    useEffect(() => {
        if (frames.length === 0) return;
        const intervalId = setInterval(() => {
            setCurrentFrame(prev => (prev + 1) % frames.length);
        }, 1000 / fps);
        return () => clearInterval(intervalId);
    }, [frames, fps, setCurrentFrame]);

    if (frames.length === 0) {
        return <div className={`w-full bg-black ${aspectClass} rounded-md flex items-center justify-center text-slate-500`}>Animasi akan dipaparkan di sini.</div>;
    }

    return (
        <div className={`w-full bg-black ${aspectClass} rounded-md flex items-center justify-center`}>
             <img src={frames[currentFrame]} alt={`Animation frame ${currentFrame + 1}`} className="max-w-full max-h-full object-contain" />
        </div>
    );
};

const ANIMATION_STYLES = [
  'Tiada', 'Anime', 'Kartun', 'Seni Piksel', 'Gerakan Henti', 'Cat Air',
  'Minimalis', 'Model 3D', 'Tanah Liat', 'Buku Komik', 'Surealis', 'Sinematik',
];

// Utility function to create video from frames
async function createVideoFromFrames(frames: string[], fps: number): Promise<Blob> {
    return new Promise(async (resolve, reject) => {
        if (frames.length === 0) return reject('Tiada bingkai diberikan.');

        // 1. Get dimensions from the first image
        const firstImage = new Image();
        firstImage.src = frames[0];
        try {
            await firstImage.decode();
        } catch (e) {
            return reject('Gagal memuatkan bingkai imej pertama.');
        }
        const { width, height } = firstImage;
        if (width === 0 || height === 0) {
            return reject('Dimensi imej tidak sah.');
        }

        // 2. Set up canvas and stream
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) return reject('Konteks kanvas tidak tersedia.');

        const stream = canvas.captureStream(fps);
        const recorder = new MediaRecorder(stream, { mimeType: 'video/webm' });

        const chunks: Blob[] = [];
        recorder.ondataavailable = e => e.data.size > 0 && chunks.push(e.data);
        recorder.onstop = () => resolve(new Blob(chunks, { type: 'video/webm' }));
        recorder.onerror = reject;

        // 3. Start recording and drawing frames
        recorder.start();

        const imageElements = await Promise.all(frames.map(url => {
            const img = new Image();
            img.src = url;
            return img.decode().then(() => img);
        }));
        
        let frameIndex = 0;
        const drawFrame = () => {
            if (frameIndex < imageElements.length) {
                ctx.drawImage(imageElements[frameIndex], 0, 0);
                frameIndex++;
                setTimeout(drawFrame, 1000 / fps);
            } else {
                recorder.stop();
            }
        };

        drawFrame();
    });
}


const AnimationGeneratorView: React.FC<AnimationGeneratorViewProps> = ({ tool, onShareToSocials }) => {
  const { aiInstance } = useGemini();
  const { t } = useLanguage();
  const [idea, setIdea] = useState('Seorang gadis di taman memegang belon merah. Belon itu terlepas dan terbang ke langit, membuatkan dia sedih.');
  const [style, setStyle] = useState(ANIMATION_STYLES[1]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const { history, addHistoryItem, clearHistory } = useHistory(`history_${tool.id}`);

  const [frames, setFrames] = useState<string[]>([]);
  const [numberOfFrames, setNumberOfFrames] = useState(12);
  const [fps, setFps] = useState(8);
  const [currentFrame, setCurrentFrame] = useState(0);
  const [animationStatus, setAnimationStatus] = useState<AnimationGenerationStatus | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);

  useEffect(() => {
    return () => {
      frames.forEach(frameUrl => URL.revokeObjectURL(frameUrl));
    };
  }, [frames]);

  const handleGenerateAnimation = useCallback(async () => {
    if (!aiInstance) {
      setError('Sila tetapkan Kunci API Gemini anda dalam pengepala.');
      return;
    }
    if (!idea.trim()) {
      setError('Sila masukkan idea untuk animasi.');
      return;
    }
    setIsLoading(true);
    setError('');
    frames.forEach(url => URL.revokeObjectURL(url));
    setFrames([]);
    setAnimationStatus(null);
    
    const fullPrompt = style !== 'Tiada' ? `${idea}, dalam gaya ${style}` : idea;
    addHistoryItem(fullPrompt);

    try {
      const result = await generateAnimationFrames(aiInstance, fullPrompt, numberOfFrames, aspectRatio, setAnimationStatus);
      setFrames(result.imageUrls);
      setAnimationStatus(null);
      setCurrentFrame(0);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Ralat tidak dijangka.';
      setError(errorMessage);
      setAnimationStatus({ message: errorMessage, progress: 100 });
    } finally {
      setIsLoading(false);
    }
  }, [idea, style, numberOfFrames, aspectRatio, addHistoryItem, aiInstance, frames]);
  
  const handleDownloadAnimation = async () => {
    if (frames.length === 0) return;
    
    setIsDownloading(true);
    setError('');

    try {
        const videoBlob = await createVideoFromFrames(frames, fps);
        const url = URL.createObjectURL(videoBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `EjenAI_Animasi_${Date.now()}.webm`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    } catch (err) {
        setError(err instanceof Error ? err.message : 'Gagal mencipta video.');
        console.error(err);
    } finally {
        setIsDownloading(false);
    }
  }

  const handleHistorySelect = (selectedIdea: string) => setIdea(selectedIdea);
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
        <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
      </div>

      <div className="space-y-6">
        <div>
          <label htmlFor="idea-input" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Cerita / Gesaan Anda</label>
          <textarea id="idea-input" rows={4} value={idea} onChange={(e) => setIdea(e.target.value)} className="w-full bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-3 text-slate-900 dark:text-white" placeholder="cth., Seekor ikan paus megah berenang melalui awan"/>
        </div>
        <div>
          <label htmlFor="style-select" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Gaya (Pilihan)</label>
          <select id="style-select" value={style} onChange={(e) => setStyle(e.target.value)} className="w-full bg-white dark:bg-slate-700 p-3 rounded-md border border-slate-300 dark:border-slate-600">
              {ANIMATION_STYLES.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
                <label htmlFor="num-frames-anim" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Bilangan Bingkai</label>
                <select id="num-frames-anim" value={numberOfFrames} onChange={(e) => setNumberOfFrames(Number(e.target.value))} className="w-full bg-white dark:bg-slate-700 p-3 rounded-md border border-slate-300 dark:border-slate-600">
                    <option value="4">4 Bingkai (Sangat Cepat)</option>
                    <option value="8">8 Bingkai (Cepat)</option>
                    <option value="12">12 Bingkai (Standard)</option>
                    <option value="16">16 Bingkai (Lancar)</option>
                    <option value="24">24 Bingkai (Sangat Lancar)</option>
                </select>
            </div>
            <div>
                <label htmlFor="aspect-ratio" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Nisbah Aspek</label>
                <select id="aspect-ratio" value={aspectRatio} onChange={(e) => setAspectRatio(e.target.value as '16:9' | '9:16')} className="w-full bg-white dark:bg-slate-700 p-3 rounded-md border border-slate-300 dark:border-slate-600">
                    <option value="16:9">Landskap (16:9)</option>
                    <option value="9:16">Potret (9:16)</option>
                </select>
            </div>
        </div>
        
        <HistoryPanel history={history} onSelect={handleHistorySelect} onClear={clearHistory} />

        <button onClick={handleGenerateAnimation} disabled={isLoading} className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 font-bold py-3 px-6 rounded-md text-white">
          {isLoading ? <LoadingSpinner /> : 'Jana Animasi'}
        </button>
        <p className="text-xs text-slate-500 dark:text-slate-500 mt-2 text-center">Sila pastikan gesaan anda mematuhi garis panduan kandungan yang selamat.</p>
        
        {error && !isLoading && (
          <div className="mt-4 bg-red-100 dark:bg-red-900/50 border border-red-300 dark:border-red-700 text-red-700 dark:text-red-300 px-4 py-3 rounded-lg text-center">
            <strong className="font-bold">Gagal Menjana: </strong><span>{error}</span>
          </div>
        )}
      </div>
      
      {isLoading && (
        <div className={`mt-8 flex flex-col items-center justify-center bg-white dark:bg-slate-800 rounded-lg shadow-lg p-8 ${aspectRatio === '16:9' ? 'aspect-video' : 'aspect-[9/16]'}`}>
            <LoadingSpinner className="w-12 h-12 text-blue-500" />
            <p className="mt-4 text-slate-700 dark:text-slate-300 font-semibold text-lg">{animationStatus?.message || 'Memulakan...'}</p>
            {animationStatus && (
              <div className="w-full max-w-md bg-slate-200 dark:bg-slate-700 rounded-full h-2.5 mt-4"><div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${animationStatus.progress}%` }}></div></div>
            )}
            <p className="mt-2 text-slate-500 dark:text-slate-400 text-sm">Ini boleh mengambil sedikit masa. Sila biarkan tetingkap ini terbuka.</p>
        </div>
      )}

      {!isLoading && frames.length > 0 && (
          <div className="mt-8 space-y-6">
              <h3 className="text-2xl font-bold text-slate-900 dark:text-white">Animasi yang Dijana</h3>
              <div className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-lg space-y-4">
                  <AnimationPlayer frames={frames} fps={fps} aspectRatio={aspectRatio} currentFrame={currentFrame} setCurrentFrame={setCurrentFrame} />
                  <div className="p-2">
                      <label htmlFor="fps-slider-anim" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Kelajuan (Bingkai Sesat): {fps}</label>
                      <input id="fps-slider-anim" type="range" min="1" max="24" value={fps} onChange={(e) => setFps(Number(e.target.value))} className="w-full h-2 bg-slate-200 dark:bg-slate-600 rounded-lg appearance-none cursor-pointer" />
                  </div>
                   <div className="flex justify-end gap-3">
                      <button onClick={() => onShareToSocials(idea)} title="Hantar ke Pengurus Kandungan" className="text-sm bg-purple-600 hover:bg-purple-500 text-white font-medium py-2 px-4 rounded-md transition-all">
                        Hantar Gesaan
                      </button>
                      <button
                        onClick={handleDownloadAnimation}
                        disabled={isDownloading}
                        className="flex items-center justify-center bg-green-600 hover:bg-green-700 disabled:bg-slate-400 text-white font-bold py-2 px-4 rounded-md"
                      >
                        {isDownloading ? <LoadingSpinner /> : 'Muat Turun Video (.webm)'}
                      </button>
                  </div>
              </div>
          </div>
        )}
    </div>
  );
};

export default AnimationGeneratorView;