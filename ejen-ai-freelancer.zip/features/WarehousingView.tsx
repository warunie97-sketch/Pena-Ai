import React, { useState, useCallback } from 'react';
import type { Tool } from '../types';
import { useGemini } from '../contexts/GeminiContext';
// FIX: Import Slide type from the central types file.
import { analyzeWarehousingData, generatePresentationFromReport, ReportData } from '../services/geminiService';
import type { Slide } from '../types';
import LoadingSpinner from '../components/LoadingSpinner';
import MarkdownRenderer from '../components/MarkdownRenderer';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';
import PresentationViewer from '../components/PresentationViewer';
import { useLanguage } from '../contexts/LanguageContext';

interface WarehousingViewProps {
  tool: Tool;
  onShareToSocials: (content: string) => void;
}

const COLORS = ['#3B82F6', '#8B5CF6', '#10B981', '#F59E0B', '#EF4444'];

const chartComponents = {
  bar: BarChart,
  line: LineChart,
  pie: PieChart,
};

const WarehousingView: React.FC<WarehousingViewProps> = ({ tool, onShareToSocials }) => {
  const { aiInstance } = useGemini();
  const { uiLang, t } = useLanguage();
  const [data, setData] = useState('');
  const [analysisGoal, setAnalysisGoal] = useState('');

  const [report, setReport] = useState<ReportData | null>(null);
  const [presentationSlides, setPresentationSlides] = useState<Slide[]>([]);
  
  const [isLoadingReport, setIsLoadingReport] = useState(false);
  const [isLoadingPresentation, setIsLoadingPresentation] = useState(false);
  const [error, setError] = useState('');

  const handleGenerateReport = useCallback(async () => {
    if (!aiInstance) {
      setError('Sila tetapkan Kunci API Gemini anda.');
      return;
    }
    if (!data.trim()) {
      setError('Sila masukkan data atau senario untuk dianalisis.');
      return;
    }
    setIsLoadingReport(true);
    setError('');
    setReport(null);
    setPresentationSlides([]);
    
    try {
        const instruction = tool.systemInstruction?.[uiLang] || '';
        const analysisReport = await analyzeWarehousingData(aiInstance, data, analysisGoal, instruction);
        setReport(analysisReport);
    } catch (err) {
      setError(err instanceof Error ? `Gagal menjana laporan: ${err.message}` : 'Ralat tidak dijangka.');
    } finally {
      setIsLoadingReport(false);
    }
  }, [aiInstance, data, analysisGoal, tool.systemInstruction, uiLang]);

  const handleGeneratePresentation = useCallback(async () => {
    if (!aiInstance || !report) return;
    
    setIsLoadingPresentation(true);
    setError('');
    try {
      const presentationData = await generatePresentationFromReport(aiInstance, report, 'Warehousing');
      setPresentationSlides(presentationData.slides || []);
    } catch (err) {
      setError(err instanceof Error ? `Gagal menjana pembentangan: ${err.message}` : 'Ralat tidak dijangka.');
    } finally {
      setIsLoadingPresentation(false);
    }
  }, [aiInstance, report]);

  const handleDownloadReport = () => {
    if (!report) return;

    let content = `# Laporan Analisis Pergudangan\n\n`;
    content += `## ${t('warehousing.executiveSummary')}\n${report.executive_summary}\n\n`;
    content += `## ${t('warehousing.keyFindings')}\n${report.key_findings.map(f => `- ${f}`).join('\n')}\n\n`;
    content += `## ${t('warehousing.recommendations')}\n${report.recommendations.map(r => `- ${r}`).join('\n')}\n\n`;

    const fileName = `Laporan_Pergudangan_${new Date().toISOString()}.md`;
    const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = fileName;
    link.click();
    URL.revokeObjectURL(link.href);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
        <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
      </div>

      <div className="space-y-6">
        <div>
            <label htmlFor="wh-data" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">{t('warehousing.dataInputLabel')}</label>
            <textarea id="wh-data" rows={8} value={data} onChange={e => setData(e.target.value)} className="w-full bg-slate-100 dark:bg-slate-700 p-3 rounded-md border border-slate-300 dark:border-slate-600 focus:ring-2 focus:ring-blue-500" placeholder={t('warehousing.dataInputPlaceholder')} />
        </div>
        <div>
            <label htmlFor="wh-goal" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">{t('warehousing.analysisGoalLabel')}</label>
            <input id="wh-goal" type="text" value={analysisGoal} onChange={e => setAnalysisGoal(e.target.value)} className="w-full bg-slate-100 dark:bg-slate-700 p-3 rounded-md border border-slate-300 dark:border-slate-600 focus:ring-2 focus:ring-blue-500" placeholder={t('warehousing.analysisGoalPlaceholder')} />
        </div>

        <button onClick={handleGenerateReport} disabled={isLoadingReport || !aiInstance} className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-md disabled:bg-slate-500">
            {isLoadingReport ? <LoadingSpinner /> : t('warehousing.generateReport')}
        </button>

        {error && <p className="text-red-500 dark:text-red-400 text-center bg-red-100 dark:bg-red-900/20 p-3 rounded-md">{error}</p>}
      </div>

        {isLoadingReport && (
             <div className="mt-8 text-center"><LoadingSpinner className="w-10 h-10 mx-auto" /><p className="mt-2 text-slate-500 dark:text-slate-400">Menganalisis data...</p></div>
        )}

        {report && !isLoadingReport && (
            <div className="mt-8 bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg space-y-8">
                <div className="flex justify-between items-center">
                    <h3 className="text-2xl font-bold">{t('warehousing.analysisReport')}</h3>
                    <button onClick={handleDownloadReport} className="text-sm bg-green-600 hover:bg-green-500 text-white font-medium py-2 px-4 rounded-md">
                        {t('warehousing.downloadReport')}
                    </button>
                </div>

                <div>
                    <h4 className="text-xl font-semibold mb-2">{t('warehousing.executiveSummary')}</h4>
                    <MarkdownRenderer content={report.executive_summary} />
                </div>
                <div>
                    <h4 className="text-xl font-semibold mb-2">{t('warehousing.keyFindings')}</h4>
                    <ul className="list-disc list-inside space-y-2">
                        {report.key_findings.map((finding, i) => <li key={i}><MarkdownRenderer content={finding} /></li>)}
                    </ul>
                </div>
                <div>
                    <h4 className="text-xl font-semibold mb-2">{t('warehousing.recommendations')}</h4>
                     <ul className="list-disc list-inside space-y-2">
                        {report.recommendations.map((rec, i) => <li key={i}><MarkdownRenderer content={rec} /></li>)}
                    </ul>
                </div>
                {report.visualizations.length > 0 && (
                    <div>
                        <h4 className="text-xl font-semibold mb-4">{t('warehousing.dataVisualizations')}</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            {report.visualizations.map((vis, i) => (
                                <div key={i} className="bg-slate-50 dark:bg-slate-900/50 p-4 rounded-lg">
                                    <h5 className="font-bold text-center mb-2">{vis.title}</h5>
                                    <ResponsiveContainer width="100%" height={300}>
                                        {vis.type === 'bar' ? (
                                            <BarChart data={vis.data}>
                                                <CartesianGrid strokeDasharray="3 3" />
                                                <XAxis dataKey="name" />
                                                <YAxis />
                                                <Tooltip />
                                                <Legend />
                                                <Bar dataKey="value" fill="#3B82F6" />
                                            </BarChart>
                                        ) : vis.type === 'line' ? (
                                            <LineChart data={vis.data}>
                                                <CartesianGrid strokeDasharray="3 3" />
                                                <XAxis dataKey="name" />
                                                <YAxis />
                                                <Tooltip />
                                                <Legend />
                                                <Line type="monotone" dataKey="value" stroke="#8B5CF6" />
                                            </LineChart>
                                        ) : (
                                            <PieChart>
                                                <Pie data={vis.data} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} fill="#8884d8" label>
                                                    {vis.data.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                                                </Pie>
                                                <Tooltip />
                                                <Legend />
                                            </PieChart>
                                        )}
                                    </ResponsiveContainer>
                                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 text-center">{vis.description}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
                
                <div className="text-center pt-6 border-t border-slate-200 dark:border-slate-700">
                    <button onClick={handleGeneratePresentation} disabled={isLoadingPresentation} className="w-full sm:w-auto flex items-center justify-center mx-auto bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-6 rounded-md">
                        {isLoadingPresentation ? <LoadingSpinner /> : t('warehousing.generatePresentation')}
                    </button>
                </div>
            </div>
        )}

        {presentationSlides.length > 0 && (
            <div className="mt-8">
                 <h3 className="text-2xl font-bold mb-4 text-slate-900 dark:text-white">{t('warehousing.presentationGenerated')}</h3>
                <PresentationViewer slides={presentationSlides} />
            </div>
        )}
    </div>
  );
};

export default WarehousingView;