import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import LoadingSpinner from '../components/LoadingSpinner';

const AuthView: React.FC = () => {
  const [isLogin, setIsLogin] = useState(false); // Default to Sign Up
  const [id, setId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login, signup } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    try {
      if (isLogin) {
        await login(id, password);
      } else {
        await signup(id, password);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-slate-100 dark:bg-slate-900 text-slate-900 dark:text-white">
      <div className="w-full max-w-md p-8 space-y-6 bg-white dark:bg-slate-800 rounded-lg shadow-2xl">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-slate-900 dark:text-white">Ejen AI Freelancer</h1>
           <h2 className="mt-4 text-2xl font-medium text-slate-800 dark:text-slate-200">
            {isLogin ? 'Log Masuk ke Akaun Anda' : 'Cipta Akaun Baru'}
          </h2>
          <p className="mt-2 text-slate-500 dark:text-slate-400">
            {isLogin ? 'Selamat kembali! Sila masukkan butiran anda.' : 'Mula menggunakan alatan AI yang hebat hari ini.'}
          </p>
        </div>
        
        <form className="space-y-6" onSubmit={handleSubmit}>
          <div>
            <label htmlFor="id" className="block text-sm font-medium text-slate-700 dark:text-slate-300">
              ID Pengguna
            </label>
            <input
              id="id"
              type="text"
              value={id}
              onChange={(e) => setId(e.target.value)}
              required
              className="w-full mt-1 p-3 bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
              placeholder="cth., ejenhebat"
            />
          </div>
          <div>
            <label htmlFor="password"  className="block text-sm font-medium text-slate-700 dark:text-slate-300">
              Kata Laluan
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full mt-1 p-3 bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
              placeholder="••••••••"
            />
             {!isLogin && <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Mestilah sekurang-kurangnya 6 aksara.</p>}
          </div>
          {error && <p className="text-red-500 dark:text-red-400 text-sm text-center bg-red-100 dark:bg-red-900/20 p-3 rounded-md">{error}</p>}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 disabled:bg-slate-600 text-white font-bold py-3 px-4 rounded-md transition-all"
          >
            {isLoading ? <LoadingSpinner /> : (isLogin ? 'Log Masuk' : 'Daftar Akaun')}
          </button>
        </form>
        <div className="text-center text-sm">
          <button
            onClick={() => { setIsLogin(!isLogin); setError(''); }}
            className="font-medium text-blue-600 hover:text-blue-500 dark:text-blue-400 dark:hover:text-blue-300"
          >
            {isLogin ? 'Tiada akaun? Daftar di sini' : 'Sudah mempunyai akaun? Log Masuk'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthView;
