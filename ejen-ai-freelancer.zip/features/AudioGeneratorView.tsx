import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { Tool } from '../types';
import WordCount from '../components/WordCount';
import { useGemini } from '../contexts/GeminiContext';
import LoadingSpinner from '../components/LoadingSpinner';
import HistoryPanel from '../components/HistoryPanel';
import { useHistory } from '../hooks/useHistory';
import { useAutoSave } from '../hooks/useAutoSave';
import { generateSpeech } from '../services/geminiService';
import { useLanguage } from '../contexts/LanguageContext';
import { decode, createWavBlob } from '../utils/audioUtils';

interface AudioGeneratorViewProps {
  tool: Tool;
  onShareToSocials: (content: string) => void;
}

// This resolves the `INVALID_ARGUMENT` error and expands the available options.
const VOICES = [
  // Existing valid voices
  { id: 'Kore', name: 'Kore', description: 'Suara wanita yang ceria dan muda.' },
  { id: 'Puck', name: 'Puck', description: 'Suara lelaki yang suka bermain dan berkarakter.' },
  { id: 'Charon', name: 'Charon', description: 'Suara lelaki yang serius dan dalam.' },
  { id: 'Fenrir', name: 'Fenrir', description: 'Suara lelaki yang kuat dan memerintah.' },
  { id: 'Zephyr', name: 'Zephyr', description: 'Suara lelaki yang standard dan neutral.' },

  // New voices from the allowed list (with inferred descriptions)
  { id: 'Autonoe', name: 'Autonoe', description: 'Suara wanita yang jelas dan tenang.' },
  { id: 'Callirrhoe', name: 'Callirrhoe', description: 'Suara wanita yang lembut dan merdu.' },
  { id: 'Despina', name: 'Despina', description: 'Suara wanita yang bertenaga dan ekspresif.' },
  { id: 'Erinome', name: 'Erinome', description: 'Suara wanita yang matang dan meyakinkan.' },
  { id: 'Leda', name: 'Leda', description: 'Suara wanita yang anggun dan naratif.' },
  { id: 'Alnilam', name: 'Alnilam', description: 'Suara lelaki yang mantap dan boleh dipercayai.' },
  { id: 'Gacrux', name: 'Gacrux', description: 'Suara lelaki yang dalam dan bergema.' },
  { id: 'Orus', name: 'Orus', description: 'Suara lelaki yang cerah dan optimis.' },
  { id: 'Achernar', name: 'Achernar', description: 'Suara lelaki yang profesional dan jelas.' },
  { id: 'Zubenelgenubi', name: 'Zubenelgenubi', description: 'Suara lelaki yang unik dan berkarakter.' },
];


const AudioGeneratorView: React.FC<AudioGeneratorViewProps> = ({ tool, onShareToSocials }) => {
  const { aiInstance } = useGemini();
  const { t } = useLanguage();
  const [script, setScript] = useState('');
  const [voice, setVoice] = useState(VOICES[0].id);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [previewingVoice, setPreviewingVoice] = useState<string | null>(null);

  const saveStatus = useAutoSave(`draft_${tool.id}`, script, setScript);
  const { history, addHistoryItem, clearHistory } = useHistory(`history_${tool.id}`);
  const audioPreviewRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    return () => {
      if (audioUrl) {
        URL.revokeObjectURL(audioUrl);
      }
      if (audioPreviewRef.current) {
        URL.revokeObjectURL(audioPreviewRef.current.src);
      }
    };
  }, [audioUrl]);

  const handlePreview = useCallback(async (voiceName: string) => {
    if (!aiInstance) {
      setError('Sila tetapkan Kunci API Gemini anda untuk pratonton suara.');
      return;
    }
    setPreviewingVoice(voiceName);
    setError('');
    
    try {
        const sampleText = "Ini ialah pratonton suara saya.";
        const base64Audio = await generateSpeech(aiInstance, sampleText, voiceName);
        const audioBytes = decode(base64Audio);
        const blob = createWavBlob(audioBytes);
        const url = URL.createObjectURL(blob);
        
        if (audioPreviewRef.current) {
            URL.revokeObjectURL(audioPreviewRef.current.src);
        }

        const audio = new Audio(url);
        audioPreviewRef.current = audio;
        audio.play();
        audio.onended = () => {
            URL.revokeObjectURL(url);
            if (audioPreviewRef.current === audio) {
                 audioPreviewRef.current = null;
            }
        };

    } catch (err) {
        setError(err instanceof Error ? `Gagal pratonton suara: ${err.message}` : 'Ralat pratonton yang tidak dijangka.');
    } finally {
        setPreviewingVoice(null);
    }

  }, [aiInstance]);

  const handleGenerate = useCallback(async () => {
    if (!aiInstance) {
      setError('Sila tetapkan Kunci API Gemini anda dalam pengepala.');
      return;
    }
    if (!script.trim()) {
      setError('Sila masukkan skrip untuk menjana audio.');
      return;
    }
    setIsLoading(true);
    setError('');
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    setAudioUrl(null);
    addHistoryItem(script);

    try {
      const base64Audio = await generateSpeech(aiInstance, script, voice);
      const audioBytes = decode(base64Audio);
      const blob = createWavBlob(audioBytes);
      const url = URL.createObjectURL(blob);
      setAudioUrl(url);

    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [script, voice, addHistoryItem, aiInstance, audioUrl]);

  const handleHistorySelect = (selectedScript: string) => {
    setScript(selectedScript);
  };
  
  const getSaveStatusMessage = () => {
    switch (saveStatus) {
        case 'saving': return 'Menyimpan...';
        case 'saved': return 'Disimpan';
        default: return 'Perubahan belum disimpan';
    }
  };

  const handleDownload = () => {
    if (!audioUrl) return;
    const link = document.createElement('a');
    link.href = audioUrl;
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    link.download = `EjenAI_Audio_${timestamp}.wav`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
        <h2 className="text-3xl font-bold text-white mb-2">{t(tool.nameKey)}</h2>
        <p className="text-slate-400">{t(tool.descriptionKey)}</p>
      </div>

      <div className="space-y-6">
        <div>
          <div className="flex justify-between items-center mb-2">
              <label htmlFor="script-input" className="block text-sm font-medium text-slate-300">Skrip Anda</label>
              <span className={`text-xs ${saveStatus === 'saved' ? 'text-slate-500' : 'text-slate-400'}`}>{getSaveStatusMessage()}</span>
          </div>
          <textarea
            id="script-input"
            rows={8}
            value={script}
            onChange={(e) => setScript(e.target.value)}
            className="w-full bg-slate-700 border border-slate-600 rounded-md p-3 text-white focus:ring-2 focus:ring-blue-500 transition"
            placeholder="Taip atau tampal skrip anda di sini..."
          />
           <div className="flex justify-between items-center mt-2">
              <p className="text-xs text-slate-500 pr-4">Sila pastikan skrip anda mematuhi garis panduan kandungan yang selamat.</p>
              <WordCount text={script} />
            </div>
        </div>

        <HistoryPanel history={history} onSelect={handleHistorySelect} onClear={clearHistory} />

        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">Pilih Suara</label>
            <div className="space-y-2">
                {VOICES.map(v => (
                    <div
                        key={v.id}
                        onClick={() => setVoice(v.id)}
                        className={`flex items-center justify-between p-3 rounded-md cursor-pointer transition-all duration-200 border-2 ${
                            voice === v.id ? 'bg-blue-600/30 border-blue-500' : 'bg-slate-700/50 border-slate-600 hover:bg-slate-700'
                        }`}
                    >
                        <div className="flex-grow">
                            <p className="font-semibold text-white">{v.name}</p>
                            <p className="text-xs text-slate-400">{v.description}</p>
                        </div>
                        <button
                            onClick={(e) => { e.stopPropagation(); handlePreview(v.id); }}
                            disabled={previewingVoice === v.id || !aiInstance}
                            className="flex-shrink-0 flex items-center justify-center bg-slate-600 hover:bg-slate-500 text-white font-medium py-2 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95 disabled:opacity-50 w-32"
                            aria-label={`Pratonton suara ${v.name}`}
                        >
                            {previewingVoice === v.id ? <LoadingSpinner className="w-5 h-5" /> : (
                                <>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="mr-2"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                                    Pratonton
                                </>
                            )}
                        </button>
                    </div>
                ))}
            </div>
        </div>

        <button
          onClick={handleGenerate}
          disabled={isLoading || !aiInstance}
          className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-3 px-6 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
        >
          {isLoading ? <LoadingSpinner /> : 'Jana Audio'}
        </button>

        {error && <p className="text-red-400 text-center">{error}</p>}
      </div>

      <div className="mt-8">
        {isLoading && (
          <div className="flex flex-col items-center justify-center bg-slate-800 p-8 rounded-lg shadow-lg">
            <LoadingSpinner className="w-12 h-12 text-blue-500" />
            <p className="mt-4 text-slate-400">Menjana audio... Ini mungkin mengambil sedikit masa.</p>
          </div>
        )}
        {audioUrl && !isLoading && (
          <div className="bg-slate-800 p-4 rounded-lg shadow-lg space-y-4">
            <h3 className="text-xl font-semibold text-white">Audio yang Dijana</h3>
            <audio src={audioUrl} controls className="w-full" />
            <div className="flex justify-end gap-3">
              <button
                onClick={() => onShareToSocials(script)}
                title="Hantar ke Pengurus Kandungan"
                className="flex items-center justify-center bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
              >
                Hantar Skrip
              </button>
              <button
                onClick={handleDownload}
                className="flex items-center justify-center bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
              >
                Muat Turun .wav
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AudioGeneratorView;