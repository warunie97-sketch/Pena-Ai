import React, { useState, useCallback, useEffect, useRef } from 'react';
import { GoogleGenAI } from '@google/genai';
import type { Tool } from '../types';
import { VideoGenerationStatus } from '../services/geminiService';
import LoadingSpinner from '../components/LoadingSpinner';
import HistoryPanel from '../components/HistoryPanel';
import { useHistory } from '../hooks/useHistory';
import { useGemini } from '../contexts/GeminiContext';
import { useLanguage } from '../contexts/LanguageContext';

interface VideoGeneratorViewProps {
  tool: Tool;
  onShareToSocials: (content: string) => void;
}

const VIDEO_STYLES = [
  'Tiada', 'Sinematik', 'Anime', 'Fotorealistik', 'Cat Air', 'Seni Piksel', 'Model 3D', 'Buku Komik'
];

const VideoGeneratorView: React.FC<VideoGeneratorViewProps> = ({ tool, onShareToSocials }) => {
  const { t } = useLanguage();
  
  const [idea, setIdea] = useState('');
  const [style, setStyle] = useState(VIDEO_STYLES[0]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const { history, addHistoryItem, clearHistory } = useHistory(`history_${tool.id}`);

  // Veo-specific state
  const [hasSelectedKey, setHasSelectedKey] = useState<boolean | 'checking'>('checking');
  const [apiKeyError, setApiKeyError] = useState('');
  const [videoStatus, setVideoStatus] = useState<VideoGenerationStatus | null>(null);
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [resolution, setResolution] = useState<'720p' | '1080p'>('720p');
  const [imageAttachment, setImageAttachment] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const imageFileInputRef = useRef<HTMLInputElement>(null);

  // Extension State
  const [completedOperation, setCompletedOperation] = useState<any | null>(null);
  const [extensionPrompt, setExtensionPrompt] = useState<string>('');
  const [isExtending, setIsExtending] = useState(false);
  const [extensionStatus, setExtensionStatus] = useState<VideoGenerationStatus | null>(null);
  const [extendedResultUrl, setExtendedResultUrl] = useState<string | null>(null);
  const [extensionError, setExtensionError] = useState('');

  useEffect(() => {
    const checkKey = async () => {
        if (!window.aistudio) {
            setHasSelectedKey(true); // Fallback if aistudio is not available
            return;
        }
        setHasSelectedKey('checking');
        const hasKey = await window.aistudio.hasSelectedApiKey();
        setHasSelectedKey(hasKey);
    };
    checkKey();
  }, []);
  
  useEffect(() => {
    return () => {
      if (resultUrl) URL.revokeObjectURL(resultUrl);
      if (imagePreview) URL.revokeObjectURL(imagePreview);
      if (extendedResultUrl) URL.revokeObjectURL(extendedResultUrl);
    };
  }, [resultUrl, imagePreview, extendedResultUrl]);

  const handleSelectKey = async () => {
    if (!window.aistudio) return;
    await window.aistudio.openSelectKey();
    setHasSelectedKey(true);
    setApiKeyError('');
  };

  const handleImageFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file?.type.startsWith('image/')) {
        if (imagePreview) URL.revokeObjectURL(imagePreview);
        setImageAttachment(file);
        setImagePreview(URL.createObjectURL(file));
        setError('');
    } else if (file) {
        setError('Sila pilih fail imej yang sah.');
        handleRemoveImageAttachment();
    }
  };

  const handleRemoveImageAttachment = () => {
    if (imagePreview) URL.revokeObjectURL(imagePreview);
    setImageAttachment(null);
    setImagePreview(null);
    if (imageFileInputRef.current) imageFileInputRef.current.value = '';
  };

  const handleGenerateVideo = useCallback(async () => {
    if (!process.env.API_KEY) {
      setError('Kunci API tidak tersedia. Sila pilih kunci API.');
      setHasSelectedKey(false);
      return;
    }
    if (!idea.trim()) {
      setError('Sila masukkan idea untuk video.');
      return;
    }

    setIsLoading(true);
    setError('');
    setExtensionError('');
    if (resultUrl) URL.revokeObjectURL(resultUrl);
    setResultUrl(null);
    if (extendedResultUrl) URL.revokeObjectURL(extendedResultUrl);
    setExtendedResultUrl(null);
    setVideoStatus(null);
    setCompletedOperation(null);
    setExtensionPrompt('');

    const fullPrompt = style !== 'Tiada' ? `${idea}, dalam gaya ${style}` : idea;
    addHistoryItem(fullPrompt);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      let imagePayload: { imageBytes: string, mimeType: string } | undefined = undefined;
      if (imageAttachment) {
        const base64EncodedData = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
          reader.onerror = reject;
          reader.readAsDataURL(imageAttachment);
        });
        imagePayload = {
          imageBytes: base64EncodedData,
          mimeType: imageAttachment.type
        };
      }

      setVideoStatus({ message: 'Memulakan penjanaan video...' });

      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: fullPrompt,
        image: imagePayload,
        config: {
          numberOfVideos: 1,
          resolution,
          aspectRatio,
        }
      });

      let pollCount = 0;
      while (!operation.done) {
        pollCount++;
        setVideoStatus({ message: `Memproses video... (semakan #${pollCount}) Ini mungkin mengambil masa beberapa minit.` });
        await new Promise(resolve => setTimeout(resolve, 10000));
        try {
            operation = await ai.operations.getVideosOperation({ operation: operation });
        } catch(e) {
            if (e instanceof Error && e.message.includes("Requested entity was not found.")) {
                 throw new Error("Kunci API tidak sah untuk penjanaan video. Sila pilih kunci yang sah.");
            }
            throw e;
        }
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (!downloadLink) {
        throw new Error("Penjanaan video selesai, tetapi tiada pautan muat turun diberikan.");
      }

      setVideoStatus({ message: 'Memuat turun video yang dijana...' });
      const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
      if (!response.ok) {
        throw new Error(`Gagal memuat turun video. Status: ${response.status}`);
      }

      const videoBlob = await response.blob();
      const videoBlobUrl = URL.createObjectURL(videoBlob);
      
      setVideoStatus({ message: 'Video berjaya dijana!' });
      setResultUrl(videoBlobUrl);
      setCompletedOperation(operation);

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Ralat tidak dijangka.';
      if (errorMessage.includes("Kunci API tidak sah")) {
          setHasSelectedKey(false);
          setApiKeyError("Kunci API yang anda pilih tidak sah untuk penjanaan video. Sila pilih kunci yang lain.");
      }
      setError(errorMessage);
      setVideoStatus({ message: `Gagal: ${errorMessage}` });
    } finally {
        setIsLoading(false);
    }
  }, [idea, style, resolution, aspectRatio, addHistoryItem, imageAttachment, resultUrl, extendedResultUrl]);
  
  const handleExtendVideo = useCallback(async () => {
    if (!completedOperation || !extensionPrompt.trim()) {
      setExtensionError('Sila masukkan gesaan untuk sambungan.');
      return;
    }
    const previousVideo = completedOperation.response?.generatedVideos?.[0]?.video;
    if (previousVideo?.resolution !== '720p') {
      setExtensionError('Hanya video 720p boleh disambung.');
      return;
    }

    setIsExtending(true);
    setExtensionError('');
    if (extendedResultUrl) URL.revokeObjectURL(extendedResultUrl);
    setExtendedResultUrl(null);
    setExtensionStatus({ message: 'Memulakan sambungan video...' });

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-generate-preview',
        prompt: extensionPrompt,
        video: previousVideo,
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: previousVideo?.aspectRatio,
        }
      });

      let pollCount = 0;
      while (!operation.done) {
        pollCount++;
        setExtensionStatus({ message: `Memproses sambungan... (semakan #${pollCount})` });
        await new Promise(resolve => setTimeout(resolve, 5000));
        try {
          operation = await ai.operations.getVideosOperation({ operation });
        } catch (e) {
          if (e instanceof Error && e.message.includes("Requested entity was not found.")) {
            throw new Error("Kunci API tidak sah untuk sambungan video. Sila pilih kunci yang sah.");
          }
          throw e;
        }
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (!downloadLink) {
        throw new Error("Sambungan video selesai, tetapi tiada pautan muat turun diberikan.");
      }

      setExtensionStatus({ message: 'Memuat turun video sambungan...' });
      const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
      if (!response.ok) {
        throw new Error(`Gagal memuat turun video sambungan. Status: ${response.status}`);
      }
      const videoBlob = await response.blob();
      const videoBlobUrl = URL.createObjectURL(videoBlob);
      setExtensionStatus({ message: 'Video berjaya disambung!' });
      setExtendedResultUrl(videoBlobUrl);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Ralat tidak dijangka.';
       if (errorMessage.includes("Kunci API tidak sah")) {
          setHasSelectedKey(false);
          setApiKeyError("Kunci API yang anda pilih tidak sah untuk sambungan video. Sila pilih kunci yang lain.");
      }
      setExtensionError(errorMessage);
    } finally {
      setIsExtending(false);
    }
  }, [completedOperation, extensionPrompt, extendedResultUrl]);


  const handleHistorySelect = (selectedIdea: string) => setIdea(selectedIdea);
  
  const handleDownload = (url: string, isExtended = false) => {
      if (!url) return;
      const link = document.createElement('a');
      link.href = url;
      const prefix = isExtended ? 'EjenAI_Video_Sambungan' : 'EjenAI_Video';
      link.download = `${prefix}_${Date.now()}.mp4`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
  };
  
  if (hasSelectedKey === 'checking') {
      return <div className="flex h-full w-full items-center justify-center"><LoadingSpinner className="h-12 w-12" /></div>;
  }

  if (!hasSelectedKey) {
      return (
        <div className="max-w-2xl mx-auto text-center bg-white dark:bg-slate-800 p-8 rounded-lg shadow-lg">
          <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-4">Diperlukan Pemilihan Kunci API</h3>
          <p className="text-slate-600 dark:text-slate-300 mb-6">Untuk menggunakan penjana video Veo, anda mesti memilih Kunci API anda sendiri yang didayakan untuk pengebilan. Ketahui lebih lanjut tentang <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">pengebilan API Gemini</a>.</p>
          <button onClick={handleSelectKey} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-md">Pilih Kunci API</button>
          {apiKeyError && <p className="text-red-500 dark:text-red-400 mt-4">{apiKeyError}</p>}
        </div>
      );
  }

  const isExtendable = completedOperation?.response?.generatedVideos?.[0]?.video?.resolution === '720p';

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg mb-6">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t(tool.nameKey)}</h2>
        <p className="text-slate-500 dark:text-slate-400">{t(tool.descriptionKey)}</p>
      </div>

      <div className="space-y-6">
        <div>
          <label htmlFor="idea-input" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Gesaan Video Anda</label>
          <input id="idea-input" type="text" value={idea} onChange={(e) => setIdea(e.target.value)} className="w-full bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-3 text-slate-900 dark:text-white" placeholder="cth., Seekor ikan paus megah berenang melalui awan"/>
        </div>
        <div>
          <label htmlFor="style-select" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Gaya (Pilihan)</label>
          <select id="style-select" value={style} onChange={(e) => setStyle(e.target.value)} className="w-full bg-white dark:bg-slate-700 p-3 rounded-md border border-slate-300 dark:border-slate-600">
              {VIDEO_STYLES.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="resolution" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Resolusi</label>
                <select id="resolution" value={resolution} onChange={(e) => setResolution(e.target.value as '720p' | '1080p')} className="w-full bg-white dark:bg-slate-700 p-3 rounded-md border border-slate-300 dark:border-slate-600">
                    <option value="720p">720p (Boleh Disambung)</option>
                    <option value="1080p">1080p (Kualiti Lebih Tinggi)</option>
                </select>
              </div>
              <div>
                <label htmlFor="aspect-ratio" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Nisbah Aspek</label>
                <select id="aspect-ratio" value={aspectRatio} onChange={(e) => setAspectRatio(e.target.value as '16:9' | '9:16')} className="w-full bg-white dark:bg-slate-700 p-3 rounded-md border border-slate-300 dark:border-slate-600">
                    <option value="16:9">Landskap (16:9)</option>
                    <option value="9:16">Potret (9:16)</option>
                </select>
              </div>
            </div>
          </div>
          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Imej Permulaan (Pilihan)</label>
            <div className="flex items-center gap-4">
                <input type="file" accept="image/*" ref={imageFileInputRef} onChange={handleImageFileChange} className="hidden"/>
                <button onClick={() => imageFileInputRef.current?.click()} className="flex items-center bg-slate-200 dark:bg-slate-600 py-2 px-4 rounded-md text-slate-700 dark:text-white hover:bg-slate-300 dark:hover:bg-slate-500">Pilih Imej</button>
                {imageAttachment && (<div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-700 pl-3 rounded-full"><span className="text-sm text-slate-600 dark:text-slate-300">{imageAttachment.name}</span><button onClick={handleRemoveImageAttachment} className="p-1.5">&times;</button></div>)}
            </div>
            {imagePreview && (<div className="mt-2"><img src={imagePreview} alt="Preview" className="max-h-32 rounded-md" /></div>)}
            <p className="text-xs text-slate-500 dark:text-slate-500">Imej ini akan digunakan sebagai bingkai pertama video anda.</p>
          </div>
        </div>
        
        <HistoryPanel history={history} onSelect={handleHistorySelect} onClear={clearHistory} />

        <button onClick={handleGenerateVideo} disabled={isLoading} className="w-full flex items-center justify-center bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 font-bold py-3 px-6 rounded-md text-white">
          {isLoading ? <LoadingSpinner /> : 'Jana Video'}
        </button>
        <p className="text-xs text-slate-500 dark:text-slate-500 mt-2 text-center">Sila pastikan gesaan anda mematuhi garis panduan kandungan yang selamat.</p>
        
        {error && !isLoading && (
          <div className="mt-4 bg-red-100 dark:bg-red-900/50 border border-red-300 dark:border-red-700 text-red-700 dark:text-red-300 px-4 py-3 rounded-lg text-center">
            <strong className="font-bold">Gagal Menjana: </strong><span>{error}</span>
          </div>
        )}
      </div>
      
      {(isLoading || resultUrl) && (
        <div className="mt-8 space-y-6">
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white">Video Asal</h3>
            {isLoading ? (
              <div className={`flex flex-col items-center justify-center bg-white dark:bg-slate-800 rounded-lg shadow-lg p-8 ${aspectRatio === '16:9' ? 'aspect-video' : 'aspect-[9/16]'}`}>
                  <LoadingSpinner className="w-12 h-12 text-blue-500" />
                  <p className="mt-4 text-slate-700 dark:text-slate-300 font-semibold text-lg">{videoStatus?.message || 'Memulakan...'}</p>
                  <p className="mt-2 text-slate-500 dark:text-slate-400 text-sm">Ini boleh mengambil beberapa minit. Sila biarkan tetingkap ini terbuka.</p>
              </div>
            ) : resultUrl && (
              <div className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-lg space-y-4">
                  <video src={resultUrl} controls autoPlay loop muted className="w-full rounded-md" />
                  <div className="flex justify-end gap-3">
                      <button onClick={() => handleDownload(resultUrl)} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md">Muat Turun .mp4</button>
                  </div>
              </div>
            )}
        </div>
      )}

      {resultUrl && !isLoading && completedOperation && (
          <div className="mt-8 space-y-6">
              <h3 className="text-2xl font-bold text-slate-900 dark:text-white">Sambung Video (Tambah 7s)</h3>
              <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg space-y-4">
                {!isExtendable ? (
                  <p className="text-yellow-600 dark:text-yellow-400 text-center bg-yellow-100 dark:bg-yellow-900/20 p-3 rounded-md">Hanya video yang dijana pada resolusi 720p boleh disambung. Sila jana video baru pada 720p untuk menggunakan ciri ini.</p>
                ) : (
                  <>
                    <div>
                      <label htmlFor="extension-prompt" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Gesaan Sambungan</label>
                      <input id="extension-prompt" type="text" value={extensionPrompt} onChange={(e) => setExtensionPrompt(e.target.value)} className="w-full bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-3 text-slate-900 dark:text-white" placeholder="cth., Kemudian, kamera menyorot ke atas untuk mendedahkan bulan purnama."/>
                    </div>
                    <button onClick={handleExtendVideo} disabled={isExtending} className="w-full flex items-center justify-center bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-400 font-bold py-3 px-6 rounded-md text-white">
                      {isExtending ? <LoadingSpinner /> : 'Jana Sambungan'}
                    </button>
                    {extensionError && <p className="text-red-500 dark:text-red-400 text-center mt-2">{extensionError}</p>}
                  </>
                )}
              </div>

            {(isExtending || extendedResultUrl) && (
              <div className="mt-6 space-y-4">
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white">Video yang Disambung</h3>
                {isExtending ? (
                    <div className={`flex flex-col items-center justify-center bg-white dark:bg-slate-800 rounded-lg shadow-lg p-8 ${aspectRatio === '16:9' ? 'aspect-video' : 'aspect-[9/16]'}`}>
                        <LoadingSpinner className="w-12 h-12 text-indigo-500" />
                        <p className="mt-4 text-slate-700 dark:text-slate-300 font-semibold text-lg">{extensionStatus?.message || 'Memulakan...'}</p>
                    </div>
                ) : extendedResultUrl && (
                    <div className="bg-white dark:bg-slate-800 p-4 rounded-lg shadow-lg space-y-4">
                        <video src={extendedResultUrl} controls autoPlay loop muted className="w-full rounded-md" />
                        <div className="flex justify-end gap-3">
                            <button onClick={() => handleDownload(extendedResultUrl, true)} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md">Muat Turun Video Sambungan</button>
                        </div>
                    </div>
                )}
              </div>
            )}
          </div>
      )}
    </div>
  );
};

export default VideoGeneratorView;