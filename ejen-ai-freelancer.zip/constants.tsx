import React from 'react';
import type { Tool } from './types';
import { ToolId } from './types';

const IconWrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className="h-5 w-5 mr-3"
  >
    {children}
  </svg>
);

export const TOOLS: Tool[] = [
  {
    id: ToolId.Dashboard,
    nameKey: 'tools.dashboard.name',
    descriptionKey: 'tools.dashboard.description',
    icon: <IconWrapper><path d="M12 21v-8a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1Z"/><path d="M20 13a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1Z"/><path d="M12 3a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1Z"/><path d="M20 3a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1Z"/></IconWrapper>,
    categoryKey: 'sidebar.main',
  },
  // --- PENULISAN ---
  {
    id: ToolId.ContentWriting,
    nameKey: 'tools.content_writing.name',
    descriptionKey: 'tools.content_writing.description',
    icon: <IconWrapper><path d="M12 20h9" /><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z" /></IconWrapper>,
    categoryKey: 'toolCategories.writing',
    systemInstruction: {
      ms: 'Anda adalah seorang penulis kandungan yang pakar. Hasilkan kandungan yang komprehensif, tersusun rapi, dan menarik berdasarkan gesaan pengguna. Pastikan nada adalah profesional dan informatif. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti \'Ia bukan X, tetapi Y\' atau \'Ia bukan X. Ia adalah Y.\'.',
      en: 'You are an expert content writer. Generate comprehensive, well-structured, and engaging content based on the user\'s prompt. Ensure the tone is professional and informative. Avoid repetitive sentence structures, especially comparison patterns like \'It\'s not X, but Y\' or \'It\'s not X. It is Y.\'.'
    }
  },
  {
    id: ToolId.MyBlog,
    nameKey: 'tools.my_blog.name',
    descriptionKey: 'tools.my_blog.description',
    icon: <IconWrapper><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></IconWrapper>,
    categoryKey: 'toolCategories.writing',
  },
  {
    id: ToolId.CommunityFeed,
    nameKey: 'tools.community_feed.name',
    descriptionKey: 'tools.community_feed.description',
    icon: <IconWrapper><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></IconWrapper>,
    categoryKey: 'toolCategories.writing',
  },
  {
    id: ToolId.CreativeWriting,
    nameKey: 'tools.creative_writing.name',
    descriptionKey: 'tools.creative_writing.description',
    icon: <IconWrapper><path d="M20.24 12.24a6 6 0 0 0-8.49-8.49L5 10.5V19h8.5z"/><line x1="16" y1="8" x2="2" y2="22"/><line x1="17.5" y1="15" x2="9" y2="15"/></IconWrapper>,
    categoryKey: 'toolCategories.writing',
    systemInstruction: {
      ms: 'Anda adalah seorang penulis kreatif. Berdasarkan gesaan pengguna, tulis sebuah karya penulisan kreatif (cerita, puisi, skrip, dll.) yang unik dan imaginatif. Beri perhatian kepada plot, watak, imejan, dan nada. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti \'Ia bukan X, tetapi Y\' atau \'Ia bukan X. Ia adalah Y.\'.',
      en: 'You are a creative writer. Based on the user\'s prompt, write a unique and imaginative piece of creative writing (story, poem, script, etc.). Pay attention to plot, character, imagery, and tone. Avoid repetitive sentence structures, especially comparison patterns like \'It\'s not X, but Y\' or \'It\'s not X. It is Y.\'.'
    }
  },
  {
    id: ToolId.BookPublishing,
    nameKey: 'tools.book_publishing.name',
    descriptionKey: 'tools.book_publishing.description',
    icon: <IconWrapper><path d="M4 22h14a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-2 2Zm0 0a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h4"/><path d="M18 22H8a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h10"/></IconWrapper>,
    categoryKey: 'toolCategories.writing',
    systemInstruction: {
      ms: 'Anda adalah pembantu penulisan buku. Berdasarkan gesaan pengguna, bantu mereka dengan mencipta rangka buku yang terperinci, menjana idea untuk bab tertentu, atau menulis draf sesebuah bahagian. Kekalkan gaya naratif yang konsisten.',
      en: 'You are a book writing assistant. Based on the user\'s prompt, assist them by creating a detailed book outline, generating ideas for specific chapters, or writing a draft of a section. Maintain a consistent narrative style.'
    }
  },
  {
    id: ToolId.IdeaGenerator,
    nameKey: 'tools.idea_generator.name',
    descriptionKey: 'tools.idea_generator.description',
    icon: <IconWrapper><path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/></IconWrapper>,
    categoryKey: 'toolCategories.writing',
    systemInstruction: {
      ms: 'Anda adalah rakan sumbang saran yang kreatif. Matlamat anda adalah untuk menjana senarai idea yang unik dan memberi inspirasi berdasarkan permintaan pengguna. Jika pengguna memberikan "idea utama", pastikan idea-idea tersebut digabungkan secara kreatif ke dalam hasil. Format idea hendaklah sepadan dengan apa yang diminta oleh pengguna (cth., senarai gesaan, perihalan babak, satu set topik). Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti \'Ia bukan X, tetapi Y\' atau \'Ia bukan X. Ia adalah Y.\'.',
      en: 'You are a creative brainstorming partner. Your goal is to generate a list of unique and inspiring ideas based on the user\'s request. If the user provides "key ideas", ensure they are creatively incorporated into the output. The format of the ideas should match what the user asks for (e.g., a list of prompts, a scene description, a set of topics). Avoid repetitive sentence structures, especially comparison patterns like \'It\'s not X, but Y\' or \'It\'s not X. It is Y.\'.'
    }
  },
  {
    id: ToolId.Copywriting,
    nameKey: 'tools.copywriting.name',
    descriptionKey: 'tools.copywriting.description',
    icon: <IconWrapper><path d="m3 11 18-5v12L3 14v-3z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/></IconWrapper>,
    categoryKey: 'toolCategories.writing',
    systemInstruction: {
      ms: 'Anda adalah seorang penulis iklan yang pakar. Tulis salinan yang meyakinkan, persuasif, dan berorientasikan tindakan berdasarkan gesaan pengguna. Fokus pada faedah, gunakan seruan tindak yang kuat, dan padankan nada yang dinyatakan (cth., kerangka AIDA, PAS). Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti \'Ia bukan X, tetapi Y\' atau \'Ia bukan X. Ia adalah Y.\'.',
      en: 'You are an expert copywriter. Write compelling, persuasive, and action-oriented copy based on the user\'s prompt. Focus on benefits, use strong calls-to-action, and match the specified tone (e.g., AIDA, PAS frameworks). Avoid repetitive sentence structures, especially comparison patterns like \'It\'s not X, but Y\' or \'It\'s not X. It is Y.\'.'
    }
  },
  {
    id: ToolId.SeoArticle,
    nameKey: 'tools.seo_article.name',
    descriptionKey: 'tools.seo_article.description',
    icon: <IconWrapper><path d="m12 14 4-4" /><path d="M3.34 19a10 10 0 1 1 17.32 0" /></IconWrapper>,
    categoryKey: 'toolCategories.writing',
    systemInstruction: {
      ms: 'Anda adalah pakar SEO dan penulis kandungan. Hasilkan artikel yang dikaji dengan baik, komprehensif, dan dioptimumkan untuk SEO. Sepadukan kata kunci yang diberikan secara semula jadi. Susun artikel dengan tag H1, H2, dan H3. Sertakan tajuk meta dan perihalan meta. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti \'Ia bukan X, tetapi Y\' atau \'Ia bukan X. Ia adalah Y.\'.',
      en: 'You are an SEO expert and content writer. Generate a well-researched, comprehensive, and SEO-optimized article. Integrate the provided keywords naturally. Structure the article with H1, H2, and H3 tags. Include a meta title and meta description. Avoid repetitive sentence structures, especially comparison patterns like \'It\'s not X, but Y\' or \'It\'s not X. It is Y.\'.'
    }
  },
  // --- PEMASARAN ---
  {
    id: ToolId.AdsManagement,
    nameKey: 'tools.ads_management.name',
    descriptionKey: 'tools.ads_management.description',
    icon: <IconWrapper><rect x="3" y="3" width="18" height="18" rx="2" /><path d="M15 3v18" /><path d="M8.5 9h-2" /><path d="M8.5 15h-2" /><path d="m12.5 9-.01 0" /><path d="m12.5 15-.01 0" /></IconWrapper>,
    categoryKey: 'toolCategories.marketing',
  },
  {
    id: ToolId.EmailMarketing,
    nameKey: 'tools.email_marketing.name',
    descriptionKey: 'tools.email_marketing.description',
    icon: <IconWrapper><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></IconWrapper>,
    categoryKey: 'toolCategories.marketing',
    systemInstruction: {
      ms: 'Anda adalah seorang pakar pemasaran e-mel. Pengguna akan memberikan templat e-mel yang sebahagiannya diisi dan beberapa butiran tambahan. Tugas anda adalah untuk mengembangkan ini menjadi e-mel yang lengkap, profesional, dan menarik. Pastikan baris subjek menarik, badan e-mel ditulis dengan baik, dan seruan tindak adalah jelas. Kekalkan nada yang konsisten dengan permintaan. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti \'Ia bukan X, tetapi Y\' atau \'Ia bukan X. Ia adalah Y.\'.',
      en: 'You are an email marketing specialist. The user will provide a partially filled email template and some additional details. Your task is to expand this into a complete, professional, and engaging email. Ensure the subject line is catchy, the body is well-written, and the call-to-action is clear. Maintain a consistent tone with the request. Avoid repetitive sentence structures, especially comparison patterns like \'It\'s not X, but Y\' or \'It\'s not X. It is Y.\'.'
    }
  },
  {
    id: ToolId.ContentManagement,
    nameKey: 'tools.content_management.name',
    descriptionKey: 'tools.content_management.description',
    icon: <IconWrapper><rect width="18" height="18" x="3" y="4" rx="2" ry="2" /><line x1="16" x2="16" y1="2" y2="6" /><line x1="8" x2="8" y1="2" y2="6" /><line x1="3" x2="21" y1="10" y2="10" /></IconWrapper>,
    categoryKey: 'toolCategories.marketing',
  },
  {
    id: ToolId.CustomerSupport,
    nameKey: 'tools.customer_support.name',
    descriptionKey: 'tools.customer_support.description',
    icon: <IconWrapper><path d="M3 14h3a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a9 9 0 0 1 18 0v7a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-2a2 2 0 0 1 2-2h3"/></IconWrapper>,
    categoryKey: 'toolCategories.marketing',
    systemInstruction: {
      ms: 'Anda adalah pembantu sokongan pelanggan yang membantu dan berempati. Hasilkan respons yang jelas, ringkas, dan mesra kepada pertanyaan pelanggan berdasarkan gesaan pengguna. Utamakan kependekkan dan kelajuan. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti \'Ia bukan X, tetapi Y\' atau \'Ia bukan X. Ia adalah Y.\'.',
      en: 'You are a helpful and empathetic customer support assistant. Generate clear, concise, and friendly responses to customer queries based on the user\'s prompt. Prioritize brevity and speed. Avoid repetitive sentence structures, especially comparison patterns like \'It\'s not X, but Y\' or \'It\'s not X. It is Y.\'.'
    }
  },
  {
    id: ToolId.UtmSettings,
    nameKey: 'tools.utm_settings.name',
    descriptionKey: 'tools.utm_settings.description',
    icon: <IconWrapper><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.72"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.72-1.72"/></IconWrapper>,
    categoryKey: 'toolCategories.marketing',
  },
  // --- MEDIA ---
  {
    id: ToolId.PhotoGenerator,
    nameKey: 'tools.photo_generator.name',
    descriptionKey: 'tools.photo_generator.description',
    icon: <IconWrapper><rect width="18" height="18" x="3" y="3" rx="2" ry="2" /><circle cx="9" cy="9" r="2" /><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" /></IconWrapper>,
    categoryKey: 'toolCategories.media',
  },
  {
    id: ToolId.ImageAnalysis,
    nameKey: 'tools.image_analysis.name',
    descriptionKey: 'tools.image_analysis.description',
    icon: <IconWrapper><circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" /><rect x="3" y="3" width="18" height="18" rx="2" /></IconWrapper>,
    categoryKey: 'toolCategories.media',
    systemInstruction: {
      ms: 'Anda adalah seorang penganalisis imej yang pakar. Terangkan kandungan imej dengan terperinci dan jawab sebarang soalan pengguna mengenainya.',
      en: 'You are an expert image analyst. Describe the contents of the image in detail and answer any user questions about it.'
    }
  },
  {
    id: ToolId.PaintingTools,
    nameKey: 'tools.painting_tools.name',
    descriptionKey: 'tools.painting_tools.description',
    icon: <IconWrapper><path d="M12 20h9" /><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z" /><path d="m15 5 4 4" /><path d="M22 22 11 11" /></IconWrapper>,
    categoryKey: 'toolCategories.media',
  },
  {
    id: ToolId.AnimationGenerator,
    nameKey: 'tools.animation_generator.name',
    descriptionKey: 'tools.animation_generator.description',
    icon: <IconWrapper><path d="M2 6a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2Z"/><path d="M6 2v20"/><path d="M18 2v20"/></IconWrapper>,
    categoryKey: 'toolCategories.media',
  },
  {
    id: ToolId.VideoGenerator,
    nameKey: 'tools.video_generator.name',
    descriptionKey: 'tools.video_generator.description',
    icon: <IconWrapper><path d="m22 8-6 4 6 4V8Z" /><rect width="14" height="12" x="2" y="6" rx="2" ry="2" /></IconWrapper>,
    categoryKey: 'toolCategories.media',
  },
  {
    id: ToolId.VideoAnalysis,
    nameKey: 'tools.video_analysis.name',
    descriptionKey: 'tools.video_analysis.description',
    icon: <IconWrapper><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"/><path d="M7 2v20"/><path d="M17 2v20"/><path d="M2 12h20"/><path d="M2 7h5"/><path d="M2 17h5"/><path d="M17 17h5"/><path d="M17 7h5"/><circle cx="12" cy="12" r="3"/><line x1="14.5" y1="14.5" x2="16" y2="16"/></IconWrapper>,
    categoryKey: 'toolCategories.media',
  },
  {
    id: ToolId.AudioGenerator,
    nameKey: 'tools.audio_generator.name',
    descriptionKey: 'tools.audio_generator.description',
    icon: <IconWrapper><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></IconWrapper>,
    categoryKey: 'toolCategories.media',
  },
  {
    id: ToolId.AudioTranscription,
    nameKey: 'tools.audio_transcription.name',
    descriptionKey: 'tools.audio_transcription.description',
    icon: <IconWrapper><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/><line x1="17" y1="14" x2="22" y2="14"/><line x1="17" y1="10" x2="22" y2="10"/></IconWrapper>,
    categoryKey: 'toolCategories.media',
  },
  {
    id: ToolId.LiveChat,
    nameKey: 'tools.live_chat.name',
    descriptionKey: 'tools.live_chat.description',
    icon: <IconWrapper><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></IconWrapper>,
    categoryKey: 'toolCategories.media',
  },
  // --- UTILITI ---
  {
    id: ToolId.TextEditing,
    nameKey: 'tools.text_editing.name',
    descriptionKey: 'tools.text_editing.description',
    icon: <IconWrapper><polyline points="4 7 4 4 20 4 20 7" /><line x1="9" y1="20" x2="15" y2="20" /><line x1="12" y1="4" x2="12" y2="20" /></IconWrapper>,
    categoryKey: 'toolCategories.utilities',
  },
  {
    id: ToolId.Chatbot,
    nameKey: 'tools.chatbot.name',
    descriptionKey: 'tools.chatbot.description',
    icon: <IconWrapper><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></IconWrapper>,
    categoryKey: 'toolCategories.utilities',
  },
  {
    id: ToolId.CodeDocumentation,
    nameKey: 'tools.code_documentation.name',
    descriptionKey: 'tools.code_documentation.description',
    icon: <IconWrapper><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></IconWrapper>,
    categoryKey: 'toolCategories.utilities',
    systemInstruction: {
      ms: 'Anda adalah jurutera perisian kanan yang pakar dalam menulis dokumentasi kod yang jelas dan ringkas. Berdasarkan coretan kod yang diberikan, jana dokumentasi dalam format Markdown. Sertakan perihalan peringkat tinggi, penjelasan parameter, dan nilai pulangan. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti \'Ia bukan X, tetapi Y\' atau \'Ia bukan X. Ia adalah Y.\'.',
      en: 'You are a senior software engineer who specializes in writing clear and concise code documentation. Based on the provided code snippet, generate documentation in Markdown format. Include a high-level description, parameter explanations, and return values. Avoid repetitive sentence structures, especially comparison patterns like \'It\'s not X, but Y\' or \'It\'s not X. It is Y.\'.'
    }
  },
  {
    id: ToolId.AcademicResearch,
    nameKey: 'tools.academic_research.name',
    descriptionKey: 'tools.academic_research.description',
    icon: <IconWrapper><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/><path d="m9 7 3 2.5 3-2.5"/><path d="M12 15v-5"/></IconWrapper>,
    categoryKey: 'toolCategories.utilities',
  },
  {
    id: ToolId.LocalDiscovery,
    nameKey: 'tools.local_discovery.name',
    descriptionKey: 'tools.local_discovery.description',
    icon: <IconWrapper><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" /></IconWrapper>,
    categoryKey: 'toolCategories.utilities',
  },
  {
    id: ToolId.EbookReader,
    nameKey: 'tools.ebook_reader.name',
    descriptionKey: 'tools.ebook_reader.description',
    icon: <IconWrapper><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></IconWrapper>,
    categoryKey: 'toolCategories.utilities',
  },
  {
    id: ToolId.ProjectManagement,
    nameKey: 'tools.project_management.name',
    descriptionKey: 'tools.project_management.description',
    icon: <IconWrapper><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/></IconWrapper>,
    categoryKey: 'toolCategories.utilities',
  },
  {
    id: ToolId.SupplyChainManagement,
    nameKey: 'tools.supply_chain_management.name',
    descriptionKey: 'tools.supply_chain_management.description',
    icon: <IconWrapper><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></IconWrapper>,
    categoryKey: 'toolCategories.utilities',
    systemInstruction: {
      ms: 'Anda adalah seorang penganalisis rantaian bekalan dan saintis data kanan. Tugas anda adalah untuk menganalisis data/senario yang diberikan, mengenal pasti cerapan utama, dan menjana laporan berstruktur termasuk ringkasan eksekutif, penemuan utama, syor boleh tindak, dan cadangan untuk visualisasi data. Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti \'Ia bukan X, tetapi Y\' atau \'Ia bukan X. Ia adalah Y.\'.',
      en: 'You are a senior supply chain analyst and data scientist. Your task is to analyze the provided data/scenario, identify key insights, and generate a structured report including an executive summary, key findings, actionable recommendations, and suggestions for data visualizations. Avoid repetitive sentence structures, especially comparison patterns like \'It\'s not X, but Y\' or \'It\'s not X. It is Y.\'.'
    }
  },
  {
    id: ToolId.WarehousingManagement,
    nameKey: 'tools.warehousing_management.name',
    descriptionKey: 'tools.warehousing_management.description',
    icon: <IconWrapper><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="3" y1="15" x2="21" y2="15"/><line x1="9" y1="3" x2="9" y2="21"/><line x1="15" y1="3" x2="15" y2="21"/></IconWrapper>,
    categoryKey: 'toolCategories.utilities',
    systemInstruction: {
      ms: 'Anda adalah seorang penganalisis logistik dan pergudangan kanan. Tugas anda adalah untuk menganalisis data/senario yang diberikan berkaitan operasi gudang, mengenal pasti cerapan utama, dan menjana laporan berstruktur termasuk ringkasan eksekutif, penemuan utama, syor boleh tindak, dan cadangan untuk visualisasi data (cth., penggunaan ruang, kadar pusing ganti inventori). Elakkan struktur ayat yang berulang-ulang, terutamanya corak perbandingan seperti \'Ia bukan X, tetapi Y\' atau \'Ia bukan X. Ia adalah Y.\'.',
      en: 'You are a senior warehousing and logistics analyst. Your task is to analyze the provided data/scenario related to warehouse operations, identify key insights, and generate a structured report including an executive summary, key findings, actionable recommendations, and suggestions for data visualizations (e.g., space utilization, inventory turnover rates). Avoid repetitive sentence structures, especially comparison patterns like \'It\'s not X, but Y\' or \'It\'s not X. It is Y.\'.'
    }
  },
];

export const SHORTCUT_KEY_MAP: Record<string, ToolId> = {
  // Main
  '0': ToolId.Dashboard,
  
  // Writing
  '1': ToolId.ContentWriting,
  '2': ToolId.Copywriting,
  '3': ToolId.CreativeWriting,
  '4': ToolId.SeoArticle,
  '5': ToolId.IdeaGenerator,
  '6': ToolId.BookPublishing,
  '7': ToolId.MyBlog,
  '8': ToolId.CommunityFeed,
  
  // Marketing
  'q': ToolId.AdsManagement,
  'w': ToolId.EmailMarketing,
  'e': ToolId.ContentManagement,
  'r': ToolId.CustomerSupport,
  't': ToolId.UtmSettings,

  // Media
  'a': ToolId.PhotoGenerator,
  's': ToolId.ImageAnalysis,
  'd': ToolId.PaintingTools,
  'f': ToolId.AnimationGenerator,
  'g': ToolId.VideoGenerator,
  'h': ToolId.VideoAnalysis,
  'j': ToolId.AudioGenerator,
  'k': ToolId.AudioTranscription,
  'l': ToolId.LiveChat,

  // Utilities & Others
  'z': ToolId.TextEditing,
  'x': ToolId.AcademicResearch,
  'c': ToolId.LocalDiscovery,
  'v': ToolId.EbookReader,
  'b': ToolId.CodeDocumentation,
  'n': ToolId.ProjectManagement,
  'm': ToolId.Chatbot,
  'y': ToolId.SupplyChainManagement,
  'u': ToolId.WarehousingManagement,
};

export const TOOL_SHORTCUT_STRINGS: Partial<Record<ToolId, string>> = Object.entries(
  SHORTCUT_KEY_MAP
).reduce((acc, [key, toolId]) => {
  acc[toolId] = `Alt + ${key}`;
  return acc;
}, {} as Partial<Record<ToolId, string>>);