import React from 'react';

export enum ToolId {
  Dashboard = 'dashboard',
  ContentWriting = 'content-writing',
  ContentManagement = 'content-management',
  Copywriting = 'copywriting',
  AdsManagement = 'ads-management',
  CreativeWriting = 'creative-writing',
  SeoArticle = 'seo-article',
  EmailMarketing = 'email-marketing',
  CustomerSupport = 'customer-support',
  UtmSettings = 'utm-settings',
  CodeDocumentation = 'code-documentation',
  TextEditing = 'text-editing',
  BookPublishing = 'book-publishing',
  IdeaGenerator = 'idea-generator',
  AcademicResearch = 'academic-research',
  LocalDiscovery = 'local-discovery',
  EbookReader = 'ebook-reader',
  PhotoGenerator = 'photo-generator',
  VideoGenerator = 'video-generator',
  AnimationGenerator = 'animation-generator',
  PaintingTools = 'painting-tools',
  ImageAnalysis = 'image-analysis',
  VideoAnalysis = 'video-analysis',
  AudioGenerator = 'audio-generator',
  AudioTranscription = 'audio-transcription',
  LiveChat = 'live-chat',
  ProjectManagement = 'project-management',
  MyBlog = 'my-blog',
  CommunityFeed = 'community-feed',
  Chatbot = 'chatbot',
  SupplyChainManagement = 'supply-chain-management',
  WarehousingManagement = 'warehousing-management',
}


export interface Tool {
  id: ToolId;
  nameKey: string;
  descriptionKey: string;
  icon: React.ReactElement;
  categoryKey: string;
  systemInstruction?: { ms: string; en: string };
}

export interface User {
  id: string;
}

export type ProjectStatus = 'Belum Mula' | 'Dalam Proses' | 'Selesai' | 'Ditangguhkan';
export type ProjectPriority = 'Rendah' | 'Sederhana' | 'Tinggi';

export interface Project {
  id: string;
  name: string;
  client: string;
  deadline: string;
  status: ProjectStatus;
  priority: ProjectPriority;
  assignee: string;
  estimatedHours: number;
  notes: string;
}

export type PostCategory = 'Puisi' | 'Cerpen' | 'Esei' | 'Novel';

export interface Post {
  id: string;
  title: string;
  content: string;
  timestamp: string; // ISO string for the date
  authorId?: string;
  category?: PostCategory;
}

export interface HistoryItem {
  prompt: string;
  timestamp: number;
}

export interface Slide {
    title: string;
    content: string; // Markdown content
    speaker_notes?: string;
}
export interface ContentIdea {
  day: number;
  topic_idea: string;
  post_draft: string;
}

export type SocialPlatform = 'Facebook' | 'Twitter' | 'Instagram' | 'LinkedIn';

export interface SocialPost {
  id: string;
  content: string;
  scheduledDate: string; // YYYY-MM-DD format
  platform: SocialPlatform;
}