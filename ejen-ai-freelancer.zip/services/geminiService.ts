import {
    GoogleGenAI,
    GenerateContentResponse,
    Content,
    Part,
    FunctionDeclaration,
    Type,
    Modality,
} from '@google/genai';
import { AiLang } from '../contexts/LanguageContext';
import type { Slide, ContentIdea } from '../types';

// --- HELPER FUNCTIONS ---

const fileToGenerativePart = async (file: File): Promise<Part> => {
    const base64Data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve((reader.result as string).split(',')[1]);
        reader.onerror = error => reject(error);
    });
    return {
        inlineData: {
            mimeType: file.type,
            data: base64Data,
        },
    };
};


// --- TEXT GENERATION ---

export const generateText = async (
    ai: GoogleGenAI,
    prompt: string,
    systemInstruction?: string,
    image?: File | null,
    documentText?: string | null
): Promise<string> => {
    const parts: Part[] = [];

    if (documentText) {
        prompt = `Using the following document as context, please answer the user's request.\n\nDOCUMENT:\n"""\n${documentText}\n"""\n\nUSER REQUEST:\n${prompt}`;
    }

    if (image) {
        parts.push(await fileToGenerativePart(image));
    }

    parts.push({ text: prompt });

    const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [{ parts }],
        config: {
            systemInstruction: systemInstruction,
        },
    });

    return response.text;
};

export const generateTextWithThinking = async (
    ai: GoogleGenAI,
    prompt: string,
    systemInstruction?: string,
    image?: File | null,
    documentText?: string | null
): Promise<string> => {
    const parts: Part[] = [];

    if (documentText) {
        prompt = `Using the following document as context, please answer the user's request.\n\nDOCUMENT:\n"""\n${documentText}\n"""\n\nUSER REQUEST:\n${prompt}`;
    }

    if (image) {
        parts.push(await fileToGenerativePart(image));
    }

    parts.push({ text: prompt });

    const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: [{ parts }],
        config: {
            systemInstruction: systemInstruction,
            thinkingConfig: { thinkingBudget: 8192 }
        },
    });

    return response.text;
};

export const generateTextLite = async (
    ai: GoogleGenAI,
    prompt: string,
    systemInstruction?: string
): Promise<string> => {
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-flash-lite-latest',
        contents: [{ parts: [{ text: prompt }] }],
        config: {
            systemInstruction: systemInstruction,
            thinkingConfig: { thinkingBudget: 0 }
        },
    });
    return response.text;
};


// --- IMAGE GENERATION ---

export const generateImage = async (
    ai: GoogleGenAI,
    prompt: string,
    referenceImage: File | null,
    numberOfImages: number,
    aspectRatio: string
): Promise<{ imageUrls: string[], enhancedPrompt: string }> => {
    
    // For now, we will use imagen as reference image is not straightforward with gemini-2.5-flash-image
    const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: prompt,
        config: {
          numberOfImages: numberOfImages,
          aspectRatio: aspectRatio,
        },
    });

    const imageUrls = response.generatedImages.map(img => {
        const blob = new Blob([img.image.imageBytes], { type: 'image/png' }); // Assuming PNG, might need adjustment
        return URL.createObjectURL(blob);
    });

    // Imagen API doesn't return an enhanced prompt in the same way, so we'll just return the original.
    const enhancedPrompt = prompt;

    return { imageUrls, enhancedPrompt };
};

export const editImage = async (
    ai: GoogleGenAI,
    prompt: string,
    image: File
): Promise<{ imageUrl: string | null; text: string | null }> => {
    const imagePart = await fileToGenerativePart(image);
    const textPart = { text: prompt };

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: { parts: [imagePart, textPart] },
        config: {
            responseModalities: [Modality.IMAGE],
        },
    });

    let imageUrl: string | null = null;
    let text: string | null = null;

    for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
            const base64ImageBytes = part.inlineData.data;
            imageUrl = `data:${part.inlineData.mimeType};base64,${base64ImageBytes}`;
        }
        if (part.text) {
            text = part.text;
        }
    }
    return { imageUrl, text };
};


// --- SEARCH & MAPS ---

export interface SearchResult {
    text: string;
    sources: { web: { uri: string, title: string } }[];
}
export interface MapGroundingSource {
    uri: string;
    title: string;
    latLng?: { latitude: number; longitude: number; };
    placeAnswerSources?: { reviewSnippets?: any[] };
}
export interface SearchResultWithMaps {
    text: string;
    sources: { web?: { uri: string, title: string }; maps?: MapGroundingSource }[];
}

export const generateWithSearch = async (
    ai: GoogleGenAI,
    prompt: string,
    systemInstruction?: string,
    image?: File | null,
    documentText?: string | null
): Promise<SearchResult> => {
    const parts: Part[] = [];

    if (documentText) {
        prompt = `Using this doc as context: "${documentText}", answer: ${prompt}`;
    }
    if (image) {
        parts.push(await fileToGenerativePart(image));
    }
    parts.push({ text: prompt });

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [{ parts }],
        config: {
            tools: [{ googleSearch: {} }],
            systemInstruction,
        },
    });

    return {
        text: response.text,
        sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || [],
    };
};

export const generateWithMaps = async (
    ai: GoogleGenAI,
    prompt: string,
    location: { latitude: number; longitude: number; },
    systemInstruction?: string
): Promise<SearchResultWithMaps> => {
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            tools: [{ googleMaps: {} }],
            toolConfig: {
                retrievalConfig: {
                    latLng: location,
                }
            },
            systemInstruction,
        },
    });

    return {
        text: response.text,
        sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || [],
    };
};


// --- SPECIALIZED TOOLS ---

// Types for structured reports
export interface ReportData {
  executive_summary: string;
  key_findings: string[];
  recommendations: string[];
  visualizations: {
    title: string;
    type: 'bar' | 'line' | 'pie';
    data: any[];
    description: string;
  }[];
}

const reportSchema = {
    type: Type.OBJECT,
    properties: {
        executive_summary: { type: Type.STRING, description: "A high-level overview of the main findings and recommendations." },
        key_findings: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of the most important insights discovered from the data." },
        recommendations: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of actionable steps to take based on the findings." },
        visualizations: {
            type: Type.ARRAY,
            description: "Suggestions for charts to visualize the data. Ensure data provided is a valid JSON array of objects.",
            items: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING, description: "A descriptive title for the chart." },
                    type: { type: Type.STRING, enum: ['bar', 'line', 'pie'], description: "The type of chart to render." },
                    data: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: {} }, description: "Data for the chart, where each object is a data point (e.g., {'name': 'Category A', 'value': 400})." },
                    description: { type: Type.STRING, description: "A brief explanation of what the chart shows." }
                },
                required: ['title', 'type', 'data', 'description']
            }
        }
    },
    required: ['executive_summary', 'key_findings', 'recommendations', 'visualizations']
};

export const analyzeSupplyChainData = async (ai: GoogleGenAI, data: string, goal: string, systemInstruction: string): Promise<ReportData> => {
  const prompt = `Analyze the following supply chain data/scenario. My specific goal is: "${goal}". Please provide a comprehensive analysis. Data:\n\n"""\n${data}\n"""`;
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-pro',
    contents: prompt,
    config: {
      systemInstruction,
      responseMimeType: 'application/json',
      responseSchema: reportSchema as any
    }
  });
  return JSON.parse(response.text.trim());
};

export const analyzeWarehousingData = async (ai: GoogleGenAI, data: string, goal: string, systemInstruction: string): Promise<ReportData> => {
  const prompt = `Analyze the following warehousing data/scenario. My specific goal is: "${goal}". Please provide a comprehensive analysis. Data:\n\n"""\n${data}\n"""`;
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-pro',
    contents: prompt,
    config: {
      systemInstruction,
      responseMimeType: 'application/json',
      responseSchema: reportSchema as any
    }
  });
  return JSON.parse(response.text.trim());
};

const presentationSchema = {
    type: Type.OBJECT,
    properties: {
        slides: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING, description: "The title of the slide." },
                    content: { type: Type.STRING, description: "The main content of the slide, formatted as Markdown bullet points." },
                    speaker_notes: { type: Type.STRING, description: "Brief notes for the presenter for this slide." }
                },
                required: ['title', 'content', 'speaker_notes']
            }
        }
    },
    required: ['slides']
};

export const generatePresentationFromReport = async (ai: GoogleGenAI, report: ReportData, context: 'Supply Chain' | 'Warehousing'): Promise<{ slides: Slide[] }> => {
    const prompt = `You are a business presentation designer. Convert the following ${context} analysis report into a professional slide presentation. For each slide, provide a clear title, concise bullet points for the content (using Markdown), and brief, helpful speaker notes. Avoid repetitive sentence structures, especially comparison patterns like "It's not X, but Y" or "It's not X. It is Y.".

    Report to convert:
    - Executive Summary: ${report.executive_summary}
    - Key Findings: ${report.key_findings.join('; ')}
    - Recommendations: ${report.recommendations.join('; ')}
    `;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: presentationSchema as any
        }
    });
    const result = JSON.parse(response.text.trim());
    return result;
};


export const translateText = async (ai: GoogleGenAI, text: string, targetLanguage: string): Promise<string> => {
    const prompt = `Translate the following text into ${targetLanguage}:\n\n"""${text}"""`;
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    return response.text;
};

// Types for Ads Manager
export interface GoogleAdGroup { name: string; keywords: string[]; headlines: string[]; descriptions: string[]; suggested_budget_allocation?: string; }
export interface FacebookAdSet { name: string; targeting_details: string; headline: string; primary_text: string; image_video_suggestion: string; suggested_budget_allocation?: string; }
export interface LinkedInAd { name: string; targeting_details: string; headline: string; introductory_text: string; image_video_suggestion: string; suggested_budget_allocation?: string; }
export interface TikTokAd { name: string; targeting_details: string; video_concept: string; ad_text: string; suggested_sound: string; suggested_budget_allocation?: string; }
export interface AdCampaignSuggestion { platform: string; campaign_name: string; suggested_funnel?: string; platform_budget_suggestion?: string; ad_groups?: GoogleAdGroup[]; ad_sets?: FacebookAdSet[]; ads?: LinkedInAd[]; tiktok_ads?: TikTokAd[]; }
export interface AdCampaignResult { campaignSuggestions: AdCampaignSuggestion[]; }

export const generateAdCampaign = async (ai: GoogleGenAI, productName: string, productDescription: string, targetAudience: string, platforms: string[], cta: string, budget: string, lang: AiLang, image?: File | null, documentText?: string | null): Promise<AdCampaignResult> => {
    let context = '';
    if (documentText) context += `\nADDITIONAL CONTEXT FROM DOCUMENT:\n${documentText}`;

    const prompt = `Generate a comprehensive ad campaign setup.
    - Product: ${productName}
    - Description: ${productDescription}
    - Target Audience: ${targetAudience}
    - Platforms: ${platforms.join(', ')}
    - Call to Action: ${cta}
    - Budget Info: ${budget}
    - Language: ${lang}
    ${context}
    Provide a detailed setup for each platform.`;

    const parts: Part[] = [];
    if (image) parts.push(await fileToGenerativePart(image));
    parts.push({ text: prompt });

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: [{ parts }],
        config: {
            responseMimeType: "application/json",
            responseSchema: { /* Define schema here */ type: Type.OBJECT, properties: { campaignSuggestions: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { /* ... all fields */ } } } } } as any,
        }
    });
    return JSON.parse(response.text.trim());
};

export const getProjectAssistance = (ai: GoogleGenAI, prompt: string): Promise<string> => {
    return generateText(ai, prompt, "You are an expert project manager assistant. Avoid repetitive sentence structures, especially comparison patterns like \"It's not X, but Y\" or \"It's not X. It is Y.\"");
};

export const fetchCodeFromUrl = async (ai: GoogleGenAI, url: string): Promise<string> => {
    const prompt = `Please retrieve the raw text content from the following URL. Respond with ONLY the raw text content, without any commentary, introductions, or markdown formatting. If the URL contains code, return just the code. If it's an article, return the article text.

URL: ${url}`;
    
    const response = await ai.models.generateContent({
        model: 'gemini-flash-lite-latest',
        contents: prompt,
        config: {
            thinkingConfig: { thinkingBudget: 0 }
        }
    });

    return response.text;
};

export const generateContentPlan = async (ai: GoogleGenAI, topic: string, lang: AiLang): Promise<ContentIdea[]> => {
    const prompt = `Act as a senior social media strategist. Your task is to generate a comprehensive 30-day content plan for the following topic: "${topic}". 
    For each day, provide a unique topic idea and a short, engaging post draft complete with relevant hashtags. The language for the output should be ${lang}.`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    plan: {
                        type: Type.ARRAY,
                        description: 'A 30-day content plan.',
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                day: { type: Type.NUMBER, description: 'Day of the month (1-30).' },
                                topic_idea: { type: Type.STRING, description: 'A brief, catchy topic idea or headline.' },
                                post_draft: { type: Type.STRING, description: 'A short draft for the social media post, including hashtags.' }
                            },
                            required: ['day', 'topic_idea', 'post_draft']
                        }
                    }
                },
                required: ['plan']
            } as any,
        }
    });

    const result = JSON.parse(response.text.trim());
    return result.plan || [];
};


// --- AUDIO & VIDEO ---

export const generateSpeech = async (ai: GoogleGenAI, text: string, voiceName: string): Promise<string> => {
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text }] }],
        config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
                voiceConfig: {
                    prebuiltVoiceConfig: { voiceName },
                },
            },
        },
    });
    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
        throw new Error("API did not return audio data.");
    }
    return base64Audio;
};

export type VideoGenerationStatus = { message: string; };

export interface AnimationGenerationStatus { progress: number; message: string; }

export const generateAnimationFrames = async (
    ai: GoogleGenAI,
    prompt: string,
    frameCount: number,
    aspectRatio: string,
    setStatus: (status: AnimationGenerationStatus) => void
): Promise<{ imageUrls: string[] }> => {
    const imageUrls: string[] = [];
    for (let i = 0; i < frameCount; i++) {
        const framePrompt = `${prompt}. This is frame ${i + 1} of a ${frameCount}-frame animation.`;
        setStatus({ progress: (i / frameCount) * 100, message: `Generating frame ${i + 1} of ${frameCount}...` });
        
        const response = await ai.models.generateImages({
            model: 'imagen-4.0-generate-001',
            prompt: framePrompt,
            config: {
                numberOfImages: 1,
                aspectRatio,
            },
        });

        if (response.generatedImages && response.generatedImages.length > 0) {
            const blob = new Blob([response.generatedImages[0].image.imageBytes], { type: 'image/png' });
            imageUrls.push(URL.createObjectURL(blob));
        } else {
            throw new Error(`Failed to generate frame ${i + 1}.`);
        }
    }
    setStatus({ progress: 100, message: 'All frames generated.' });
    return { imageUrls };
};

export const generateTextFromVideo = async (
  ai: GoogleGenAI,
  prompt: string,
  videoFile: File
): Promise<string> => {
    const videoPart = await fileToGenerativePart(videoFile);
    const textPart = { text: prompt };

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [videoPart, textPart] }
    });
    return response.text;
};

export const transcribeAudio = async (
    ai: GoogleGenAI,
    audioBlob: Blob,
    language: AiLang
): Promise<string> => {
    const audioFile = audioBlob instanceof File
        ? audioBlob
        : new File([audioBlob], "audio.webm", { type: audioBlob.type });
    const audioPart = await fileToGenerativePart(audioFile);
    const promptPart = { text: `Transcribe this audio. The language is ${language}.` };

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [audioPart, promptPart] }
    });
    return response.text;
};
