import React, { createContext, useState, useContext, useEffect, ReactNode, useCallback } from 'react';
// FIX: Corrected import path for translations.
import { translations } from '../translations';

export type UiLang = 'ms' | 'en';
export type AiLang = 'Bahasa Malaysia' | 'English';

interface LanguageContextType {
  uiLang: UiLang;
  setUiLang: (lang: UiLang) => void;
  aiLang: AiLang;
  setAiLang: (lang: AiLang) => void;
  t: (key: string, replacements?: Record<string, string | number>) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const UI_LANG_KEY = 'ejen_ai_ui_lang';
const AI_LANG_KEY = 'ejen_ai_ai_lang';

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [uiLang, setUiLangState] = useState<UiLang>('ms');
  const [aiLang, setAiLangState] = useState<AiLang>('Bahasa Malaysia');

  // useEffect(() => {
  //   const storedUiLang = localStorage.getItem(UI_LANG_KEY) as UiLang;
  //   if (storedUiLang && ['ms', 'en'].includes(storedUiLang)) {
  //     setUiLangState(storedUiLang);
  //   }
  //   const storedAiLang = localStorage.getItem(AI_LANG_KEY) as AiLang;
  //   if (storedAiLang && ['Bahasa Malaysia', 'English'].includes(storedAiLang)) {
  //     setAiLangState(storedAiLang);
  //   }
  // }, []);
  
  const setUiLang = (lang: UiLang) => {
    setUiLangState(lang);
    localStorage.setItem(UI_LANG_KEY, lang);
  };

  const setAiLang = (lang: AiLang) => {
    setAiLangState(lang);
    localStorage.setItem(AI_LANG_KEY, lang);
  };
  
  const t = useCallback((key: string, replacements?: Record<string, string | number>): string => {
    const keys = key.split('.');
    let result: any = translations[uiLang];
    
    // Primary language lookup
    for (const k of keys) {
      result = result?.[k];
      if (result === undefined) break;
    }

    // Fallback to English if key not found
    if (result === undefined) {
        let fallbackResult: any = translations['en'];
        for (const k of keys) {
            fallbackResult = fallbackResult?.[k];
            if (fallbackResult === undefined) return key; // Return key if not in fallback either
        }
        result = fallbackResult;
    }

    if (typeof result !== 'string') {
        return key;
    }

    if (replacements) {
        return Object.entries(replacements).reduce((acc, [k, v]) => {
            return acc.replace(new RegExp(`{{${k}}}`, 'g'), String(v));
        }, result);
    }
    
    return result;
  }, [uiLang]);

  return (
    <LanguageContext.Provider value={{ uiLang, setUiLang, aiLang, setAiLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
