import React, { createContext, useState, useContext, useEffect, ReactNode, useCallback } from 'react';
import { ToolId } from '../types';

const ANALYTICS_STORAGE_KEY = 'ejen_ai_analytics_data';

export type UsageData = Partial<Record<ToolId, number>>;

interface AnalyticsContextType {
  usageData: UsageData;
  trackToolUsage: (toolId: ToolId) => void;
  clearUsageData: () => void;
}

const AnalyticsContext = createContext<AnalyticsContextType | undefined>(undefined);

export const AnalyticsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [usageData, setUsageData] = useState<UsageData>({});

  useEffect(() => {
    try {
      const storedData = localStorage.getItem(ANALYTICS_STORAGE_KEY);
      if (storedData) {
        setUsageData(JSON.parse(storedData));
      }
    } catch (error) {
      console.error("Failed to load analytics data from localStorage:", error);
    }
  }, []);

  const trackToolUsage = useCallback((toolId: ToolId) => {
    setUsageData(prevData => {
      const newData = {
        ...prevData,
        [toolId]: (prevData[toolId] || 0) + 1,
      };
      try {
        localStorage.setItem(ANALYTICS_STORAGE_KEY, JSON.stringify(newData));
      } catch (e) {
        console.error("Failed to save analytics data:", e);
      }
      return newData;
    });
  }, []);
  
  const clearUsageData = useCallback(() => {
      setUsageData({});
      localStorage.removeItem(ANALYTICS_STORAGE_KEY);
  }, []);

  return (
    <AnalyticsContext.Provider value={{ usageData, trackToolUsage, clearUsageData }}>
      {children}
    </AnalyticsContext.Provider>
  );
};

export const useAnalytics = (): AnalyticsContextType => {
  const context = useContext(AnalyticsContext);
  if (context === undefined) {
    throw new Error('useAnalytics must be used within an AnalyticsProvider');
  }
  return context;
};