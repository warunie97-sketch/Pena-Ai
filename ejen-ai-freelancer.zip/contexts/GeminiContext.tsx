import React, { createContext, useState, useContext, useEffect, ReactNode, useCallback } from 'react';
import { GoogleGenAI } from '@google/genai';

interface GeminiContextType {
  aiInstance: GoogleGenAI | null;
  apiKey: string | null;
  isKeySet: boolean;
  setApiKey: (key: string) => void;
  clearApiKey: () => void;
  isModalOpen: boolean;
  openModal: () => void;
  closeModal: () => void;
  requestsMade: number;
  requestLimit: number;
  incrementRequestCount: () => void;
  error: string | null;
}

const GeminiContext = createContext<GeminiContextType | undefined>(undefined);

const API_KEY_STORAGE_KEY = 'gemini_api_key';
const REQUEST_COUNT_SESSION_KEY = 'gemini_request_count';
const REQUEST_LIMIT = 60;

export const GeminiProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [apiKey, _setApiKey] = useState<string | null>(null);
  const [aiInstance, setAiInstance] = useState<GoogleGenAI | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [requestsMade, setRequestsMade] = useState<number>(() => {
    try {
      const storedCount = sessionStorage.getItem(REQUEST_COUNT_SESSION_KEY);
      return storedCount ? parseInt(storedCount, 10) : 0;
    } catch {
      return 0;
    }
  });

  const incrementRequestCount = useCallback(() => {
    setRequestsMade(prevCount => {
      const newCount = prevCount + 1;
      sessionStorage.setItem(REQUEST_COUNT_SESSION_KEY, newCount.toString());
      return newCount;
    });
  }, []);
  
  const openModal = useCallback(() => setIsModalOpen(true), []);
  
  const closeModal = useCallback(() => {
    setIsModalOpen(false);
    setError(null);
  }, []);
  
  const clearApiKey = useCallback(() => {
    localStorage.removeItem(API_KEY_STORAGE_KEY);
    _setApiKey(null);
    setError(null);
    setRequestsMade(0);
    sessionStorage.removeItem(REQUEST_COUNT_SESSION_KEY);
  }, []);

  const setApiKey = useCallback((key: string) => {
    const trimmedKey = key.trim();
    if (!trimmedKey) {
      setError('Kunci API tidak boleh kosong.');
      return;
    }
    
    try {
      // Immediately test initialization with the new key.
      new GoogleGenAI({ apiKey: trimmedKey });
      
      // If validation succeeds, commit the key to state and storage.
      localStorage.setItem(API_KEY_STORAGE_KEY, trimmedKey);
      _setApiKey(trimmedKey);
      setError(null); // Clear any previous validation errors.
      
      // Reset session request count on new key.
      setRequestsMade(0);
      sessionStorage.setItem(REQUEST_COUNT_SESSION_KEY, '0');
      closeModal();
    } catch (err) {
      // If initialization fails, show an error and keep the modal open.
      const errorMessage = err instanceof Error ? err.message : 'Kunci API yang dimasukkan tidak sah.';
      console.error("Failed to validate new API key:", err);
      setError(errorMessage);
    }
  }, [closeModal]);

  // Load stored key on initial mount
  useEffect(() => {
    const storedKey = localStorage.getItem(API_KEY_STORAGE_KEY);
    if (storedKey) {
      _setApiKey(storedKey);
    }
  }, []);

  // Effect to create/validate AI instance when API key changes
  useEffect(() => {
    if (!apiKey) {
      setAiInstance(null);
      return;
    }

    try {
      const ai = new GoogleGenAI({ apiKey });

      // Wrap core API methods to intercept calls and increment the counter
      const originalGenerateContent = ai.models.generateContent;
      ai.models.generateContent = (...args: any[]) => {
          incrementRequestCount();
          return originalGenerateContent.apply(ai.models, args as any);
      };

      const originalGenerateImages = ai.models.generateImages;
      ai.models.generateImages = (...args: any[]) => {
          incrementRequestCount();
          return originalGenerateImages.apply(ai.models, args as any);
      };
      
      const originalGenerateVideos = ai.models.generateVideos;
      ai.models.generateVideos = (...args: any[]) => {
          incrementRequestCount();
          return originalGenerateVideos.apply(ai.models, args as any);
      };
      
      const originalGetVideosOperation = ai.operations.getVideosOperation;
      ai.operations.getVideosOperation = (...args: any[]) => {
          incrementRequestCount();
          return originalGetVideosOperation.apply(ai.operations, args as any);
      };

      setAiInstance(ai);
      setError(null); // Clear any error from a previous invalid key
    } catch (err) {
      console.error("Failed to initialize with stored API key:", err);
      setError('Kunci API yang disimpan tidak lagi sah. Sila masukkan yang baharu.');
      clearApiKey(); // Use the existing clear function to handle cleanup
      openModal();
    }
  }, [apiKey, incrementRequestCount, openModal, clearApiKey]);

  const isKeySet = !!apiKey;

  return (
    <GeminiContext.Provider value={{ 
        aiInstance, 
        apiKey, 
        isKeySet, 
        setApiKey, 
        clearApiKey, 
        isModalOpen, 
        openModal, 
        closeModal,
        requestsMade,
        requestLimit: REQUEST_LIMIT,
        incrementRequestCount,
        error,
    }}>
      {children}
    </GeminiContext.Provider>
  );
};

export const useGemini = (): GeminiContextType => {
  const context = useContext(GeminiContext);
  if (context === undefined) {
    throw new Error('useGemini must be used within a GeminiProvider');
  }
  return context;
};