
import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import type { User } from '../types';

// NOTE: This is a simplified, insecure authentication system for demonstration purposes only.
// In a real-world application, never store passwords in plaintext in localStorage.
// Use a secure backend with proper password hashing and session management.
const USERS_STORAGE_KEY = 'ejen_ai_users';
const SESSION_STORAGE_KEY = 'ejen_ai_session';

interface AuthContextType {
  currentUser: User | null;
  login: (id: string, pass: string) => Promise<void>;
  signup: (id: string, pass: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    try {
      const sessionUser = localStorage.getItem(SESSION_STORAGE_KEY);
      if (sessionUser) {
        setCurrentUser(JSON.parse(sessionUser));
      }
    } catch (error) {
      console.error("Failed to load session:", error);
      localStorage.removeItem(SESSION_STORAGE_KEY);
    } finally {
        setIsLoading(false);
    }
  }, []);

  const getUsers = (): Record<string, string> => {
    try {
      const users = localStorage.getItem(USERS_STORAGE_KEY);
      return users ? JSON.parse(users) : {};
    } catch {
      return {};
    }
  };

  const login = async (id: string, pass: string): Promise<void> => {
    const users = getUsers();
    if (users[id] && users[id] === pass) {
      const user: User = { id };
      setCurrentUser(user);
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(user));
    } else {
      throw new Error('ID Pengguna atau Kata Laluan tidak sah.');
    }
  };

  const signup = async (id: string, pass: string): Promise<void> => {
    const users = getUsers();
    if (users[id]) {
      throw new Error('ID Pengguna ini telah wujud. Sila pilih yang lain.');
    }
    if (pass.length < 6) {
        throw new Error('Kata laluan mestilah sekurang-kurangnya 6 aksara.');
    }
    users[id] = pass;
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
    const user: User = { id };
    setCurrentUser(user);
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(user));
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem(SESSION_STORAGE_KEY);
  };

  return (
    <AuthContext.Provider value={{ currentUser, login, signup, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
