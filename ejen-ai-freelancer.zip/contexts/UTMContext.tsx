import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { ToolId } from '../types';

export interface UTMParams {
  utm_source?: string;
  utm_medium?: string;
  utm_campaign?: string;
  utm_term?: string;
  utm_content?: string;
}

// New structure to hold global and per-tool overrides
interface UTMSettings {
    global: UTMParams;
    overrides: Partial<Record<ToolId, UTMParams>>;
}

const UTM_SETTINGS_STORAGE_KEY = 'utm_settings_v2'; // New key to avoid conflicts

interface UTMContextType {
  getUTMParams: (toolId?: ToolId) => UTMParams; // Function to get merged params
  setGlobalUTMParams: (params: UTMParams) => void; // Function to set global defaults
}

const UTMContext = createContext<UTMContextType | undefined>(undefined);

export const UTMProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<UTMSettings>({
    global: {
      utm_source: 'ejen_ai_freelancer',
      utm_medium: '',
      utm_campaign: '',
      utm_term: '',
      utm_content: '',
    },
    // Demonstrate a hardcoded override for per-tool customization
    overrides: {
        [ToolId.AcademicResearch]: {
            utm_source: 'ai_google_research',
            utm_campaign: 'research_results',
        },
        [ToolId.ContentManagement]: {
            utm_medium: 'social',
        }
    },
  });

  useEffect(() => {
    try {
      const storedSettings = localStorage.getItem(UTM_SETTINGS_STORAGE_KEY);
      if (storedSettings) {
        const parsed = JSON.parse(storedSettings);
        // Merge stored with default to ensure all keys exist and new overrides are included
        setSettings(current => ({
            global: { ...current.global, ...parsed.global },
            overrides: { ...current.overrides, ...parsed.overrides }
        }));
      }
    } catch (error) {
      console.error("Failed to load UTM settings from localStorage:", error);
    }
  }, []);

  const setGlobalUTMParams = (params: UTMParams) => {
    setSettings(currentSettings => {
        const newSettings = { ...currentSettings, global: params };
        try {
            localStorage.setItem(UTM_SETTINGS_STORAGE_KEY, JSON.stringify(newSettings));
        } catch (error) {
            console.error("Failed to save UTM settings to localStorage:", error);
        }
        return newSettings;
    });
  };
  
  const getUTMParams = (toolId?: ToolId): UTMParams => {
      const globalParams = settings.global;
      const toolOverrides = toolId ? settings.overrides[toolId] : undefined;
      // Merges params, with tool-specific overrides taking precedence
      return { ...globalParams, ...toolOverrides };
  };

  return (
    <UTMContext.Provider value={{ getUTMParams, setGlobalUTMParams }}>
      {children}
    </UTMContext.Provider>
  );
};

export const useUTM = (): UTMContextType => {
  const context = useContext(UTMContext);
  if (context === undefined) {
    throw new Error('useUTM must be used within a UTMProvider');
  }
  return context;
};