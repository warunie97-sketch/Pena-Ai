import React from 'react';
import LoadingSpinner from './LoadingSpinner';
import WordCount from './WordCount';
import TranslationWidget from './TranslationWidget';
import MarkdownRenderer from './MarkdownRenderer';
import ReadAloudButton from './ReadAloudButton';

interface SummaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  summary: string;
  isLoading: boolean;
  onShareToSocials: (content: string) => void;
}

const SummaryModal: React.FC<SummaryModalProps> = ({ isOpen, onClose, summary, isLoading, onShareToSocials }) => {
  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(summary);
  };

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4"
      onClick={onClose}
      aria-modal="true"
      role="dialog"
    >
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-2xl" onClick={e => e.stopPropagation()}>
        <div className="p-6 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Ringkasan Dokumen</h2>
          <button onClick={onClose} className="text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white" aria-label="Tutup modal">&times;</button>
        </div>
        <div className="p-6 max-h-[70vh] overflow-y-auto">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center min-h-[200px]">
              <LoadingSpinner className="w-10 h-10" />
              <p className="mt-4 text-slate-500 dark:text-slate-400">Menjana ringkasan...</p>
            </div>
          ) : summary ? (
            <div>
                <MarkdownRenderer content={summary} />
                <div className="mt-4 flex justify-between items-center">
                    <WordCount text={summary} />
                    <div className="flex items-center gap-2">
                        <ReadAloudButton textToRead={summary} />
                        <button onClick={() => onShareToSocials(summary)} title="Hantar ke Pengurus Kandungan" className="text-sm bg-purple-600 hover:bg-purple-500 text-white font-medium py-1 px-3 rounded-md transition-all">Hantar</button>
                        <button onClick={handleCopy} className="text-sm bg-slate-200 dark:bg-slate-600 hover:bg-slate-300 dark:hover:bg-slate-500 text-slate-700 dark:text-white font-medium py-1 px-3 rounded-md transition-all">Salin</button>
                    </div>
                </div>
                <TranslationWidget textToTranslate={summary} />
            </div>
          ) : (
            <p className="text-slate-500 dark:text-slate-400 text-center">Tiada ringkasan dijana.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default SummaryModal;
