import React from 'react';

interface BookmarkPanelProps {
  bookmarks: number[];
  onJumpToPage: (page: number) => void;
  onDeleteBookmark: (page: number) => void;
}

const BookmarkPanel: React.FC<BookmarkPanelProps> = ({ bookmarks, onJumpToPage, onDeleteBookmark }) => {
  if (bookmarks.length === 0) {
    return (
      <div className="bg-slate-100 dark:bg-slate-800/50 rounded-lg p-4 text-center text-sm text-slate-500 dark:text-slate-500">
        Tiada penanda halaman lagi.
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-800/50 rounded-lg">
      <h3 className="text-lg font-semibold text-slate-900 dark:text-white p-4 border-b border-slate-200 dark:border-slate-700">
        Penanda Halaman
      </h3>
      <ul className="max-h-60 overflow-y-auto p-2">
        {bookmarks.map(page => (
          <li key={page} className="flex items-center justify-between group hover:bg-slate-100 dark:hover:bg-slate-700 rounded-md">
            <button
              onClick={() => onJumpToPage(page)}
              className="flex-grow text-left p-2 text-slate-700 dark:text-slate-300"
            >
              Muka Surat {page}
            </button>
            <button
              onClick={() => onDeleteBookmark(page)}
              className="p-2 text-slate-500 dark:text-slate-500 hover:text-red-500 dark:hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
              aria-label={`Padam penanda halaman untuk muka surat ${page}`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default BookmarkPanel;