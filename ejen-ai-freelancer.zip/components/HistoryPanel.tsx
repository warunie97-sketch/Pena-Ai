import React, { useState } from 'react';
import type { HistoryItem } from '../types';

interface HistoryPanelProps {
  history: HistoryItem[];
  onSelect: (item: string) => void;
  onClear: () => void;
}

function formatRelativeTime(timestamp: number): string {
    const now = Date.now();
    const seconds = Math.floor((now - timestamp) / 1000);
  
    let interval = seconds / 31536000;
    if (interval > 1) return new Date(timestamp).toLocaleDateString('ms-MY');
    interval = seconds / 2592000;
    if (interval > 1) return new Date(timestamp).toLocaleDateString('ms-MY');
    interval = seconds / 86400;
    if (interval > 1) return `${Math.floor(interval)} hari lalu`;
    interval = seconds / 3600;
    if (interval > 1) return `${Math.floor(interval)} jam lalu`;
    interval = seconds / 60;
    if (interval > 1) return `${Math.floor(interval)} minit lalu`;
    return `Sebentar tadi`;
}


const HistoryPanel: React.FC<HistoryPanelProps> = ({ history, onSelect, onClear }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
    
  if (history.length === 0) {
    return null;
  }

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => {
      setCopiedIndex(null);
    }, 2000); // Reset after 2 seconds
  };

  return (
    <div className="mt-6 space-y-3">
        <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-slate-800 dark:text-white">Sejarah Terkini</h3>
            <button
                onClick={onClear}
                className="text-xs text-red-500 dark:text-red-400 hover:text-red-600 dark:hover:text-red-300 hover:underline"
            >
                Padam Sejarah
            </button>
        </div>
        <ul className="space-y-2 max-h-56 overflow-y-auto rounded-lg bg-slate-100 dark:bg-slate-900/50 p-2">
            {history.map((item, index) => (
              <li key={index} className="flex items-center justify-between group rounded-md p-2 hover:bg-slate-200 dark:hover:bg-slate-700/50">
                <div className="flex-grow min-w-0">
                  <p className="text-sm text-slate-700 dark:text-slate-300 truncate" title={item.prompt}>{item.prompt}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{formatRelativeTime(item.timestamp)}</p>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0 pl-4">
                  <button
                    onClick={() => onSelect(item.prompt)}
                    className="text-xs bg-blue-600 hover:bg-blue-700 text-white font-semibold py-1 px-3 rounded-md transition-opacity opacity-0 group-hover:opacity-100"
                  >
                    Guna
                  </button>
                  <button
                    onClick={() => handleCopy(item.prompt, index)}
                    className="p-2 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white transition-opacity opacity-0 group-hover:opacity-100"
                    title="Salin"
                  >
                    {copiedIndex === index ? (
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="text-green-500 dark:text-green-400">
                          <polyline points="20 6 9 17 4 12"></polyline>
                      </svg>
                    ) : (
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                          <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                      </svg>
                    )}
                  </button>
                </div>
              </li>
            ))}
        </ul>
    </div>
  );
};

export default HistoryPanel;
