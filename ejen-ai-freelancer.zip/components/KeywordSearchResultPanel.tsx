import React from 'react';
import LoadingSpinner from './LoadingSpinner';

interface KeywordSearchResultPanelProps {
  isLoading: boolean;
  results: number[];
  error: string;
  onJumpToPage: (page: number) => void;
}

const KeywordSearchResultPanel: React.FC<KeywordSearchResultPanelProps> = ({ isLoading, results, error, onJumpToPage }) => {
  if (isLoading) {
    return (
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg p-6 flex flex-col items-center justify-center min-h-[150px]">
        <LoadingSpinner className="w-8 h-8 text-blue-500" />
        <p className="mt-4 text-slate-500 dark:text-slate-400">Mencari dalam dokumen...</p>
      </div>
    );
  }

  if (error) {
    return <p className="text-red-500 dark:text-red-400 text-center bg-red-100 dark:bg-red-900/20 p-3 rounded-md">{error}</p>;
  }
  
  return (
    <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg">
        <div className="p-4 border-b border-slate-200 dark:border-slate-700">
            <h3 className="text-xl font-semibold text-slate-900 dark:text-white">Hasil Carian Kata Kunci</h3>
            {results.length > 0 &&
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Ditemui di {results.length} muka surat.</p>
            }
        </div>
        {results.length > 0 ? (
            <div className="p-4 grid grid-cols-4 sm:grid-cols-6 md:grid-cols-10 gap-2 max-h-48 overflow-y-auto">
                {results.map(page => (
                <button
                    key={page}
                    onClick={() => onJumpToPage(page)}
                    className="bg-slate-200 dark:bg-slate-700 hover:bg-blue-600 text-slate-800 dark:text-white font-medium p-2 rounded-md text-sm transition-colors"
                    title={`Lompat ke muka surat ${page}`}
                >
                    MS {page}
                </button>
                ))}
            </div>
        ) : (
            <p className="p-6 text-slate-500 dark:text-slate-400">Kata kunci tidak ditemui dalam dokumen.</p>
        )}
    </div>
  );
};

export default KeywordSearchResultPanel;