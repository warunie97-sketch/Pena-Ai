import React from 'react';

interface WordCountProps {
  text: string;
}

const WordCount: React.FC<WordCountProps> = ({ text }) => {
  const words = text.trim().split(/\s+/).filter(Boolean).length;
  const characters = text.length;

  return (
    <div className="text-xs text-slate-400 flex justify-end gap-4 pr-1 flex-shrink-0">
      <span>{words} perkataan</span>
      <span>{characters} aksara</span>
    </div>
  );
};

export default WordCount;