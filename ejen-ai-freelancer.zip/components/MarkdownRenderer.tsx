import React from 'react';

interface MarkdownRendererProps {
  content: string;
}

const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  // Use a placeholder that is unlikely to appear in the content
  const CODE_BLOCK_PLACEHOLDER = '___CODE_BLOCK_PLACEHOLDER___';

  // 1. Isolate code blocks and store them
  const codeBlocks: string[] = [];
  let processedContent = content.replace(/```(?:\w+)?\n([\s\S]+?)\n```/g, (match, code) => {
    // Sanitize code content to prevent HTML injection inside <pre><code>
    const sanitizedCode = code.replace(/</g, '&lt;').replace(/>/g, '&gt;');
    codeBlocks.push(sanitizedCode);
    return CODE_BLOCK_PLACEHOLDER;
  });

  // 2. Sanitize the rest of the content to prevent HTML injection
  processedContent = processedContent
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

  // 3. Apply Markdown to HTML conversions
  processedContent = processedContent
    // Images
    .replace(/!\[(.*?)\]\((.*?)\)/g, '<img src="$2" alt="$1" class="rounded-md my-4 max-w-full h-auto" />')
    // Headings
    .replace(/^### (.*$)/gim, '<h3>$1</h3>')
    .replace(/^## (.*$)/gim, '<h2>$1</h2>')
    .replace(/^# (.*$)/gim, '<h1>$1</h1>')
    // Bold, Italic, Strikethrough, Inline Code
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/~~(.*?)~~/g, '<del>$1</del>')
    .replace(/`(.*?)`/g, '<code>$1</code>')
    // Links
    .replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>')
    // Lists (handle multiline lists)
    .replace(/^\s*[\-\*] (.*)/gm, '<li>$1</li>')
    .replace(/^\s*\d+\. (.*)/gm, '<li>$1</li>')
    // Wrap groups of <li> into <ul> or <ol>
    // This is a simplified approach; it assumes lists are not mixed
    .replace(/(<li>(?:.|\n)*?<\/li>)(?!\s*<li>)/g, (match) => {
        if (match.includes('<ol>')) return match; // Avoid double wrapping
        if (match.startsWith('<li>')) return `<ul>${match}</ul>`;
        return match;
    })
    // Paragraphs: Wrap lines that are not part of other elements in <p> tags
    .split('\n\n')
    .map(paragraph => {
      if (!paragraph.trim()) return '';
      // Avoid wrapping list structures or headings in <p> tags
      if (paragraph.trim().startsWith('<') || paragraph.trim().startsWith('<li>')) {
        return paragraph;
      }
      return `<p>${paragraph.replace(/\n/g, '<br />')}</p>`;
    })
    .join('');
    
  // 4. Split the HTML by the placeholder and re-insert code blocks
  const finalHtmlParts = processedContent.split(CODE_BLOCK_PLACEHOLDER);

  return (
    <div className="prose">
      {finalHtmlParts.map((part, index) => (
        <React.Fragment key={index}>
          <div dangerouslySetInnerHTML={{ __html: part }} />
          {codeBlocks[index] && (
            <pre><code>{codeBlocks[index]}</code></pre>
          )}
        </React.Fragment>
      ))}
    </div>
  );
};

export default MarkdownRenderer;