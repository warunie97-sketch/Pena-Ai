import React, { useState, useMemo, useRef, useEffect } from 'react';
import type { Project } from '../types';
import { downloadICSFile } from '../utils/icsHelper';

interface CalendarViewProps {
  projects: Project[];
}

const CalendarView: React.FC<CalendarViewProps> = ({ projects }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDay, setSelectedDay] = useState<{ day: number; projects: Project[] } | null>(null);
  const [popoverPosition, setPopoverPosition] = useState({ top: 0, left: 0 });
  const calendarRef = useRef<HTMLDivElement>(null);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 640);

  useEffect(() => {
    const checkSize = () => setIsMobile(window.innerWidth < 640);
    window.addEventListener('resize', checkSize);
    return () => window.removeEventListener('resize', checkSize);
  }, []);

  const deadlinesByDate = useMemo(() => {
    const map = new Map<string, Project[]>();
    projects.forEach(project => {
      if (project.deadline) {
        const dateKey = project.deadline; // YYYY-MM-DD
        if (!map.has(dateKey)) {
          map.set(dateKey, []);
        }
        map.get(dateKey)?.push(project);
      }
    });
    return map;
  }, [projects]);

  const changeMonth = (offset: number) => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      newDate.setMonth(prev.getMonth() + offset);
      return newDate;
    });
    setSelectedDay(null); // Close popover when changing month
  };

  const handleDayClick = (day: number, dayProjects: Project[], e: React.MouseEvent) => {
      if (dayProjects.length === 0) {
          setSelectedDay(null);
          return;
      };

      if (isMobile) {
          setSelectedDay({ day, projects: dayProjects });
          return;
      }

      const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
      const calendarRect = calendarRef.current?.getBoundingClientRect();

      if (calendarRect) {
        let top = rect.top - calendarRect.top + rect.height;
        let left = rect.left - calendarRect.left;
        
        // Prevent popover from going off-screen
        if (left + 256 > calendarRect.width) { // 256 is w-64
            left = rect.right - calendarRect.left - 256;
        }
        if (top + 210 > calendarRect.height) { // Approximate popover height + margin
            top = rect.top - calendarRect.top - 210;
        }

        setPopoverPosition({ top: Math.max(0, top), left: Math.max(0, left) });
      }
      setSelectedDay({ day, projects: dayProjects });
  };
  
  const renderCalendar = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();

    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    const days = [];
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="border-r border-b border-slate-300 dark:border-slate-700"></div>);
    }

    for (let day = 1; day <= daysInMonth; day++) {
      const dateKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const dayProjects = deadlinesByDate.get(dateKey) || [];
      const isToday = new Date().toDateString() === new Date(year, month, day).toDateString();

      days.push(
        <div 
            key={day} 
            className="border-r border-b border-slate-300 dark:border-slate-700 p-2 text-left relative min-h-[80px] sm:min-h-[100px] md:min-h-[120px] cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700/50 transition-colors"
            onClick={(e) => handleDayClick(day, dayProjects, e)}
        >
          <span className={`text-sm font-semibold ${isToday ? 'bg-blue-200 text-blue-800 dark:bg-blue-700 dark:text-white rounded-full w-6 h-6 flex items-center justify-center' : 'text-slate-700 dark:text-slate-300'}`}>{day}</span>
          {dayProjects.length > 0 && (
            <div className="mt-1 space-y-1">
              {dayProjects.slice(0, 1).map(p => (
                <div key={p.id} className="text-xs bg-blue-100 dark:bg-blue-900/70 text-blue-800 dark:text-blue-200 rounded px-1.5 py-0.5 truncate" title={p.name}>
                    {p.name}
                </div>
              ))}
              <div className="hidden sm:block">
                  {dayProjects.slice(1, 2).map(p => (
                    <div key={p.id} className="text-xs bg-blue-100 dark:bg-blue-900/70 text-blue-800 dark:text-blue-200 rounded px-1.5 py-0.5 truncate" title={p.name}>
                        {p.name}
                    </div>
                  ))}
              </div>
              {dayProjects.length > 1 && (
                  <div className="text-xs text-slate-500 dark:text-slate-400 sm:hidden">+ {dayProjects.length - 1} lagi</div>
              )}
               {dayProjects.length > 2 && (
                  <div className="hidden text-xs text-slate-500 dark:text-slate-400 sm:block">+ {dayProjects.length - 2} lagi</div>
              )}
            </div>
          )}
        </div>
      );
    }

    return days;
  };

  const weekdays = ['Ahad', 'Isnin', 'Selasa', 'Rabu', 'Khamis', 'Jumaat', 'Sabtu'];
  const weekdaysShort = ['Ahd', 'Isn', 'Sel', 'Rab', 'Kha', 'Jum', 'Sab'];

  return (
    <div className="bg-white dark:bg-slate-800 p-4 sm:p-6 rounded-lg shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <button onClick={() => changeMonth(-1)} className="p-2 bg-slate-200 dark:bg-slate-600 rounded-md hover:bg-slate-300 dark:hover:bg-slate-500 transition-all duration-200 hover:scale-105 active:scale-95">&lt;</button>
        <h3 className="text-xl font-bold text-slate-900 dark:text-white">
          {currentDate.toLocaleString('ms-MY', { month: 'long', year: 'numeric' })}
        </h3>
        <button onClick={() => changeMonth(1)} className="p-2 bg-slate-200 dark:bg-slate-600 rounded-md hover:bg-slate-300 dark:hover:bg-slate-500 transition-all duration-200 hover:scale-105 active:scale-95">&gt;</button>
      </div>

      <div ref={calendarRef} className="relative">
        <div className="grid grid-cols-7 text-center text-xs font-bold text-slate-500 dark:text-slate-400 border-t border-l border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50">
          {weekdays.map((day, index) => (
            <div key={day} className="py-2 border-r border-b border-slate-300 dark:border-slate-700">
                <span className="hidden sm:inline">{day}</span>
                <span className="sm:hidden">{weekdaysShort[index]}</span>
            </div>
          ))}
          {renderCalendar()}
        </div>

        {selectedDay && isMobile && (
            <div 
                className="fixed inset-0 bg-black bg-opacity-50 z-10 animate-fadeInUp"
                style={{ animationDuration: '0.2s' }}
                onClick={() => setSelectedDay(null)}
            />
        )}

        {selectedDay && (
             <div 
                className={isMobile 
                    ? "fixed bottom-0 left-0 right-0 w-full bg-white dark:bg-slate-900 rounded-t-lg shadow-2xl z-20 p-4 animate-fadeInUp"
                    : "absolute bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-lg shadow-2xl z-10 w-64 p-3 animate-fadeInUp"
                }
                style={isMobile ? { animationDuration: '0.3s' } : { top: popoverPosition.top, left: popoverPosition.left, animationDuration: '0.2s' }}
             >
                <div className="flex justify-between items-center mb-2">
                    <h4 className="font-bold text-slate-900 dark:text-white">Tarikh Akhir: {selectedDay.day}</h4>
                    <button onClick={() => setSelectedDay(null)} className="text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white">&times;</button>
                </div>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                    {selectedDay.projects.map(p => (
                        <div key={p.id} className="bg-slate-100 dark:bg-slate-800 p-2 rounded">
                           <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">{p.name}</p>
                           <p className="text-xs text-slate-500 dark:text-slate-400">{p.client}</p>
                           <button 
                                onClick={() => downloadICSFile(p)} 
                                className="text-xs text-blue-600 dark:text-blue-400 hover:underline mt-1"
                            >
                                Tambah ke Kalendar
                            </button>
                        </div>
                    ))}
                </div>
             </div>
        )}
      </div>
    </div>
  );
};

export default CalendarView;