import React, { useState, useEffect } from 'react';
import { useGemini } from '../contexts/GeminiContext';

const ApiKeyModal: React.FC = () => {
  const { setApiKey, isModalOpen, closeModal, apiKey, clearApiKey, requestsMade, requestLimit, error } = useGemini();
  const [key, setKey] = useState('');

  useEffect(() => {
    if (apiKey) {
      setKey(apiKey);
    } else {
      setKey('');
    }
  }, [apiKey, isModalOpen]);

  if (!isModalOpen) return null;

  const usagePercentage = Math.min((requestsMade / requestLimit) * 100, 100);
  let usageColor = 'bg-blue-600';
  let usageMessage = `Anda telah menggunakan ${requestsMade} daripada ${requestLimit} permintaan dalam sesi ini.`;

  if (usagePercentage >= 100) {
      usageColor = 'bg-red-600';
      usageMessage = `Anda telah mencapai had permintaan sesi anda (${requestLimit}). Sila mulakan semula sesi anda (tutup & buka semula tab) atau tukar kunci API.`;
  } else if (usagePercentage >= 80) {
      usageColor = 'bg-yellow-500';
      usageMessage = `Amaran: Anda hampir mencapai had permintaan sesi anda (${requestsMade}/${requestLimit}).`;
  }


  const handleSave = () => {
    // Context handles validation, error display, and closing the modal.
    setApiKey(key);
  };

  const handleClear = () => {
    clearApiKey();
    setKey('');
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-lg">
        <div className="p-6 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Urus Kunci API Gemini</h2>
          <button onClick={closeModal} className="text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white" aria-label="Tutup modal">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
          </button>
        </div>
        <div className="p-6 space-y-4 text-slate-600 dark:text-slate-300">
            <p>Untuk menggunakan Ejen AI Freelancer, anda memerlukan kunci API Google Gemini anda sendiri. Ini memastikan anda mempunyai kawalan penuh ke atas penggunaan AI anda di bawah pelan Gemini anda.</p>
            <p>Dapatkan kunci API anda secara percuma dari <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="text-blue-600 dark:text-blue-400 hover:underline font-semibold">Google AI Studio</a>.</p>
            <div>
              <label htmlFor="api-key-input" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Kunci API Gemini Anda</label>
              <input
                id="api-key-input"
                type="password"
                value={key}
                onChange={(e) => setKey(e.target.value)}
                className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                placeholder="Tampal kunci API anda di sini"
              />
            </div>
            {error && (
                <p className="text-red-500 dark:text-red-400 text-sm text-center bg-red-100 dark:bg-red-900/20 p-3 rounded-md">
                    {error}
                </p>
            )}
             {apiKey && !error && (
              <div className="space-y-2 pt-4 border-t border-slate-200 dark:border-slate-700">
                  <h3 className="text-sm font-medium text-slate-700 dark:text-slate-300">Penggunaan API Sesi Semasa</h3>
                  <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2.5">
                      <div 
                          className={`h-2.5 rounded-full transition-all duration-500 ${usageColor}`} 
                          style={{ width: `${usagePercentage}%` }}
                      ></div>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{usageMessage}</p>
              </div>
            )}
        </div>
        <div className="p-4 bg-slate-100 dark:bg-slate-900/50 flex justify-between items-center gap-3 rounded-b-lg">
          <button
            onClick={handleClear}
            disabled={!apiKey}
            className="bg-red-600 hover:bg-red-700 disabled:bg-slate-400 dark:disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-medium py-2 px-4 rounded-md transition-all"
          >
            Kosongkan Kunci
          </button>
          <button
            onClick={handleSave}
            disabled={!key.trim()}
            className="flex-1 flex items-center justify-center bg-blue-600 hover:bg-blue-700 disabled:bg-slate-500 disabled:cursor-not-allowed text-white font-bold py-2 px-4 rounded-md transition-all"
          >
            Simpan Kunci API
          </button>
        </div>
      </div>
    </div>
  );
};

export default ApiKeyModal;