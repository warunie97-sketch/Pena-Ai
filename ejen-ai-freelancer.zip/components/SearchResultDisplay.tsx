import React from 'react';
import type { SearchResult } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import TranslationWidget from './TranslationWidget';
import { useUTM } from '../contexts/UTMContext';
import { appendUTMParams } from '../utils/urlUtils';
import { ToolId } from '../types';
import MarkdownRenderer from './MarkdownRenderer';

interface SearchResultDisplayProps {
    isLoading: boolean;
    result: SearchResult | null;
    error: string;
    toolName: string;
    onShareToSocials: (content: string) => void;
}

const SearchResultDisplay: React.FC<SearchResultDisplayProps> = ({ isLoading, result, error, toolName, onShareToSocials }) => {
    const { getUTMParams } = useUTM();

    const handleCopy = () => {
        if (result) {
            navigator.clipboard.writeText(result.text);
        }
    };

    const handleShare = async () => {
        if (!result) return;
        try {
            if (navigator.share) {
                await navigator.share({
                    title: `Hasil Carian untuk ${toolName}`,
                    text: result.text,
                });
            } else {
                await navigator.clipboard.writeText(result.text);
                alert('Hasil carian disalin ke papan keratan!');
            }
        } catch (error) {
             if (error instanceof Error && !error.message.includes('Abort')) {
                console.error('Error sharing:', error);
            }
        }
    };


    const handleExport = (format: 'txt' | 'md') => {
        if (!result) return;

        let content = result.text;
        if (result.sources && result.sources.length > 0) {
            content += '\n\n---\n\nRujukan\n\n';
            result.sources.forEach((source, index) => {
                const title = source.web.title || source.web.uri;
                const uri = source.web.uri;
                if (format === 'md') {
                    content += `${index + 1}. [${title}](${uri})\n`;
                } else {
                    content += `[${index + 1}] ${title} (${uri})\n`;
                }
            });
        }

        const formattedToolName = toolName.replace(/\s+/g, '_');
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const fileName = `${formattedToolName}_${timestamp}.${format}`;

        const mimeType = format === 'md' ? 'text/markdown' : 'text/plain';
        const blob = new Blob([content], { type: `${mimeType};charset=utf-8` });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(link.href);
    };

    if (isLoading) {
        return (
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg p-6 flex flex-col items-center justify-center min-h-[200px]">
                <LoadingSpinner className="w-10 h-10 text-blue-500" />
                <p className="mt-4 text-slate-500 dark:text-slate-400">Mencari dan menyusun hasil...</p>
            </div>
        );
    }

    if (error) {
        return <p className="text-red-500 dark:text-red-400 text-center bg-red-100 dark:bg-red-900/20 p-3 rounded-md">{error}</p>;
    }

    if (!result) {
        return null; // Render nothing if there's no result, no loading, and no error
    }

    return (
        <>
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg">
                <div className="flex justify-between items-center p-4 border-b border-slate-200 dark:border-slate-700 flex-wrap gap-2">
                    <h3 className="text-xl font-semibold text-slate-900 dark:text-white">Jawapan</h3>
                    <div className="flex items-center gap-2">
                        <button onClick={() => onShareToSocials(result.text)} title="Hantar ke Pengurus Kandungan" className="text-sm bg-purple-600 hover:bg-purple-500 text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95 flex items-center gap-1.5">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="18" height="18" x="3" y="4" rx="2" ry="2" /><line x1="16" x2="16" y1="2" y2="6" /><line x1="8" x2="8" y1="2" y2="6" /><line x1="3" x2="21" y1="10" y2="10" /></svg>
                            Hantar ke Pengurus
                        </button>
                         <button onClick={handleShare} title="Kongsi" className="p-2 text-sm bg-cyan-600 hover:bg-cyan-500 text-white font-medium rounded-md transition-all duration-200 hover:scale-105 active:scale-95">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" x2="12" y1="2" y2="15"/></svg>
                        </button>
                        <button onClick={handleCopy} className="text-sm bg-slate-200 hover:bg-slate-300 text-slate-700 dark:bg-slate-600 dark:hover:bg-slate-500 dark:text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">Salin Teks</button>
                        <button onClick={() => handleExport('txt')} className="text-sm bg-green-600 hover:bg-green-500 text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">Eksport .txt</button>
                        <button onClick={() => handleExport('md')} className="text-sm bg-green-600 hover:bg-green-500 text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">Eksport .md</button>
                    </div>
                </div>
                <div className="p-6">
                    <MarkdownRenderer content={result.text} />
                    <TranslationWidget textToTranslate={result.text} />
                </div>
            </div>

            {result.sources.length > 0 && (
                <div className="mt-6 bg-white dark:bg-slate-800 rounded-lg shadow-lg">
                    <div className="p-4 border-b border-slate-200 dark:border-slate-700">
                        <h3 className="text-xl font-semibold text-slate-900 dark:text-white">Rujukan</h3>
                    </div>
                    <ul className="p-6 space-y-3">
                        {result.sources.map((source, index) => {
                             const utmParams = getUTMParams(ToolId.AcademicResearch);
                             let content = 'unknown_source';
                             try {
                                content = new URL(source.web.uri).hostname.replace(/\./g, '_');
                             } catch {}
                             const finalUri = appendUTMParams(source.web.uri, utmParams, `source_${index + 1}_${content}`);

                            return (
                                <li key={index} className="text-sm text-slate-600 dark:text-slate-300">
                                    [{index + 1}] {source.web.title || 'Judul tidak tersedia'}. (t.t.). Diperoleh daripada <a href={finalUri} target="_blank" rel="noopener noreferrer" className="text-blue-600 dark:text-blue-400 hover:underline break-all" title={source.web.uri}>{source.web.uri}</a>
                                </li>
                            );
                        })}
                    </ul>
                </div>
            )}
        </>
    );
};

export default SearchResultDisplay;