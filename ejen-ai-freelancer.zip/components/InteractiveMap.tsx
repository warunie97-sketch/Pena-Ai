import React from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import type { LatLngExpression } from 'leaflet';
import type { MapGroundingSource } from '../services/geminiService';

interface InteractiveMapProps {
    center: { lat: number; lng: number };
    locations: MapGroundingSource[];
}

// A helper component to update map bounds when locations change
const MapBoundsUpdater: React.FC<{ bounds: LatLngExpression[] }> = ({ bounds }) => {
    const map = useMap();
    if (bounds.length > 0) {
        map.fitBounds(bounds, { padding: [50, 50] });
    }
    return null;
}

const InteractiveMap: React.FC<InteractiveMapProps> = ({ center, locations }) => {
    const validLocations = locations.filter(loc => loc.latLng);

    if (validLocations.length === 0) {
        return (
            <div className="bg-slate-100 dark:bg-slate-800/50 p-4 rounded-lg text-center text-slate-500 dark:text-slate-400">
                Tiada data lokasi ditemui untuk dipaparkan pada peta.
            </div>
        );
    }
    
    // Calculate bounds to fit all markers
    const bounds: LatLngExpression[] = validLocations.map(loc => [loc.latLng!.latitude, loc.latLng!.longitude]);
    // Also include user's center point
    bounds.push([center.lat, center.lng]);

    return (
        <MapContainer center={[center.lat, center.lng]} zoom={13} scrollWheelZoom={true} className="leaflet-container">
            <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <MapBoundsUpdater bounds={bounds} />

            {/* User Location Marker */}
            <Marker position={[center.lat, center.lng]}>
                <Popup>Lokasi Anda</Popup>
            </Marker>

            {/* Location Markers */}
            {validLocations.map((loc, index) => (
                <Marker key={index} position={[loc.latLng!.latitude, loc.latLng!.longitude]}>
                    <Popup>
                        <strong>{loc.title}</strong>
                        <br />
                        <a href={loc.uri} target="_blank" rel="noopener noreferrer" className="text-blue-600 dark:text-blue-400 hover:underline">
                            Lihat di Peta Google
                        </a>
                    </Popup>
                </Marker>
            ))}
        </MapContainer>
    );
};

export default InteractiveMap;
