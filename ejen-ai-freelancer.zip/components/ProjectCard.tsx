import React from 'react';
import type { Project, ProjectStatus, ProjectPriority } from '../types';
import { downloadICSFile } from '../utils/icsHelper';

interface ProjectCardProps {
  project: Project;
  onEdit: () => void;
  onDelete: () => void;
}

const statusStyles: Record<ProjectStatus, string> = {
  'Belum Mula': 'bg-slate-500 dark:bg-slate-600 text-white dark:text-slate-200',
  'Dalam Proses': 'bg-blue-600 text-white',
  'Selesai': 'bg-green-600 text-white',
  'Ditangguhkan': 'bg-yellow-500 dark:bg-yellow-600 text-white',
};

const priorityStyles: Record<ProjectPriority, { dot: string }> = {
  'Rendah': { dot: 'bg-gray-400' },
  'Sederhana': { dot: 'bg-blue-400' },
  'Tinggi': { dot: 'bg-red-400' },
};

const ProjectCard: React.FC<ProjectCardProps> = ({ project, onEdit, onDelete }) => {
  const currentPriority = project.priority || 'Sederhana';
  const priorityStyle = priorityStyles[currentPriority] || priorityStyles['Sederhana'];

  return (
    <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg flex flex-col transition-all duration-200 ease-in-out transform hover:-translate-y-1 hover:shadow-blue-500/20">
      <div className="p-5 flex-grow">
        <div className="flex justify-between items-start mb-2">
            <div className="flex items-center gap-2 flex-1 min-w-0">
                <span className={`w-3 h-3 rounded-full flex-shrink-0 ${priorityStyle.dot}`} title={`Keutamaan: ${currentPriority}`}></span>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white truncate" title={project.name}>{project.name}</h3>
            </div>
            <span className={`text-xs font-semibold px-2.5 py-1 rounded-full flex-shrink-0 ml-2 ${statusStyles[project.status]}`}>
                {project.status}
            </span>
        </div>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-1">
          <strong>Klien:</strong> {project.client || 'N/A'}
        </p>
         <div className="grid grid-cols-2 gap-x-4 mb-2">
            <p className="text-sm text-slate-500 dark:text-slate-400 truncate">
              <strong>Tarikh Akhir:</strong> {project.deadline ? new Date(project.deadline.replace(/-/g, '/')).toLocaleDateString() : 'N/A'}
            </p>
            <p className="text-sm text-slate-500 dark:text-slate-400 truncate">
              <strong>Anggaran:</strong> {project.estimatedHours > 0 ? `${project.estimatedHours} jam` : 'N/A'}
            </p>
        </div>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-4 truncate">
          <strong>Penerima Tugas:</strong> {project.assignee || 'Tiada'}
        </p>
        <div className="bg-slate-100 dark:bg-slate-900/50 p-3 rounded-md max-h-24 overflow-y-auto">
          <p className="text-sm text-slate-700 dark:text-slate-300 whitespace-pre-wrap">{project.notes || 'Tiada nota.'}</p>
        </div>
      </div>
      <div className="bg-slate-50 dark:bg-slate-900/70 p-3 flex justify-end gap-3 rounded-b-lg">
        {project.deadline && (
             <button
              onClick={() => downloadICSFile(project)}
              className="text-sm bg-sky-600 hover:bg-sky-500 text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
              title="Tambah tarikh akhir ke kalendar anda"
            >
              Tambah ke Kalendar
            </button>
        )}
        <button
          onClick={onEdit}
          className="text-sm bg-slate-200 hover:bg-slate-300 text-slate-700 dark:bg-slate-600 dark:hover:bg-slate-500 dark:text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
        >
          Sunting
        </button>
        <button
          onClick={onDelete}
          className="text-sm bg-red-600 hover:bg-red-500 text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
        >
          Padam
        </button>
      </div>
    </div>
  );
};

export default ProjectCard;