import React from 'react';
import type { SearchResultWithMaps } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import TranslationWidget from './TranslationWidget';
import MarkdownRenderer from './MarkdownRenderer';

interface MapResultDisplayProps {
    isLoading: boolean;
    result: SearchResultWithMaps | null;
    error: string;
    toolName: string;
    onShareToSocials: (content: string) => void;
}

const MapResultDisplay: React.FC<MapResultDisplayProps> = ({ isLoading, result, error, toolName, onShareToSocials }) => {
    
    if (isLoading) {
        return (
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg p-6 flex flex-col items-center justify-center min-h-[200px]">
                <LoadingSpinner className="w-10 h-10 text-blue-500" />
                <p className="mt-4 text-slate-500 dark:text-slate-400">Mencari tempat berdekatan...</p>
            </div>
        );
    }

    if (error) {
        return <p className="text-red-500 dark:text-red-400 text-center bg-red-100 dark:bg-red-900/20 p-3 rounded-md">{error}</p>;
    }

    if (!result) {
        return null;
    }

    const mapSources = result.sources.filter(s => s.maps);

    return (
        <>
            <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg">
                <div className="p-4 border-b border-slate-200 dark:border-slate-700">
                    <h3 className="text-xl font-semibold text-slate-900 dark:text-white">Cadangan</h3>
                </div>
                <div className="p-6">
                    <MarkdownRenderer content={result.text} />
                    <TranslationWidget textToTranslate={result.text} />
                </div>
            </div>

            {mapSources.length > 0 && (
                <div className="mt-6 bg-white dark:bg-slate-800 rounded-lg shadow-lg">
                    <div className="p-4 border-b border-slate-200 dark:border-slate-700">
                        <h3 className="text-xl font-semibold text-slate-900 dark:text-white">Tempat yang Disebutkan</h3>
                    </div>
                    <ul className="p-6 space-y-3">
                        {mapSources.map((source, index) => (
                           <li key={index} className="text-sm text-slate-600 dark:text-slate-300">
                               <a href={source.maps!.uri} target="_blank" rel="noopener noreferrer" className="text-blue-600 dark:text-blue-400 hover:underline font-semibold break-all" title={source.maps!.title}>{source.maps!.title}</a>
                           </li>
                        ))}
                    </ul>
                </div>
            )}
        </>
    );
};

export default MapResultDisplay;
