import React from 'react';
import { TOOLS, TOOL_SHORTCUT_STRINGS } from '../constants';
import type { Tool } from '../types';
import { ToolId } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

const IconWrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className="h-5 w-5 mr-3"
  >
    {children}
  </svg>
);

interface SidebarProps {
  activeTool: ToolId | null;
  setActiveTool: (toolId: ToolId | null) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTool, setActiveTool }) => {
  const { t } = useLanguage();

  const myBlogTool = TOOLS.find(tool => tool.id === ToolId.MyBlog);
  const mainTools = TOOLS.filter(tool => tool.categoryKey === 'sidebar.main');

  const groupedTools = TOOLS.reduce((acc, tool) => {
    if (tool.id === ToolId.MyBlog || tool.categoryKey === 'sidebar.main') return acc;
    (acc[tool.categoryKey] = acc[tool.categoryKey] || []).push(tool);
    return acc;
  }, {} as Record<string, Tool[]>);

  const categoryOrder = ['toolCategories.writing', 'toolCategories.marketing', 'toolCategories.media', 'toolCategories.utilities'];

  return (
    <nav className="flex-shrink-0 w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-700 flex flex-col h-full">
      <div className="p-4 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white tracking-wider">{t('sidebar.title')}</h2>
        <button 
            onClick={() => setActiveTool(null)} 
            className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700/50" 
            title="Kembali ke Laman Utama"
        >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-600 dark:text-slate-300"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
        </button>
      </div>
      <div className="flex-1 overflow-y-auto">
        <div className="p-2">
           {mainTools.length > 0 && (
            <div className="my-2">
              <h3 className="px-3 pt-2 pb-1 text-xs font-bold uppercase text-slate-500 dark:text-slate-500 tracking-wider">
                {t('sidebar.main')}
              </h3>
              <ul>
                {mainTools.map((tool) => (
                  <li key={tool.id}>
                    <button
                      onClick={() => setActiveTool(tool.id)}
                      className={`w-full text-left flex items-center p-3 my-1 rounded-md transition-all duration-200 transform hover:scale-[1.02] active:scale-[1] ${
                        activeTool === tool.id
                          ? 'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100'
                          : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 hover:text-slate-900 dark:hover:text-white'
                      }`}
                      title={`${t(tool.nameKey)}${TOOL_SHORTCUT_STRINGS[tool.id] ? ` (${TOOL_SHORTCUT_STRINGS[tool.id]})` : ''}`}
                    >
                      {tool.icon}
                      <span className="font-medium">{t(tool.nameKey)}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
           )}

           <ul>
              {myBlogTool && (
                <li>
                  <button
                    onClick={() => setActiveTool(myBlogTool.id)}
                    className={`w-full text-left flex items-center p-3 my-1 rounded-md transition-all duration-200 transform hover:scale-[1.02] active:scale-[1] ${
                      activeTool === myBlogTool.id
                        ? 'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100'
                        : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 hover:text-slate-900 dark:hover:text-white'
                    }`}
                    title={`${t(myBlogTool.nameKey)}${TOOL_SHORTCUT_STRINGS[myBlogTool.id] ? ` (${TOOL_SHORTCUT_STRINGS[myBlogTool.id]})` : ''}`}
                  >
                    {myBlogTool.icon}
                    <span className="font-medium">{t(myBlogTool.nameKey)}</span>
                  </button>
                </li>
              )}
            </ul>

          {categoryOrder.map(categoryKey => (
            groupedTools[categoryKey] && (
                <div key={categoryKey} className="my-2">
                <h3 className="px-3 pt-2 pb-1 text-xs font-bold uppercase text-slate-500 dark:text-slate-500 tracking-wider">
                    {t(categoryKey)}
                </h3>
                <ul>
                    {groupedTools[categoryKey]?.map((tool) => (
                    <li key={tool.id}>
                        <button
                        onClick={() => setActiveTool(tool.id)}
                        className={`w-full text-left flex items-center p-3 my-1 rounded-md transition-all duration-200 transform hover:scale-[1.02] active:scale-[1] ${
                            activeTool === tool.id
                            ? 'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100'
                            : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50 hover:text-slate-900 dark:hover:text-white'
                        }`}
                        title={`${t(tool.nameKey)}${TOOL_SHORTCUT_STRINGS[tool.id] ? ` (${TOOL_SHORTCUT_STRINGS[tool.id]})` : ''}`}
                        >
                        {tool.icon}
                        <span className="font-medium">{t(tool.nameKey)}</span>
                        </button>
                    </li>
                    ))}
                </ul>
                </div>
            )
          ))}
        </div>
      </div>
    </nav>
  );
};

export default Sidebar;