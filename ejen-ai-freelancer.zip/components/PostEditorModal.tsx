import React, { useState, useEffect, useCallback, useRef } from 'react';
// FIX: Import PostCategory to use it for state and props.
import type { Post, PostCategory } from '../types';
import MarkdownToolbar from './MarkdownToolbar';

interface PostEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  // FIX: Update onSave to include an optional category to support both BlogView and FeedView.
  onSave: (postData: { title: string; content: string; category?: PostCategory }, postId?: string) => void;
  post: Post | null;
  // FIX: Add optional prop to control visibility of the category selector.
  showCategorySelector?: boolean;
}

const PostEditorModal: React.FC<PostEditorModalProps> = ({ isOpen, onClose, onSave, post, showCategorySelector = false }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  // FIX: Add state for category.
  const [category, setCategory] = useState<PostCategory>('Puisi');
  const contentTextareaRef = useRef<HTMLTextAreaElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (post) {
        setTitle(post.title);
        setContent(post.content);
        // FIX: Set category from existing post or default.
        setCategory(post.category || 'Puisi');
    } else {
        setTitle('');
        setContent('');
        // FIX: Reset category for a new post.
        setCategory('Puisi');
    }
  }, [post, isOpen]);


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;
    // The parent component is responsible for handling the save logic
    // and closing the modal. The useEffect hook will reset the form
    // when the modal is reopened for a new post.
    onSave({ title, content, category }, post?.id);
  };

  const handleClose = useCallback((e: React.MouseEvent | React.KeyboardEvent) => {
      if ('target' in e && 'currentTarget' in e && e.target === e.currentTarget) {
          onClose();
      }
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') {
            onClose();
        }
    };
    if (isOpen) {
        document.addEventListener('keydown', handleKeyDown);
    }
    return () => {
        document.removeEventListener('keydown', handleKeyDown);
    }
  }, [isOpen, onClose]);

  const handleEmbedImage = () => {
    imageInputRef.current?.click();
  };

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file || !contentTextareaRef.current) return;

      const reader = new FileReader();
      reader.onload = (event) => {
          const dataUrl = event.target?.result as string;
          const { selectionStart, value } = contentTextareaRef.current!;
          const imageMarkdown = `\n![${file.name}](${dataUrl})\n`;
          const newContent = `${value.substring(0, selectionStart)}${imageMarkdown}${value.substring(selectionStart)}`;
          setContent(newContent);
      };
      reader.readAsDataURL(file);

      // Reset file input
      e.target.value = '';
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4"
      onClick={handleClose}
      aria-modal="true"
      role="dialog"
    >
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-2xl" onClick={e => e.stopPropagation()}>
        <form onSubmit={handleSubmit}>
          <div className="p-6 border-b border-slate-200 dark:border-slate-700">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">{post ? 'Sunting Catatan' : 'Tulis Catatan Baru'}</h2>
          </div>
          <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
            <div>
              <label htmlFor="post-title" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Tajuk</label>
              <input 
                id="post-title" 
                type="text" 
                value={title} 
                onChange={(e) => setTitle(e.target.value)} 
                required 
                className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500" 
                placeholder="Tajuk yang menarik..."
              />
            </div>
            {/* FIX: Conditionally render the category selector. */}
            {showCategorySelector && (
              <div>
                <label htmlFor="post-category" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Kategori</label>
                <select 
                  id="post-category" 
                  value={category} 
                  onChange={(e) => setCategory(e.target.value as PostCategory)} 
                  className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Puisi">Puisi</option>
                  <option value="Cerpen">Cerpen</option>
                  <option value="Esei">Esei</option>
                  <option value="Novel">Novel</option>
                </select>
              </div>
            )}
            <div>
              <label htmlFor="post-content" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Kandungan Catatan Anda</label>
              <div className="bg-slate-100 dark:bg-slate-700 rounded-md border border-slate-300 dark:border-slate-600 focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-blue-500 transition-all">
                <div className="flex items-center gap-1 border-b border-slate-300 dark:border-slate-600 p-2">
                    <MarkdownToolbar textareaRef={contentTextareaRef} onValueChange={setContent} />
                    <div className="h-6 border-l border-slate-300 dark:border-slate-600 mx-1"></div>
                    <input type="file" accept="image/*" ref={imageInputRef} onChange={handleImageFileChange} className="hidden" />
                    <button type="button" onClick={handleEmbedImage} title="Embed Image" className="p-2 rounded-md text-slate-500 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600 hover:text-slate-800 dark:hover:text-white transition-colors">
                       <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                    </button>
                </div>
                <textarea 
                  ref={contentTextareaRef}
                  id="post-content" 
                  rows={12} 
                  value={content} 
                  onChange={(e) => setContent(e.target.value)} 
                  required 
                  className="w-full bg-transparent p-3 text-slate-900 dark:text-white placeholder-slate-500 dark:placeholder-slate-400 focus:outline-none resize-y"
                  placeholder="Tulis sesuatu yang hebat..."
                ></textarea>
              </div>
            </div>
          </div>
          <div className="p-4 bg-slate-100 dark:bg-slate-900/50 flex justify-end gap-3 rounded-b-lg">
            <button type="button" onClick={onClose} className="bg-slate-200 hover:bg-slate-300 text-slate-800 dark:bg-slate-600 dark:hover:bg-slate-500 dark:text-white font-medium py-2 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">Batal</button>
            <button type="submit" disabled={!title.trim() || !content.trim()} className="bg-blue-600 hover:bg-blue-700 disabled:bg-slate-500 disabled:cursor-not-allowed text-white font-bold py-2 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">{post ? 'Simpan Perubahan' : 'Terbitkan Catatan'}</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PostEditorModal;