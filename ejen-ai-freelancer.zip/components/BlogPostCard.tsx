import React from 'react';
import type { Post } from '../types';
import MarkdownRenderer from './MarkdownRenderer';

interface BlogPostCardProps {
  post: Post;
  onEdit: () => void;
  onDelete: () => void;
}

const BlogPostCard: React.FC<BlogPostCardProps> = ({ post, onEdit, onDelete }) => {
  const formattedDate = new Date(post.timestamp).toLocaleDateString('ms-MY', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  return (
    <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg flex flex-col transition-all duration-200 ease-in-out transform hover:-translate-y-1 hover:shadow-blue-500/20">
      <div className="p-6 flex-grow">
        <div className="flex justify-between items-start mb-2">
            <h3 className="text-2xl font-bold text-slate-900 dark:text-white">{post.title}</h3>
            <span className="text-xs text-slate-500 dark:text-slate-400 flex-shrink-0 ml-4">
                {formattedDate}
            </span>
        </div>
        <div className="max-h-96 overflow-y-auto">
            <MarkdownRenderer content={post.content} />
        </div>
      </div>
      <div className="bg-slate-50 dark:bg-slate-900/70 p-3 flex justify-end gap-3 rounded-b-lg">
          <button
          onClick={onEdit}
          className="text-sm bg-slate-200 hover:bg-slate-300 text-slate-700 dark:bg-slate-600 dark:hover:bg-slate-500 dark:text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
          >
          Sunting
          </button>
          <button
          onClick={onDelete}
          className="text-sm bg-red-600 hover:bg-red-500 text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
          >
          Padam
          </button>
      </div>
    </div>
  );
};

export default BlogPostCard;