import React from 'react';
import { TOOLS } from '../constants';
import { ToolId } from '../types';
import { useGemini } from '../contexts/GeminiContext';
import { useAuth } from '../contexts/AuthContext';
import { useUTM } from '../contexts/UTMContext';
import { appendUTMParams } from '../utils/urlUtils';
import { useTheme } from '../contexts/ThemeContext';
import { useLanguage } from '../contexts/LanguageContext';
import LanguageSelector from './LanguageSelector';

interface HeaderProps {
  activeTool: ToolId | null;
}

const Header: React.FC<HeaderProps> = ({ activeTool }) => {
  const { openModal, clearApiKey } = useGemini();
  const { logout } = useAuth();
  const { getUTMParams } = useUTM();
  const { theme, toggleTheme } = useTheme();
  const { t } = useLanguage();

  const handleShareApp = async () => {
    const tool = TOOLS.find(t => t.id === activeTool);
    const shareText = tool && activeTool !== null
      ? t('header.shareToolText', { toolName: t(tool.nameKey), toolDescription: t(tool.descriptionKey).toLowerCase() })
      : t('header.shareText');
      
    let shareableUrl: string | undefined;

    // Cuba dapatkan URL yang sah, utamakan origin.
    if (window.location.origin && window.location.origin !== 'null') {
      try {
        new URL(window.location.origin);
        shareableUrl = window.location.origin;
      } catch (e) {
        // origin bukan URL yang sah
      }
    }
    
    // Jika origin gagal, cuba href.
    if (!shareableUrl) {
      try {
        new URL(window.location.href);
        shareableUrl = window.location.href;
      } catch (e) {
        // href bukan URL yang sah
        console.warn("Tidak dapat menentukan URL yang boleh dikongsi.");
      }
    }

    // Sediakan data kongsi, hanya masukkan URL jika ia sah.
    const shareData: { title: string; text: string; url?: string } = {
      title: t('header.title'),
      text: shareText,
    };

    if (shareableUrl) {
      const utmParams = getUTMParams(); // Get global/default params
      const finalParams = {
          ...utmParams,
          utm_campaign: utmParams.utm_campaign || 'app_sharing'
      };
      // Use the new dynamicContent parameter to specify the context
      shareData.url = appendUTMParams(shareableUrl, finalParams, 'header_share_button');
    }

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        const clipboardText = shareData.url
          ? `${shareData.text}\n\n${shareData.url}`
          : shareData.text;
        await navigator.clipboard.writeText(clipboardText);
        alert(t('common.shareLinkCopied'));
      }
    } catch (error) {
      if (error instanceof Error && !error.message.includes('Abort')) {
         console.error('Error sharing:', error);
         alert(t('common.shareFailed'));
      }
    }
  };

  const handleLogout = () => {
    clearApiKey();
    logout();
  };


  return (
    <header className="flex-shrink-0 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 px-4 sm:px-6 md:px-8 h-16 flex items-center justify-between">
      <h1 className="text-xl font-bold text-slate-900 dark:text-white">{t('header.title')}</h1>
      <div className="flex items-center gap-2 md:gap-4">
        {activeTool !== null && (
          <button 
            onClick={handleShareApp}
            className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-700 dark:hover:bg-slate-600 dark:text-white font-medium py-2 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95"
            title={t('header.shareApp')}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" x2="12" y1="2" y2="15"/></svg>
            <span className="hidden sm:inline">{t('common.share')}</span>
          </button>
        )}
        
        <div className="h-8 border-l border-slate-200 dark:border-slate-700"></div>

        <LanguageSelector />

        <button
          onClick={toggleTheme}
          className="flex items-center justify-center h-10 w-10 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white rounded-full transition-colors duration-200 hover:bg-slate-200 dark:hover:bg-slate-700"
          title={t('header.toggleTheme')}
        >
          {theme === 'light' ? (
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>
          ) : (
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>
          )}
        </button>

        <div className="h-8 border-l border-slate-200 dark:border-slate-700"></div>

        <button onClick={openModal} className="flex items-center gap-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white font-medium py-2 px-4 rounded-md transition-all duration-200 hover:bg-slate-100 dark:hover:bg-slate-700" title={t('header.manageApiKey')}>
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 18v3c0 .6.4 1 1 1h4v-3h3v-3h2l1.4-1.4a6.5 6.5 0 1 0-4-4Z"/><circle cx="16.5" cy="7.5" r=".5"/></svg>
          <span className="hidden md:inline">{t('header.manageApiKey')}</span>
        </button>

        <div className="h-8 border-l border-slate-200 dark:border-slate-700"></div>
        
        <button onClick={handleLogout} className="text-sm text-slate-500 dark:text-slate-400 hover:text-red-500 dark:hover:text-red-400 hover:underline">
            {t('header.clearAndLogout')}
        </button>
      </div>
    </header>
  );
};

export default Header;