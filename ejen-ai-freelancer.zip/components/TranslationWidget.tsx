import React, { useState, useCallback } from 'react';
import { translateText } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import { useGemini } from '../contexts/GeminiContext';

interface TranslationWidgetProps {
  textToTranslate: string;
}

const LANGUAGES = [
  'English', 'Spanish', 'French', 'German', 'Chinese (Simplified)',
  'Japanese', 'Russian', 'Arabic', 'Portuguese', 'Hindi', 'Italian',
  'Korean', 'Bahasa Melayu', 'Bahasa Malaysia'
];

const TranslationWidget: React.FC<TranslationWidgetProps> = ({ textToTranslate }) => {
  const { aiInstance } = useGemini();
  const [translatedText, setTranslatedText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [targetLanguage, setTargetLanguage] = useState('');

  const handleTranslate = useCallback(async (language: string) => {
    if (!aiInstance) {
      setError("Sila tetapkan Kunci API anda untuk menggunakan terjemahan.");
      return;
    }
    if (!language || !textToTranslate) {
      setTargetLanguage(language);
      setTranslatedText('');
      setError('');
      return;
    }
    setTargetLanguage(language);
    setIsLoading(true);
    setError('');
    setTranslatedText('');
    try {
      const result = await translateText(aiInstance, textToTranslate, language);
      setTranslatedText(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [textToTranslate, aiInstance]);

  const handleCopy = () => {
    navigator.clipboard.writeText(translatedText);
  };

  return (
    <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700">
      <div className="flex items-center gap-4">
        <label htmlFor="language-select" className="text-sm font-medium text-slate-700 dark:text-slate-300">
          Terjemah ke:
        </label>
        <select
          id="language-select"
          onChange={(e) => handleTranslate(e.target.value)}
          value={targetLanguage}
          className="bg-slate-200 dark:bg-slate-600 border border-slate-300 dark:border-slate-500 rounded-md py-1 px-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition disabled:opacity-50"
          aria-label="Select language for translation"
          disabled={!aiInstance}
        >
          <option value="">Pilih bahasa...</option>
          {LANGUAGES.map(lang => (
            <option key={lang} value={lang}>{lang}</option>
          ))}
        </select>
      </div>
      
      {isLoading && (
        <div className="mt-4 flex items-center justify-center p-4 bg-slate-100 dark:bg-slate-900/50 rounded-md">
          <LoadingSpinner />
          <p className="ml-3 text-slate-500 dark:text-slate-400">Menterjemah...</p>
        </div>
      )}
      
      {error && <p className="mt-4 text-red-500 dark:text-red-400 text-center">{error}</p>}
      
      {translatedText && !isLoading && (
        <div className="mt-4 bg-slate-100 dark:bg-slate-900/50 rounded-lg shadow-inner">
           <div className="flex justify-between items-center p-3 border-b border-slate-200 dark:border-slate-700/50">
             <h4 className="text-md font-semibold text-slate-800 dark:text-white">Terjemahan ({targetLanguage})</h4>
             <button onClick={handleCopy} className="text-xs bg-slate-200 dark:bg-slate-600 hover:bg-slate-300 dark:hover:bg-slate-500 text-slate-800 dark:text-white font-medium py-1 px-3 rounded-md transition">Salin</button>
           </div>
           <div className="p-4 whitespace-pre-wrap text-slate-700 dark:text-slate-300">
             {translatedText}
           </div>
         </div>
      )}
    </div>
  );
};

export default TranslationWidget;