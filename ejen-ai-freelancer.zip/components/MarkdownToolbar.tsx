import React, { RefObject } from 'react';

interface MarkdownToolbarProps {
  textareaRef: RefObject<HTMLTextAreaElement>;
  onValueChange: (value: string) => void;
}

const MarkdownToolbar: React.FC<MarkdownToolbarProps> = ({ textareaRef, onValueChange }) => {
  const applyFormat = (type: 'bold' | 'italic' | 'strikethrough' | 'code') => {
    if (!textareaRef.current) return;

    const { selectionStart, selectionEnd, value } = textareaRef.current;
    const selectedText = value.substring(selectionStart, selectionEnd);
    const symbols = {
      bold: '**',
      italic: '*',
      strikethrough: '~~',
      code: '`',
    };
    const symbol = symbols[type];
    const newText = `${value.substring(0, selectionStart)}${symbol}${selectedText || type}${symbol}${value.substring(selectionEnd)}`;
    
    onValueChange(newText);
    
    // Restore focus and selection
    setTimeout(() => {
        textareaRef.current?.focus();
        if(selectedText) {
             textareaRef.current?.setSelectionRange(selectionStart + symbol.length, selectionEnd + symbol.length);
        } else {
             textareaRef.current?.setSelectionRange(selectionStart + symbol.length, selectionStart + symbol.length + type.length);
        }
    }, 0);
  };
  
  const applyList = (type: 'ul' | 'ol') => {
     if (!textareaRef.current) return;
     
     const { selectionStart, selectionEnd, value } = textareaRef.current;
     const lines = value.substring(selectionStart, selectionEnd).split('\n');
     let lineCounter = 1;

     const formattedLines = lines.map(line => {
         if (line.trim() === '') return line;
         if (type === 'ul') {
             return `- ${line}`;
         } else {
             return `${lineCounter++}. ${line}`;
         }
     }).join('\n');
     
     const newText = `${value.substring(0, selectionStart)}${formattedLines}${value.substring(selectionEnd)}`;
     onValueChange(newText);
  };

  const buttons = [
    { type: 'bold', label: 'Bold', icon: <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M6 4h8a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"/><path d="M6 12h9a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z"/></svg> },
    { type: 'italic', label: 'Italic', icon: <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="19" y1="4" x2="10" y2="4"/><line x1="14" y1="20" x2="5" y2="20"/><line x1="15" y1="4" x2="9" y2="20"/></svg> },
    { type: 'strikethrough', label: 'Strikethrough', icon: <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M16 4H9a3 3 0 0 0-2.83 4"/><path d="M14 12a4 4 0 0 1 0 8H6"/><line x1="4" y1="12" x2="20" y2="12"/></svg> },
    { type: 'code', label: 'Code', icon: <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg> },
    { type: 'ul', label: 'Unordered List', icon: <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg> },
    { type: 'ol', label: 'Ordered List', icon: <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="10" y1="6" x2="21" y2="6"/><line x1="10" y1="12" x2="21" y2="12"/><line x1="10" y1="18" x2="21" y2="18"/><path d="M4 6h1v4"/><path d="M4 10h2"/><path d="M6 18H4c0-1 2-2 2-3s-1-1.5-2-1.5"/></svg> },
  ];
  
  const handleButtonClick = (type: string) => {
    if (type === 'ul' || type === 'ol') {
      applyList(type);
    } else {
      applyFormat(type as 'bold' | 'italic' | 'strikethrough' | 'code');
    }
  };

  return (
    <div className="flex items-center gap-1 border-b border-slate-300 dark:border-slate-600 p-2">
      {buttons.map(button => (
        <button
          key={button.type}
          type="button"
          onClick={() => handleButtonClick(button.type)}
          title={button.label}
          className="p-2 rounded-md text-slate-500 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600 hover:text-slate-800 dark:hover:text-white transition-colors"
        >
          {button.icon}
        </button>
      ))}
    </div>
  );
};

export default MarkdownToolbar;