import React, { useState, useEffect, useRef, useCallback } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import type { PDFDocumentProxy, PDFPageProxy } from 'pdfjs-dist/types/src/display/api';
import LoadingSpinner from './LoadingSpinner';

// Set up the worker source for pdf.js
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@4.4.168/build/pdf.worker.mjs';

interface PdfViewerProps {
  fileUrl: string;
  page: number;
  onPageChange: (page: number) => void;
  onDocumentLoad: (pdf: PDFDocumentProxy) => void;
  onTextSelect: (text: string) => void;
  onAddBookmark: (page: number) => void;
  bookmarks: number[];
}

const PDF_VIEWER_SCALE_KEY = 'pdfViewer_scale';
const SPREAD_BREAKPOINT = 1024; // lg

const PdfViewer: React.FC<PdfViewerProps> = ({ fileUrl, page, onPageChange, onDocumentLoad, onTextSelect, onAddBookmark, bookmarks }) => {
  const [pdfDoc, setPdfDoc] = useState<PDFDocumentProxy | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [scale, setScale] = useState(() => parseFloat(localStorage.getItem(PDF_VIEWER_SCALE_KEY) || '1.5'));
  
  const [isSpreadView, setIsSpreadView] = useState(window.innerWidth > SPREAD_BREAKPOINT);

  const [isLeftPageLoaded, setIsLeftPageLoaded] = useState(false);
  const [isRightPageLoaded, setIsRightPageLoaded] = useState(false);

  const canvasLeftRef = useRef<HTMLCanvasElement>(null);
  const textLayerLeftRef = useRef<HTMLDivElement>(null);
  const canvasRightRef = useRef<HTMLCanvasElement>(null);
  const textLayerRightRef = useRef<HTMLDivElement>(null);
  const viewerContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    localStorage.setItem(PDF_VIEWER_SCALE_KEY, scale.toString());
  }, [scale]);

  useEffect(() => {
    const checkSize = () => setIsSpreadView(window.innerWidth > SPREAD_BREAKPOINT);
    window.addEventListener('resize', checkSize);
    return () => window.removeEventListener('resize', checkSize);
  }, []);
  
  useEffect(() => {
    setIsLoading(true);
    setPdfDoc(null);
    const loadingTask = pdfjsLib.getDocument(fileUrl);
    loadingTask.promise.then(
      (pdf) => {
        setPdfDoc(pdf);
        onDocumentLoad(pdf);
        onPageChange(1);
        setIsLoading(false);
      },
      (reason) => {
        console.error(`Error during PDF loading: ${reason}`);
        setError('Gagal memuatkan fail PDF.');
        setIsLoading(false);
      }
    );
  }, [fileUrl, onDocumentLoad]);

  const renderPage = useCallback(async (
    pageNum: number | null,
    canvasRef: React.RefObject<HTMLCanvasElement>,
    textLayerRef: React.RefObject<HTMLDivElement>,
    setPageLoaded: (loaded: boolean) => void
  ) => {
    if (!pdfDoc || !pageNum || pageNum > pdfDoc.numPages || pageNum < 1) {
        const canvas = canvasRef.current;
        if(canvas) {
            const context = canvas.getContext('2d');
            if (canvas.width > 0 && canvas.height > 0) {
               context?.clearRect(0, 0, canvas.width, canvas.height);
            }
        }
        if(textLayerRef.current) textLayerRef.current.innerHTML = '';
        setPageLoaded(true);
        return;
    };
    
    setPageLoaded(false);
    try {
        const pdfPage = await pdfDoc.getPage(pageNum);
        const viewport = pdfPage.getViewport({ scale });
        
        const canvas = canvasRef.current;
        const textLayer = textLayerRef.current;
        if (!canvas || !textLayer) return;

        const context = canvas.getContext('2d');
        if (!context) return;
        
        canvas.height = viewport.height;
        canvas.width = viewport.width;

        const renderContext = { canvasContext: context, viewport: viewport };
        await pdfPage.render(renderContext).promise;

        const textContent = await pdfPage.getTextContent();
        textLayer.innerHTML = ''; // Clear previous
        textLayer.style.setProperty('--scale-factor', scale.toString());
        textLayer.style.width = `${viewport.width}px`;
        textLayer.style.height = `${viewport.height}px`;
        pdfjsLib.renderTextLayer({ textContentSource: textContent, container: textLayer, viewport });
        
        setPageLoaded(true);
    } catch (e) {
      console.error(`Failed to render page ${pageNum}`, e);
    }
  }, [pdfDoc, scale]);

  // In spread view, if we are on the last page and it's an even number,
  // we display it alone on the right, like a book's back cover.
  const isEvenLastPageAlone = isSpreadView && pdfDoc && page === pdfDoc.numPages && pdfDoc.numPages % 2 === 0;

  const leftPageNum = (isSpreadView && page > 1 && !isEvenLastPageAlone) 
    ? (page % 2 === 0 ? page : page - 1) 
    : null;

  const rightPageNum = isSpreadView 
    ? (page === 1 ? 1 : (leftPageNum ? leftPageNum + 1 : page))
    : page;

  useEffect(() => {
    if(isSpreadView){
        renderPage(leftPageNum, canvasLeftRef, textLayerLeftRef, setIsLeftPageLoaded);
        renderPage(rightPageNum, canvasRightRef, textLayerRightRef, setIsRightPageLoaded);
    } else {
        // In single view, ensure left page is cleared
        renderPage(null, canvasLeftRef, textLayerLeftRef, setIsLeftPageLoaded);
        renderPage(rightPageNum, canvasRightRef, textLayerRightRef, setIsRightPageLoaded);
    }
  }, [page, pdfDoc, isSpreadView, leftPageNum, rightPageNum, renderPage]);

  const handlePrevPage = useCallback(() => {
    if (!pdfDoc || page <= 1) return;
    const jump = isSpreadView ? 2 : 1;
    const newPage = Math.max(1, page - jump);
    onPageChange(newPage);
  }, [page, isSpreadView, pdfDoc, onPageChange]);

  const handleNextPage = useCallback(() => {
    if (!pdfDoc) return;
    const jump = isSpreadView && page > 0 ? 2 : 1;
    const newPage = Math.min(pdfDoc.numPages, page + jump);
    if (newPage !== page) onPageChange(newPage);
  }, [page, pdfDoc, isSpreadView, onPageChange]);

  const handleZoomIn = () => setScale(s => s + 0.25);
  const handleZoomOut = () => setScale(s => Math.max(0.25, s - 0.25));

  const handleTextSelection = () => {
      const selection = window.getSelection()?.toString().trim() ?? '';
      if (selection.length > 0) onTextSelect(selection);
  };
  
  if (isLoading) {
    return (
        <div className="w-full h-full flex flex-col items-center justify-center bg-slate-100 dark:bg-slate-800">
            <LoadingSpinner className="w-10 h-10 text-blue-500" />
            <p className="mt-4 text-slate-500 dark:text-slate-400">Memuatkan PDF...</p>
        </div>
    );
  }

  if (error) {
     return <div className="w-full h-full flex items-center justify-center bg-slate-100 dark:bg-slate-800 text-red-500 dark:text-red-400">{error}</div>;
  }
  
  const pageLabel = pdfDoc ? (isSpreadView
    ? (!leftPageNum ? `Muka Surat ${rightPageNum}` // Handles page 1 and even-last-page
      : (rightPageNum > pdfDoc.numPages ? `Muka Surat ${leftPageNum}` : `Muka Surat ${leftPageNum}-${rightPageNum}`))
    : `Muka Surat ${page}`) : '';


  return (
    <div className="w-full h-full flex flex-col bg-slate-200 dark:bg-slate-700">
      <div 
        ref={viewerContainerRef}
        className="flex-grow overflow-auto flex justify-center items-center"
        onMouseUp={handleTextSelection}
        onTouchEnd={handleTextSelection}
      >
        <div className="book-viewer">
            <div className="book-spread" style={{ flexDirection: isSpreadView ? 'row' : 'column' }}>
                {isSpreadView && leftPageNum && (
                    <div className={`book-page ${isLeftPageLoaded ? 'loaded' : ''}`}>
                         <canvas ref={canvasLeftRef} />
                         <div ref={textLayerLeftRef} className="textLayer" />
                         <div className="page-turn-area page-turn-area--prev" onClick={handlePrevPage}></div>
                    </div>
                )}
                {pdfDoc && rightPageNum > 0 && rightPageNum <= pdfDoc.numPages && (
                    <div className={`book-page ${isSpreadView && !leftPageNum ? 'book-page--single' : ''} ${isRightPageLoaded ? 'loaded' : ''}`}>
                         <canvas ref={canvasRightRef} />
                         <div ref={textLayerRightRef} className="textLayer" />
                         {!isSpreadView && <div className="page-turn-area page-turn-area--prev" onClick={handlePrevPage}></div>}
                         <div className="page-turn-area page-turn-area--next" onClick={handleNextPage}></div>
                    </div>
                )}
            </div>
        </div>
      </div>
      {pdfDoc && (
        <div className="flex-shrink-0 bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm p-2 flex items-center justify-center gap-2 sm:gap-4 text-slate-800 dark:text-white">
          <button onClick={handlePrevPage} disabled={page <= 1} className="p-2 bg-slate-200 dark:bg-slate-600 rounded-md disabled:opacity-50 hover:bg-slate-300 dark:hover:bg-slate-500 transition" title="Sebelumnya">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
          </button>
          <span className="text-sm font-medium w-32 text-center">
            {pageLabel} / {pdfDoc.numPages}
          </span>
          <button onClick={handleNextPage} disabled={page >= pdfDoc.numPages || rightPageNum >= pdfDoc.numPages} className="p-2 bg-slate-200 dark:bg-slate-600 rounded-md disabled:opacity-50 hover:bg-slate-300 dark:hover:bg-slate-500 transition" title="Seterusnya">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
          </button>

          <div className="h-6 border-l border-slate-300 dark:border-slate-600 mx-1 sm:mx-2"></div>
          
          <button onClick={handleZoomOut} className="p-2 bg-slate-200 dark:bg-slate-600 rounded-md hover:bg-slate-300 dark:hover:bg-slate-500 transition" title="Zum Keluar"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line></svg></button>
          <span className="text-sm w-12 text-center">{(scale * 100).toFixed(0)}%</span>
          <button onClick={handleZoomIn} className="p-2 bg-slate-200 dark:bg-slate-600 rounded-md hover:bg-slate-300 dark:hover:bg-slate-500 transition" title="Zum Masuk"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg></button>

          <div className="h-6 border-l border-slate-300 dark:border-slate-600 mx-1 sm:mx-2"></div>
          
          {isSpreadView && leftPageNum && (
             <button onClick={() => onAddBookmark(leftPageNum)} disabled={bookmarks.includes(leftPageNum)} className="p-2 bg-slate-200 dark:bg-slate-600 rounded-md disabled:opacity-50 hover:bg-slate-300 dark:hover:bg-slate-500 transition" title={`Tanda Halaman ${leftPageNum}`} >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill={bookmarks.includes(leftPageNum) ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={`transition-colors ${bookmarks.includes(leftPageNum) ? 'text-blue-500 dark:text-blue-400' : ''}`}><path d="m19 21-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/></svg>
             </button>
          )}
           <button onClick={() => onAddBookmark(rightPageNum)} disabled={bookmarks.includes(rightPageNum) || rightPageNum > pdfDoc.numPages} className="p-2 bg-slate-200 dark:bg-slate-600 rounded-md disabled:opacity-50 hover:bg-slate-300 dark:hover:bg-slate-500 transition" title={`Tanda Halaman ${rightPageNum}`}>
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill={bookmarks.includes(rightPageNum) ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={`transition-colors ${bookmarks.includes(rightPageNum) ? 'text-blue-500 dark:text-blue-400' : ''}`}><path d="m19 21-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/></svg>
           </button>
        </div>
      )}
    </div>
  );
};

export default PdfViewer;