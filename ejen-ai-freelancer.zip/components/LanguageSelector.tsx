import React, { useState, useRef, useEffect } from 'react';
import { useLanguage, UiLang, AiLang } from '../contexts/LanguageContext';

const LanguageSelector: React.FC = () => {
  const { uiLang, setUiLang, aiLang, setAiLang, t } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleUiLangChange = (lang: UiLang) => {
    setUiLang(lang);
    setIsOpen(false);
  };

  const handleAiLangChange = (lang: AiLang) => {
    setAiLang(lang);
    setIsOpen(false);
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center justify-center h-10 w-10 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white rounded-full transition-colors duration-200 hover:bg-slate-200 dark:hover:bg-slate-700"
        title={t('common.language')}
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="m5 8 6 6"/>
            <path d="m4 14 6-6 2-3"/>
            <path d="M2 5h12"/>
            <path d="M7 2h1"/>
            <path d="m22 22-5-10-5 10"/>
            <path d="M14 18h6"/>
        </svg>
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-56 bg-white dark:bg-slate-800 rounded-md shadow-lg ring-1 ring-black ring-opacity-5 z-10">
          <div className="p-4 space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                {t('common.language')} UI
              </label>
              <div className="flex flex-col space-y-2">
                <button onClick={() => handleUiLangChange('ms')} className={`text-left text-sm p-2 rounded-md ${uiLang === 'ms' ? 'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}`}>
                  {t('common.bahasaMalaysia')}
                </button>
                <button onClick={() => handleUiLangChange('en')} className={`text-left text-sm p-2 rounded-md ${uiLang === 'en' ? 'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}`}>
                  {t('common.english')}
                </button>
              </div>
            </div>
            <div className="border-t border-slate-200 dark:border-slate-700"></div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                {t('common.responseLanguage')} AI
              </label>
              <div className="flex flex-col space-y-2">
                <button onClick={() => handleAiLangChange('Bahasa Malaysia')} className={`text-left text-sm p-2 rounded-md ${aiLang === 'Bahasa Malaysia' ? 'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}`}>
                  {t('common.bahasaMalaysia')}
                </button>
                <button onClick={() => handleAiLangChange('English')} className={`text-left text-sm p-2 rounded-md ${aiLang === 'English' ? 'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100' : 'hover:bg-slate-100 dark:hover:bg-slate-700'}`}>
                  {t('common.english')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LanguageSelector;