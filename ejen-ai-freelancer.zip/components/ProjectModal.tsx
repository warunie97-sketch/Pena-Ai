import React, { useState, useEffect, useCallback } from 'react';
import type { Project, ProjectStatus, ProjectPriority } from '../types';
import { useGemini } from '../contexts/GeminiContext';
import { getProjectAssistance } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';

interface ProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (project: Omit<Project, 'id'>) => void;
  project: Project | null;
}

const AiAssistButton: React.FC<{ onClick: () => void, isLoading: boolean, disabled: boolean, children: React.ReactNode, title: string }> = ({ onClick, isLoading, disabled, children, title }) => (
    <button
        type="button"
        onClick={onClick}
        disabled={isLoading || disabled}
        title={title}
        className="flex items-center gap-1.5 text-xs bg-slate-200 dark:bg-slate-600 hover:bg-slate-300 dark:hover:bg-slate-500 text-slate-700 dark:text-white font-medium py-1 px-3 rounded-md transition-all duration-200 hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
    >
        {isLoading ? <LoadingSpinner className="w-4 h-4" /> : (
             <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3v.01"/><path d="M16.2 3.8v.01"/><path d="M20.2 7.8v.01"/><path d="M21 12v.01"/><path d="M20.2 16.2v.01"/><path d="M16.2 20.2v.01"/><path d="M12 21v.01"/><path d="M7.8 20.2v.01"/><path d="M3.8 16.2v.01"/><path d="M3 12v.01"/><path d="M3.8 7.8v.01"/><path d="M7.8 3.8v.01"/></svg>
        )}
        {children}
    </button>
);


const ProjectModal: React.FC<ProjectModalProps> = ({ isOpen, onClose, onSave, project }) => {
  const { aiInstance } = useGemini();
  const [name, setName] = useState('');
  const [client, setClient] = useState('');
  const [deadline, setDeadline] = useState('');
  const [status, setStatus] = useState<ProjectStatus>('Belum Mula');
  const [notes, setNotes] = useState('');
  const [priority, setPriority] = useState<ProjectPriority>('Sederhana');
  const [assignee, setAssignee] = useState('');
  const [estimatedHours, setEstimatedHours] = useState<number | ''>('');
  const [aiLoading, setAiLoading] = useState<'brief' | 'tasks' | 'hours' | null>(null);
  const [aiError, setAiError] = useState('');


  useEffect(() => {
    if (project) {
      setName(project.name);
      setClient(project.client);
      
      // The original deadline might not be in YYYY-MM-DD format.
      // We try to parse it and format it correctly for the date input.
      const date = project.deadline ? new Date(project.deadline.replace(/-/g, '/')) : null;
      if (date && !isNaN(date.getTime())) {
          const year = date.getFullYear();
          const month = (date.getMonth() + 1).toString().padStart(2, '0');
          const day = date.getDate().toString().padStart(2, '0');
          setDeadline(`${year}-${month}-${day}`);
      } else {
          setDeadline('');
      }

      setStatus(project.status);
      setNotes(project.notes);
      setPriority(project.priority || 'Sederhana');
      setAssignee(project.assignee || '');
      setEstimatedHours(project.estimatedHours || '');
    } else {
      // Reset form for new project
      setName('');
      setClient('');
      setDeadline('');
      setStatus('Belum Mula');
      setNotes('');
      setPriority('Sederhana');
      setAssignee('');
      setEstimatedHours('');
    }
  }, [project, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onSave({ 
        name, 
        client, 
        deadline, 
        status, 
        notes,
        priority,
        assignee,
        estimatedHours: Number(estimatedHours) || 0
    });
  };
  
  const handleClose = useCallback((e: React.MouseEvent | React.KeyboardEvent) => {
      // Close on background click
      if ('target' in e && 'currentTarget' in e && e.target === e.currentTarget) {
          onClose();
      }
  }, [onClose]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') {
            onClose();
        }
    };
    if (isOpen) {
        document.addEventListener('keydown', handleKeyDown);
    }
    return () => {
        document.removeEventListener('keydown', handleKeyDown);
    }
  }, [isOpen, onClose]);

  const handleAiAction = async (action: 'brief' | 'tasks' | 'hours') => {
      if (!aiInstance) {
          setAiError('Sila tetapkan Kunci API Gemini anda untuk menggunakan pembantu AI.');
          return;
      }
      setAiLoading(action);
      setAiError('');
      
      let prompt = '';
      try {
          switch(action) {
              case 'brief':
                  prompt = `Expand the following notes into a structured project brief for a project named "${name}" for the client "${client}". Notes:\n"""\n${notes}\n"""`;
                  const brief = await getProjectAssistance(aiInstance, prompt);
                  setNotes(brief);
                  break;
              case 'tasks':
                  prompt = `Based on the project name "${name}" and the following notes, suggest a checklist of common tasks in markdown format. Notes:\n"""\n${notes}\n"""`;
                  const tasks = await getProjectAssistance(aiInstance, prompt);
                  setNotes(prev => prev ? `${prev}\n\n### Cadangan Tugasan\n${tasks}` : `### Cadangan Tugasan\n${tasks}`);
                  break;
              case 'hours':
                  prompt = `Based on the project name "${name}" and the following notes, estimate the total hours required. Respond with only a single number, no extra text, labels, or explanations. Notes:\n"""\n${notes}\n"""`;
                  const hoursText = await getProjectAssistance(aiInstance, prompt);
                  const hours = parseInt(hoursText.match(/\d+/)?.[0] || '', 10);
                  if (!isNaN(hours)) {
                      setEstimatedHours(hours);
                  } else {
                      setAiError('AI tidak memulangkan anggaran yang sah. Sila cuba lagi.');
                  }
                  break;
          }
      } catch (err) {
          setAiError(err instanceof Error ? err.message : 'An unexpected AI error occurred.');
      } finally {
          setAiLoading(null);
      }
  };


  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4"
      onClick={handleClose}
      aria-modal="true"
      role="dialog"
    >
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-xl w-full max-w-lg" onClick={e => e.stopPropagation()}>
        <form onSubmit={handleSubmit}>
          <div className="p-6 border-b border-slate-200 dark:border-slate-700">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">{project ? 'Sunting Projek' : 'Cipta Projek Baru'}</h2>
          </div>
          <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Nama Projek (Diperlukan)</label>
              <input id="name" type="text" value={name} onChange={(e) => setName(e.target.value)} required className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label htmlFor="client" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Nama Klien</label>
              <input id="client" type="text" value={client} onChange={(e) => setClient(e.target.value)} className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500" />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
               <div>
                <label htmlFor="priority" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Keutamaan</label>
                <select id="priority" value={priority} onChange={(e) => setPriority(e.target.value as ProjectPriority)} className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500">
                  <option>Rendah</option>
                  <option>Sederhana</option>
                  <option>Tinggi</option>
                </select>
              </div>
              <div>
                <label htmlFor="assignee" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Penerima Tugas</label>
                <input id="assignee" type="text" value={assignee} onChange={(e) => setAssignee(e.target.value)} className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500" placeholder="cth., Jane Doe" />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="deadline" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Tarikh Akhir</label>
                <input id="deadline" type="date" value={deadline} onChange={(e) => setDeadline(e.target.value)} className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500" />
              </div>
              <div>
                <label htmlFor="estimatedHours" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Anggaran Jam</label>
                <input id="estimatedHours" type="number" value={estimatedHours} onChange={(e) => setEstimatedHours(e.target.value === '' ? '' : Number(e.target.value))} min="0" className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500" />
                 <div className="mt-2">
                     <AiAssistButton onClick={() => handleAiAction('hours')} isLoading={aiLoading === 'hours'} disabled={!name.trim()} title="Anggarkan jam menggunakan AI">
                        Cadang Anggaran
                     </AiAssistButton>
                 </div>
              </div>
            </div>
             <div>
                <label htmlFor="status" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Status</label>
                <select id="status" value={status} onChange={(e) => setStatus(e.target.value as ProjectStatus)} className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500">
                  <option>Belum Mula</option>
                  <option>Dalam Proses</option>
                  <option>Selesai</option>
                  <option>Ditangguhkan</option>
                </select>
              </div>
            <div>
              <label htmlFor="notes" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Nota</label>
              <textarea id="notes" rows={4} value={notes} onChange={(e) => setNotes(e.target.value)} className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md p-2 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500"></textarea>
               <div className="mt-2 flex items-center gap-2">
                  <AiAssistButton onClick={() => handleAiAction('brief')} isLoading={aiLoading === 'brief'} disabled={!name.trim()} title="Jana draf ringkasan projek daripada nota anda">
                      Jana Ringkasan
                  </AiAssistButton>
                   <AiAssistButton onClick={() => handleAiAction('tasks')} isLoading={aiLoading === 'tasks'} disabled={!name.trim()} title="Cadangkan senarai tugasan berdasarkan butiran projek">
                      Cadang Tugasan
                  </AiAssistButton>
               </div>
            </div>
            {aiError && <p className="text-red-500 dark:text-red-400 text-sm text-center">{aiError}</p>}
          </div>
          <div className="p-4 bg-slate-100 dark:bg-slate-900/50 flex justify-end gap-3 rounded-b-lg">
            <button type="button" onClick={onClose} className="bg-slate-200 hover:bg-slate-300 text-slate-800 dark:bg-slate-600 dark:hover:bg-slate-500 dark:text-white font-medium py-2 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">Batal</button>
            <button type="submit" disabled={!name.trim()} className="bg-blue-600 hover:bg-blue-700 disabled:bg-slate-500 disabled:cursor-not-allowed text-white font-bold py-2 px-4 rounded-md transition-all duration-200 hover:scale-105 active:scale-95">Simpan Projek</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProjectModal;