import React, { useState } from 'react';
import type { Slide } from '../types';
import MarkdownRenderer from './MarkdownRenderer';

interface PresentationViewerProps {
  slides: Slide[];
}

const PresentationViewer: React.FC<PresentationViewerProps> = ({ slides }) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  if (!slides || slides.length === 0) {
    return (
      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-lg text-center">
        <p className="text-slate-500 dark:text-slate-400">Tiada slaid untuk dipaparkan.</p>
      </div>
    );
  }

  const goToNext = () => setCurrentSlide(prev => Math.min(slides.length - 1, prev + 1));
  const goToPrev = () => setCurrentSlide(prev => Math.max(0, prev - 1));

  const slide = slides[currentSlide];

  return (
    <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg overflow-hidden">
        <div className="aspect-video bg-slate-100 dark:bg-slate-900 p-8 flex flex-col justify-center items-center">
            <h2 className="text-4xl font-bold text-slate-900 dark:text-white mb-4 text-center">{slide.title}</h2>
            <div className="text-slate-700 dark:text-slate-300 text-lg text-center">
                 <MarkdownRenderer content={slide.content} />
            </div>
        </div>
        
        {slide.speaker_notes && (
            <div className="p-4 bg-slate-200 dark:bg-slate-700">
                <h4 className="font-bold text-sm text-slate-600 dark:text-slate-300 mb-2">Nota Penceramah:</h4>
                <p className="text-sm text-slate-600 dark:text-slate-400">{slide.speaker_notes}</p>
            </div>
        )}

        <div className="p-4 bg-slate-100 dark:bg-slate-900/50 flex justify-between items-center">
            <button onClick={goToPrev} disabled={currentSlide === 0} className="px-4 py-2 bg-blue-600 text-white rounded-md disabled:bg-slate-400">Sebelumnya</button>
            <span className="font-semibold text-slate-700 dark:text-slate-200">Slaid {currentSlide + 1} / {slides.length}</span>
            <button onClick={goToNext} disabled={currentSlide === slides.length - 1} className="px-4 py-2 bg-blue-600 text-white rounded-md disabled:bg-slate-400">Seterusnya</button>
        </div>
    </div>
  );
};

export default PresentationViewer;
