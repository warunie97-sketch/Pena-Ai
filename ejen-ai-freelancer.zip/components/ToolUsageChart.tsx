import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { useAnalytics } from '../contexts/AnalyticsContext';
import { useTheme } from '../contexts/ThemeContext';
import { TOOLS } from '../constants';
import { useLanguage } from '../contexts/LanguageContext';
import type { Tool, ToolId } from '../types';

const COLORS = ['#3B82F6', '#8B5CF6', '#10B981', '#F59E0B', '#EF4444'];

// Create a map for efficient and safe lookup. This is created once when the module is loaded.
const toolMap = new Map<ToolId, Tool>(TOOLS.map(tool => [tool.id, tool]));

const ToolUsageChart: React.FC = () => {
    const { usageData } = useAnalytics();
    const { theme } = useTheme();
    const { t } = useLanguage();

    const chartData = Object.entries(usageData)
        .map(([toolId, count]) => {
            const tool = toolMap.get(toolId as ToolId);
            // If tool is not found in the current TOOLS constant (e.g., from old localStorage data), ignore this entry.
            if (!tool) {
                return null;
            }
            return {
                id: toolId,
                name: t(tool.nameKey),
                usage: count,
            };
        })
        // Filter out null entries (for deleted tools) and entries with no/invalid usage.
        .filter((item): item is { id: string; name: string; usage: number } => item !== null && typeof item.usage === 'number' && item.usage > 0)
        .sort((a, b) => b.usage - a.usage)
        .slice(0, 5); // Only show the top 5 most used tools

    if (chartData.length === 0) {
        return (
            <div className="flex items-center justify-center h-96 bg-slate-100 dark:bg-slate-800 rounded-lg">
                <p className="text-slate-500 dark:text-slate-400">{t('dashboard.noUsageData')}</p>
            </div>
        );
    }

    const tickColor = theme === 'dark' ? '#94a3b8' : '#64748b';
    const gridColor = theme === 'dark' ? '#334155' : '#e2e8f0';

    const CustomTooltip = ({ active, payload, label }: any) => {
      if (active && payload && payload.length) {
        return (
          <div className="bg-white dark:bg-slate-800 p-3 rounded-md shadow-lg border border-slate-200 dark:border-slate-600">
            <p className="font-bold text-slate-900 dark:text-white">{label}</p>
            <p className="text-sm text-slate-600 dark:text-slate-300">{`${t('dashboard.usageLabel')}: ${payload[0].value}`}</p>
          </div>
        );
      }
      return null;
    };

    return (
        <div style={{ width: '100%', height: 400 }}>
            <ResponsiveContainer>
                <BarChart
                    data={chartData}
                    layout="vertical"
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                    <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
                    <XAxis type="number" allowDecimals={false} tick={{ fill: tickColor, fontSize: 12 }} />
                    <YAxis
                        dataKey="name"
                        type="category"
                        tick={{ fill: tickColor, fontSize: 12, width: 150 }}
                        width={150}
                        interval={0}
                    />
                    <Tooltip content={<CustomTooltip />} cursor={{fill: theme === 'dark' ? 'rgba(100, 116, 139, 0.2)' : 'rgba(203, 213, 225, 0.4)'}} />
                    <Bar dataKey="usage" name={t('dashboard.usageLabel')}>
                        {chartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                    </Bar>
                </BarChart>
            </ResponsiveContainer>
        </div>
    );
};

export default ToolUsageChart;
