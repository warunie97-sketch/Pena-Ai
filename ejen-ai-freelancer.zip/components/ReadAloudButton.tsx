import React, { useState, useRef, useCallback, useEffect } from 'react';
import { useGemini } from '../contexts/GeminiContext';
import { generateSpeech } from '../services/geminiService';
import { decode, decodeAudioData } from '../utils/audioUtils';
import LoadingSpinner from './LoadingSpinner';

interface ReadAloudButtonProps {
  textToRead: string;
}

const ReadAloudButton: React.FC<ReadAloudButtonProps> = ({ textToRead }) => {
    const { aiInstance } = useGemini();
    const [status, setStatus] = useState<'idle' | 'loading' | 'playing' | 'error'>('idle');
    const [error, setError] = useState('');
    
    const audioContextRef = useRef<AudioContext | null>(null);
    const sourceRef = useRef<AudioBufferSourceNode | null>(null);

    // Cleanup audio resources on unmount
    useEffect(() => {
        return () => {
            sourceRef.current?.stop();
            if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
                audioContextRef.current.close();
            }
        };
    }, []);

    // Stop playback if the text to read changes while playing
    useEffect(() => {
        if (status === 'playing' || status === 'loading') {
            sourceRef.current?.stop();
            setStatus('idle');
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [textToRead]);

    const handleClick = async () => {
        if (status === 'loading' || status === 'playing') {
            sourceRef.current?.stop(); // onended will fire and set status to 'idle'
            return;
        }

        if (!aiInstance) {
            setError('Sila tetapkan Kunci API anda.');
            setStatus('error');
            setTimeout(() => { setStatus('idle'); setError(''); }, 3000);
            return;
        }
        if (!textToRead.trim()) return;

        setStatus('loading');
        setError('');

        try {
            // Using a neutral, standard voice for reading aloud.
            const base64Audio = await generateSpeech(aiInstance, textToRead, 'Zephyr');

            if (!audioContextRef.current || audioContextRef.current.state === 'closed') {
                audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            }
            const audioCtx = audioContextRef.current;
            
            const audioBytes = decode(base64Audio);
            const audioBuffer = await decodeAudioData(audioBytes, audioCtx, 24000, 1);
            
            const source = audioCtx.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(audioCtx.destination);
            
            source.onended = () => {
                setStatus('idle');
                sourceRef.current = null;
            };
            
            source.start();
            sourceRef.current = source;
            setStatus('playing');

        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'Gagal menjana audio.';
            setError(errorMessage);
            setStatus('error');
            console.error(errorMessage);
            setTimeout(() => { setStatus('idle'); setError(''); }, 5000);
        }
    };
    
    const iconMap = {
        idle: <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>,
        loading: <LoadingSpinner className="w-4 h-4" />,
        playing: <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>,
        error: <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
    };

    const titleMap = {
        idle: "Baca Dengan Kuat",
        loading: "Memuatkan audio...",
        playing: "Berhenti",
        error: error || "Ralat Audio"
    };

    const colorMap = {
        idle: "bg-teal-600 hover:bg-teal-500",
        loading: "bg-yellow-500 cursor-not-allowed",
        playing: "bg-red-600 hover:bg-red-500",
        error: "bg-red-600"
    };
    
    return (
        <button
            onClick={handleClick}
            title={titleMap[status]}
            disabled={(!textToRead.trim() && status === 'idle') || status === 'loading'}
            className={`p-2 text-sm ${colorMap[status]} text-white font-medium rounded-md transition-all duration-200 hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed`}
        >
            {iconMap[status]}
        </button>
    );
};

export default ReadAloudButton;