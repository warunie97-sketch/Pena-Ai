import * as pdfjsLib from 'pdfjs-dist';
import mammoth from 'mammoth';

// Set up the worker source for pdf.js. This is crucial for it to work in a browser environment.
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@4.4.168/build/pdf.worker.mjs';

/**
 * Parses the text content from a PDF file.
 * @param file - The PDF file to parse.
 * @returns A promise that resolves with the extracted text content.
 */
const parsePdf = async (file: File): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    // Using `any` for PDFDocumentProxy to avoid type import issues in the browser module environment.
    const pdf: any = await pdfjsLib.getDocument(arrayBuffer).promise;
    let fullText = '';

    for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const pageText = (textContent.items as { str: string }[]).map(item => item.str).join(' ');
        fullText += pageText + '\n\n';
    }
    return fullText;
};

/**
 * Parses the text content from a DOCX file.
 * @param file - The DOCX file to parse.
 * @returns A promise that resolves with the extracted text content.
 */
const parseDocx = async (file: File): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    const result = await mammoth.extractRawText({ arrayBuffer });
    return result.value;
};

/**
 * Parses the text content from a TXT file.
 * @param file - The TXT file to parse.
 * @returns A promise that resolves with the text content.
 */
const parseTxt = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target?.result as string);
        reader.onerror = (e) => reject(new Error('Failed to read text file.'));
        reader.readAsText(file);
    });
};


/**
 * Parses a file to extract its text content, supporting PDF, DOCX, and TXT formats.
 * @param file - The file to parse.
 * @returns A promise that resolves with the extracted text, or rejects if the format is unsupported.
 */
export const parseFileForText = (file: File): Promise<string> => {
    if (file.type === 'application/pdf') {
        return parsePdf(file);
    }
    if (file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || file.name.endsWith('.docx')) {
        return parseDocx(file);
    }
    if (file.type === 'text/plain' || file.name.endsWith('.txt') || file.name.endsWith('.md')) {
        return parseTxt(file);
    }
    return Promise.reject(new Error('Jenis fail tidak disokong untuk pengekstrakan teks. Sila gunakan PDF, DOCX, TXT, atau MD.'));
};