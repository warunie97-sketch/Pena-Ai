import type { UTMParams } from '../contexts/UTMContext';

/**
 * Appends UTM parameters to a given URL.
 * It handles existing query parameters in the URL and allows for a dynamic utm_content override.
 * @param urlString The original URL.
 * @param params The base UTM parameters to append.
 * @param dynamicContent An optional string to override the utm_content parameter.
 * @returns The new URL with UTM parameters.
 */
export const appendUTMParams = (urlString: string, params: UTMParams, dynamicContent?: string): string => {
  if (!urlString) return '';
  
  try {
    const url = new URL(urlString);
    
    // Create a mutable copy of params and apply the dynamic override
    const finalParams: UTMParams = { ...params };
    if (dynamicContent) {
      finalParams.utm_content = dynamicContent;
    }
    
    Object.entries(finalParams).forEach(([key, value]) => {
      if (value) {
        // The type assertion is safe here as UTMParams only has string values.
        url.searchParams.set(key, value as string);
      }
    });

    return url.toString();
  } catch (error) {
    console.warn(`Invalid URL provided to appendUTMParams: ${urlString}`);
    return urlString; // Return original URL if it's invalid
  }
};