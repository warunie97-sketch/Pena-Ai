import type { Project } from '../types';

// Formats a date string (YYYY-MM-DD) into the required ICS format (YYYYMMDD) for an all-day event.
const formatDateForICS = (dateString: string): string => {
    if (!dateString) return '';
    // Removes hyphens from 'YYYY-MM-DD' to get 'YYYYMMDD'
    return dateString.replace(/-/g, '');
};

/**
 * Generates the content for an .ics file for a single project deadline.
 * @param project The project to create a calendar event for.
 * @returns A string containing the VCALENDAR data.
 */
const generateICSContent = (project: Project): string => {
    const startDate = formatDateForICS(project.deadline);
    if (!startDate) return '';
    
    // For an all-day event, DTEND is the day after DTSTART.
    const endDate = new Date(project.deadline.replace(/-/g, '/'));
    endDate.setDate(endDate.getDate() + 1);
    const endDateString = `${endDate.getFullYear()}${(endDate.getMonth() + 1).toString().padStart(2, '0')}${endDate.getDate().toString().padStart(2, '0')}`;

    const uid = `${Date.now()}-${project.id}@ejen-ai-freelancer.com`;
    const timestamp = new Date().toISOString().replace(/[-:.]/g, '') + 'Z';
    
    // RFC 5545 VCALENDAR format
    const icsContent = [
        'BEGIN:VCALENDAR',
        'VERSION:2.0',
        'PRODID:-//EjenAIFreelancer//ProjectDeadline//EN',
        'BEGIN:VEVENT',
        `UID:${uid}`,
        `DTSTAMP:${timestamp}`,
        `DTSTART;VALUE=DATE:${startDate}`,
        `DTEND;VALUE=DATE:${endDateString}`, // All-day events end on the next day
        `SUMMARY:Tarikh Akhir Projek: ${project.name}`,
        `DESCRIPTION:Tarikh akhir untuk projek '${project.name}'. Klien: ${project.client || 'N/A'}. Keutamaan: ${project.priority || 'Sederhana'}. Nota: ${project.notes || 'Tiada'}.`,
        'END:VEVENT',
        'END:VCALENDAR'
    ].join('\r\n');
    
    return icsContent;
};

/**
 * Triggers a browser download for a given text content as a file.
 * @param content The string content of the file.
 * @param filename The desired name for the downloaded file.
 */
export const downloadICSFile = (project: Project) => {
    const icsContent = generateICSContent(project);
    if (!icsContent) {
        alert("Projek tidak mempunyai tarikh akhir yang sah.");
        return;
    }

    const filename = `TarikhAkhir_${project.name.replace(/[^a-z0-9]/gi, '_')}.ics`;
    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
};
