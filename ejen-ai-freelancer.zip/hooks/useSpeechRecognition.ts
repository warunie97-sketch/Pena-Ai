import { useState, useEffect, useRef, useCallback } from 'react';
import { useLanguage } from '../contexts/LanguageContext';

// These APIs are not part of the standard DOM typings.
interface SpeechRecognitionAlternative {
  readonly transcript: string;
  readonly confidence: number;
}

interface SpeechRecognitionResult {
  readonly isFinal: boolean;
  readonly length: number;
  item(index: number): SpeechRecognitionAlternative;
  [index: number]: SpeechRecognitionAlternative;
}

interface SpeechRecognitionResultList {
  readonly length: number;
  item(index: number): SpeechRecognitionResult;
  [index: number]: SpeechRecognitionResult;
}

interface SpeechRecognitionEvent extends Event {
  readonly resultIndex: number;
  readonly results: SpeechRecognitionResultList;
}

interface SpeechRecognitionErrorEvent extends Event {
  readonly error: string;
  readonly message: string;
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  abort(): void;
  onresult: (event: SpeechRecognitionEvent) => void;
  onerror: (event: SpeechRecognitionErrorEvent) => void;
  onend: () => void;
}

// Consistent access to the SpeechRecognition object, checking for vendor prefixes.
const SpeechRecognitionAPI = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

type Recognition = SpeechRecognition | null;

/**
 * A custom React hook to handle voice-to-text transcription using the Web Speech API.
 * @param onTranscriptUpdate - A callback function that receives the transcribed text.
 * @returns An object with the listening state, functions to start/stop listening, and a support flag.
 */
export const useSpeechRecognition = (onTranscriptUpdate: (transcript: string) => void) => {
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<Recognition>(null);
  const { uiLang } = useLanguage();
  const onTranscriptUpdateRef = useRef(onTranscriptUpdate);

  // Keep the ref updated with the latest callback without re-triggering the main effect.
  useEffect(() => {
    onTranscriptUpdateRef.current = onTranscriptUpdate;
  }, [onTranscriptUpdate]);

  useEffect(() => {
    if (!SpeechRecognitionAPI) {
      console.warn("Speech Recognition API is not supported in this browser.");
      return;
    }

    const recognition: SpeechRecognition = new SpeechRecognitionAPI();
    recognition.continuous = true; // Keep listening even after a pause in speech.
    recognition.interimResults = false; // We only process the final, confirmed transcript.
    recognition.lang = uiLang === 'ms' ? 'ms-MY' : 'en-US'; // Set language dynamically

    // Event handler for when the API returns a result.
    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let finalTranscript = '';
      // Concatenate all final results from the current event.
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        }
      }
      if (finalTranscript) {
        // Append the new transcript with a space for better sentence separation.
        onTranscriptUpdateRef.current(finalTranscript.trim() + ' ');
      }
    };

    // Event handler for when the recognition service ends.
    recognition.onend = () => {
      // This handler is called when the service stops, either programmatically or due to timeout.
      // We ensure the UI state is synced.
      setIsListening(false);
    };

    // Event handler for any errors.
    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      console.error('Speech recognition error:', event.error, event.message);
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        alert("Akses mikrofon telah dinafikan. Sila benarkan akses mikrofon dalam tetapan pelayar anda untuk menggunakan ciri ini.");
      }
      // The 'aborted' error is often not a "real" user-facing error, but a result of stopping the service.
      // We will still log it but won't show an alert.
      setIsListening(false);
    };

    recognitionRef.current = recognition;

    // Cleanup: ensure recognition is stopped when the component unmounts.
    return () => {
      recognitionRef.current?.abort();
    };
  }, [uiLang]); // The main setup effect now only depends on the language.

  const startListening = useCallback(async () => {
    if (!recognitionRef.current || isListening) {
      return;
    }

    try {
      // Proactively check microphone permissions.
      const permissionStatus = await navigator.permissions.query({ name: 'microphone' as PermissionName });

      if (permissionStatus.state === 'denied') {
        alert("Akses mikrofon telah dinafikan. Sila benarkan akses mikrofon dalam tetapan pelayar anda untuk menggunakan ciri ini.");
        return;
      }

      // 'prompt' state will trigger the browser's permission request.
      // 'granted' state will start listening immediately.
      recognitionRef.current.start();
      setIsListening(true);
    } catch (e) {
      console.error("Could not start speech recognition:", e);
      // The `onerror` handler will catch more specific errors from the recognition service itself.
    }
  }, [isListening]);

  const stopListening = useCallback(() => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  }, [isListening]);

  const hasRecognitionSupport = !!SpeechRecognitionAPI;

  return { isListening, startListening, stopListening, hasRecognitionSupport };
};
