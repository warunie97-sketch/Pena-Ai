import { useState, useEffect, useCallback } from 'react';
import type { Project } from '../types';
import { useAuth } from '../contexts/AuthContext';

/**
 * A custom hook to manage freelance projects with localStorage persistence.
 * @returns An object containing the list of projects and functions to manage them.
 */
export const useProjects = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const { currentUser } = useAuth();
  const storageKey = currentUser ? `freelancer_projects_${currentUser.id}` : null;

  // Load projects from localStorage on initial mount or when user changes.
  useEffect(() => {
    if (!storageKey) {
      setProjects([]); // Clear projects if no user is logged in
      return;
    }
    try {
      const storedProjects = localStorage.getItem(storageKey);
      if (storedProjects) {
        setProjects(JSON.parse(storedProjects));
      } else {
        setProjects([]);
      }
    } catch (error) {
      console.error("Failed to parse projects from localStorage", error);
      setProjects([]);
    }
  }, [storageKey]);

  // Persist projects to localStorage whenever the projects state changes.
  const persistProjects = useCallback((updatedProjects: Project[]) => {
    if (!storageKey) return;
    try {
      localStorage.setItem(storageKey, JSON.stringify(updatedProjects));
      setProjects(updatedProjects);
    } catch (error) {
      console.error("Failed to save projects to localStorage", error);
    }
  }, [storageKey]);

  const addProject = useCallback((project: Omit<Project, 'id'>) => {
    const newProject: Project = { ...project, id: Date.now().toString() };
    setProjects(prevProjects => {
        const updatedProjects = [newProject, ...prevProjects];
        persistProjects(updatedProjects);
        return updatedProjects;
    });
  }, [persistProjects]);

  const updateProject = useCallback((updatedProject: Project) => {
     setProjects(prevProjects => {
        const updatedProjects = prevProjects.map(p =>
            p.id === updatedProject.id ? updatedProject : p
        );
        persistProjects(updatedProjects);
        return updatedProjects;
    });
  }, [persistProjects]);

  const deleteProject = useCallback((projectId: string) => {
    setProjects(prevProjects => {
        const updatedProjects = prevProjects.filter(p => p.id !== projectId);
        persistProjects(updatedProjects);
        return updatedProjects;
    });
  }, [persistProjects]);

  return { projects, addProject, updateProject, deleteProject };
};
