import { useState, useEffect, useCallback } from 'react';
import type { HistoryItem } from '../types';
import { useAuth } from '../contexts/AuthContext';

const MAX_HISTORY_ITEMS = 50;

/**
 * Custom hook to manage a history of items (e.g., prompts), persisted to localStorage
 * and namespaced by the current user's ID.
 * @param key A unique key for the specific history list.
 * @returns An object containing the history array and functions to manage it.
 */
export const useHistory = (key: string): { history: HistoryItem[], addHistoryItem: (prompt: string) => void, clearHistory: () => void } => {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const { currentUser } = useAuth();
  const storageKey = currentUser ? `history_${currentUser.id}_${key}` : null;

  useEffect(() => {
    if (storageKey) {
      try {
        const storedHistory = localStorage.getItem(storageKey);
        if (storedHistory) {
          setHistory(JSON.parse(storedHistory));
        } else {
          setHistory([]);
        }
      } catch (error) {
        console.error("Failed to load history from localStorage:", error);
        setHistory([]);
      }
    } else {
      setHistory([]);
    }
  }, [storageKey]);
  
  const persistHistory = useCallback((newHistory: HistoryItem[]) => {
      if(storageKey) {
          try {
            localStorage.setItem(storageKey, JSON.stringify(newHistory));
          } catch (error) {
            console.error("Failed to save history to localStorage:", error);
          }
      }
  }, [storageKey]);

  const addHistoryItem = useCallback((prompt: string) => {
    if (!prompt.trim()) return;

    setHistory(prevHistory => {
      const newItem: HistoryItem = { prompt, timestamp: Date.now() };
      // Avoid adding the exact same prompt as the most recent one
      if (prevHistory.length > 0 && prevHistory[0].prompt === prompt) {
        return prevHistory;
      }
      const newHistory = [newItem, ...prevHistory].slice(0, MAX_HISTORY_ITEMS);
      persistHistory(newHistory);
      return newHistory;
    });
  }, [persistHistory]);

  const clearHistory = useCallback(() => {
    setHistory([]);
    persistHistory([]);
  }, [persistHistory]);

  return { history, addHistoryItem, clearHistory };
};