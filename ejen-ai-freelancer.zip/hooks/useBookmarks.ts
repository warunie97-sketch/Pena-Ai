import { useState, useEffect, useCallback } from 'react';

/**
 * A custom hook to manage e-book bookmarks with localStorage persistence for a specific document.
 * @param documentId A unique identifier for the current e-book.
 * @returns An object containing the list of bookmarks and functions to manage them.
 */
export const useBookmarks = (documentId: string | null) => {
  const [bookmarks, setBookmarks] = useState<number[]>([]);
  const storageKey = documentId ? `ebook_bookmarks_${documentId}` : null;

  // Load bookmarks when the documentId changes.
  useEffect(() => {
    if (storageKey) {
      try {
        const stored = localStorage.getItem(storageKey);
        setBookmarks(stored ? JSON.parse(stored) : []);
      } catch (error) {
        console.error("Failed to parse bookmarks from localStorage", error);
        setBookmarks([]);
      }
    } else {
      setBookmarks([]); // Clear bookmarks if no document is loaded
    }
  }, [storageKey]);
  
  const persistBookmarks = useCallback((updatedBookmarks: number[]) => {
      if (storageKey) {
          localStorage.setItem(storageKey, JSON.stringify(updatedBookmarks));
          setBookmarks(updatedBookmarks);
      }
  }, [storageKey]);

  const addBookmark = useCallback((pageNumber: number) => {
    setBookmarks(prev => {
      if (prev.includes(pageNumber)) {
        return prev; // Avoid duplicates
      }
      const newBookmarks = [...prev, pageNumber].sort((a, b) => a - b);
      persistBookmarks(newBookmarks);
      return newBookmarks;
    });
  }, [persistBookmarks]);

  const removeBookmark = useCallback((pageNumber: number) => {
    setBookmarks(prev => {
      const newBookmarks = prev.filter(p => p !== pageNumber);
      persistBookmarks(newBookmarks);
      return newBookmarks;
    });
  }, [persistBookmarks]);

  return { bookmarks, addBookmark, removeBookmark };
};
