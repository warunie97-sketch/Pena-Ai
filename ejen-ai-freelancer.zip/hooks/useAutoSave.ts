import { useState, useEffect, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';

type SaveStatus = 'unsaved' | 'saving' | 'saved';

/**
 * A custom React hook to automatically save text to localStorage and retrieve it on mount,
 * namespaced by the current user's ID.
 * @param key A unique key for the localStorage item (e.g., a tool ID).
 * @param value The text value to be saved.
 * @param setValue The state setter function to update the text value.
 */
export const useAutoSave = (key: string, value: string, setValue: (value: string) => void) => {
  const [saveStatus, setSaveStatus] = useState<SaveStatus>('saved');
  const { currentUser } = useAuth();
  const storageKey = currentUser ? `draft_${currentUser.id}_${key}` : null;
  const timeoutRef = useRef<number | null>(null);

  // Load saved draft on initial mount
  useEffect(() => {
    if (storageKey) {
      try {
        const savedValue = localStorage.getItem(storageKey);
        if (savedValue) {
          setValue(savedValue);
        }
      } catch (error) {
        console.error("Failed to load draft from localStorage:", error);
      }
    }
    // We only want this to run once when the component mounts with a valid key.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [storageKey]);

  // Handle auto-saving
  useEffect(() => {
    if (!storageKey) return;

    // Don't save the initial empty state if nothing was loaded
    if (value === '' && !localStorage.getItem(storageKey)) {
        return;
    }

    setSaveStatus('unsaved');

    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    timeoutRef.current = window.setTimeout(() => {
      setSaveStatus('saving');
      try {
        localStorage.setItem(storageKey, value);
        setTimeout(() => setSaveStatus('saved'), 500); // Give user feedback
      } catch (error) {
        console.error("Failed to save draft to localStorage:", error);
        setSaveStatus('unsaved');
      }
    }, 1000); // Debounce save by 1 second

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [value, storageKey]);


  return saveStatus;
};