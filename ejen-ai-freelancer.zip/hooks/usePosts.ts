import { useState, useEffect, useCallback } from 'react';
import type { Post } from '../types';

/**
 * A custom hook to manage community feed posts with localStorage persistence.
 * @param key The localStorage key to use for storing posts. If null, the hook will not persist data.
 * @returns An object containing the list of posts and functions to manage them.
 */
export const usePosts = (key: string | null) => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [isInitialLoadComplete, setIsInitialLoadComplete] = useState(false);

  // Effect 1: Load posts from localStorage on initial mount or when key changes.
  useEffect(() => {
    setIsInitialLoadComplete(false);
    if (!key) {
        setPosts([]);
        setIsInitialLoadComplete(true);
        return;
    }
    try {
      const storedPosts = localStorage.getItem(key);
      if (storedPosts) {
        const parsedData = JSON.parse(storedPosts);
        if (Array.isArray(parsedData)) {
          setPosts(parsedData);
        } else {
          console.warn(`Invalid data found in localStorage for key "${key}", resetting.`);
          setPosts([]);
        }
      } else {
        setPosts([]);
      }
    } catch (error) {
      console.error(`Failed to parse posts from localStorage for key "${key}"`, error);
      setPosts([]);
    } finally {
      setIsInitialLoadComplete(true);
    }
  }, [key]);

  // Effect 2: Persist posts to localStorage whenever the posts state changes,
  // but only after the initial load is complete to prevent overwriting.
  useEffect(() => {
    if (isInitialLoadComplete && key) {
      try {
        localStorage.setItem(key, JSON.stringify(posts));
      } catch (error) {
        console.error(`Failed to save posts to localStorage for key "${key}"`, error);
      }
    }
  }, [posts, isInitialLoadComplete, key]);

  const addPost = useCallback((postData: Omit<Post, 'id' | 'timestamp'>) => {
    const newPost: Post = { 
        ...postData, 
        id: Date.now().toString(),
        timestamp: new Date().toISOString()
    };
    setPosts(prevPosts => [newPost, ...prevPosts]);
  }, []);

  const updatePost = useCallback((updatedPost: Post) => {
    setPosts(prevPosts => prevPosts.map(p => p.id === updatedPost.id ? updatedPost : p));
  }, []);

  const deletePost = useCallback((postId: string) => {
    setPosts(prevPosts => prevPosts.filter(p => p.id !== postId));
  }, []);


  return { posts, addPost, updatePost, deletePost };
};
